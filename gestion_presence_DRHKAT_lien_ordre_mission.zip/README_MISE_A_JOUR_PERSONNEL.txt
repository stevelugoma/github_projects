MISE A JOUR DU MODULE PERSONNELS

1. Le champ personnel.SITE est désormais alimenté directement par entite.Site.
2. Le champ personnel.ENTITE est désormais alimenté directement par appartenance.Entite.
3. CODE_SITE, CODE_ENTITE et CODE_DIV sont masqués au premier affichage du tableau.
   Ils restent disponibles via le bouton « Colonnes ».
4. Les référentiels Divisions et Fonctions disposent maintenant des opérations :
   ajout, modification et suppression.
5. Les changements de division sont propagés vers les fiches du personnel concernées.
6. Les suppressions de division utilisée sont bloquées pour protéger l'intégrité des données.

Déploiement :
- Remplacer les fichiers de l'application par ceux de cette archive.
- Importer migration_personnel_referentiels.sql dans phpMyAdmin si nécessaire.
- Recharger avec Ctrl+F5.

MISE A JOUR GRADE
- Importer migration_grade.sql dans la base edrhk2581223_21zrkh.
- Le champ Grade de la fiche personnel est maintenant une liste issue de la table grade.
- CODE_GRADE est alimenté par grade.Code et GRADES par grade.sigle_grade.
- Ajout, modification et suppression des grades dans Personnels > Grades.

SIGNATAIRES D'IMPRESSION
- Importer migration_signataires.sql si nécessaire.
- Gérer les signataires dans Personnels > Signataires.
- Lors d'une impression, choisir le signataire dans le tableau proposé.
