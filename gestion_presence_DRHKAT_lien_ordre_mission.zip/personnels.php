<?php
require_once __DIR__ . '/auth.php';

$pageTitle = 'Gestion du personnel';
$activePage = 'personnels.php';
$canWrite = aPermission('personnels.manage');
$canManageSignataires = aPermission('signataires.manage');
$pdo = db();
ensurePersonnelFunctionColumns($pdo);
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS signataire_impression (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        nom_complet VARCHAR(200) NOT NULL,
        qualite VARCHAR(150) NOT NULL,
        actif TINYINT(1) NOT NULL DEFAULT 1,
        ordre_affichage INT NOT NULL DEFAULT 0,
        date_creation DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Throwable $e) { }

$extraHead = <<<'HTML'
<link rel="stylesheet" href="https://cdn.datatables.net/rowgroup/1.5.1/css/rowGroup.bootstrap5.min.css">
HTML;
$extraScripts = <<<'HTML'
<script src="https://cdn.datatables.net/buttons/3.1.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/3.1.2/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/rowgroup/1.5.1/js/dataTables.rowGroup.min.js"></script>
<script src="assets/personnels.js?v=1.7"></script>
HTML;

function personnelPost($key, $default = '') {
    return isset($_POST[$key]) ? trim((string)$_POST[$key]) : $default;
}

function personnelNull($value) {
    $value = trim((string)$value);
    return $value === '' ? null : $value;
}

function personnelFetchEntity($pdo, $id) {
    $stmt = $pdo->prepare('SELECT IdEntite, Site, CommentaireEnt FROM entite WHERE IdEntite=?');
    $stmt->execute(array($id));
    return $stmt->fetch();
}

function personnelFetchMembership($pdo, $id) {
    $stmt = $pdo->prepare('SELECT IdAppartenance, DesignationAppart, Entite, CommentaireAppart FROM appartenance WHERE IdAppartenance=?');
    $stmt->execute(array($id));
    return $stmt->fetch();
}

function personnelFetchDivision($pdo, $id) {
    $stmt = $pdo->prepare('SELECT ID_DIV, DIVISION, CODE_DIV FROM division WHERE ID_DIV=?');
    $stmt->execute(array($id));
    return $stmt->fetch();
}

function personnelFetchGrade($pdo, $id) {
    $stmt = $pdo->prepare('SELECT id_gr, sigle_grade, Libelle_complete, Code, Commentaire, ordre_gr, Categorie FROM grade WHERE id_gr=?');
    $stmt->execute(array($id));
    return $stmt->fetch();
}

function personnelFetchFunction($pdo, $id) {
    $stmt = $pdo->prepare('SELECT id_fonction, Libelle_Fonction, Sigle_Fonction, Etat_Fonction FROM fonction WHERE id_fonction=?');
    $stmt->execute(array($id));
    return $stmt->fetch();
}


// Détail dynamique des effectifs par site, appartenance ou division.
if (isset($_GET['ajax_effectif'])) {
    header('Content-Type: application/json; charset=UTF-8');
    $type = isset($_GET['type']) ? (string)$_GET['type'] : '';
    $id = isset($_GET['id']) ? (string)$_GET['id'] : '';
    $label = isset($_GET['label']) ? (string)$_GET['label'] : '';
    $where = '';
    $paramsEffectif = array();
    if ($type === 'site') {
        if ($id === '__NULL__') $where = '(p.CODE_SITE IS NULL OR p.SITE IS NULL OR TRIM(p.SITE)=\'\')';
        else { $where = 'p.CODE_SITE = ?'; $paramsEffectif[] = $id; }
    } elseif ($type === 'appartenance') {
        if ($id === '__NULL__') $where = '(p.CODE_ENTITE IS NULL OR p.ENTITE IS NULL OR TRIM(p.ENTITE)=\'\')';
        else { $where = 'p.CODE_ENTITE = ?'; $paramsEffectif[] = $id; }
    } elseif ($type === 'division') {
        if ($id === '__NULL__') $where = '(p.CODE_DIV IS NULL OR p.DIVISION IS NULL OR TRIM(p.DIVISION)=\'\')';
        else { $where = 'p.CODE_DIV = ?'; $paramsEffectif[] = $id; }
    } elseif ($type === 'grade') {
        if ($id === '__NULL__') $where = '(p.GRADES IS NULL OR TRIM(p.GRADES)=\'\')';
        else { $where = 'p.GRADES = ?'; $paramsEffectif[] = $id; }
    } else { echo json_encode(array('ok'=>false,'message'=>'Type de regroupement invalide.')); exit; }

    try {
        $stmt = $pdo->prepare("SELECT p.CODE_AGENT,p.NOMS,p.SITE,p.ENTITE,p.DIVISION,p.GRADES,p.CODE_FONCTION,p.FONCTION_AGENT,p.MATRICULE
                              FROM personnel p WHERE $where ORDER BY p.NOMS, p.CODE_AGENT");
        $stmt->execute($paramsEffectif);
        $rows = $stmt->fetchAll();
        echo json_encode(array('ok'=>true,'type'=>$type,'label'=>$label,'effectif'=>count($rows),'rows'=>$rows), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    } catch (Throwable $e) {
        echo json_encode(array('ok'=>false,'message'=>$e->getMessage()), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = personnelPost('action');
    $isSignerAction = in_array($action, array('save_signataire','delete_signataire'), true);
    if ($isSignerAction) {
        exigerPermission('signataires.manage','personnels.php?tab=signataires');
    } else {
        exigerPermission('personnels.manage','personnels.php');
    }


    try {
        if ($action === 'save_signataire') {
            $id = (int)personnelPost('id');
            $nom = personnelPost('nom_complet');
            $qualite = personnelPost('qualite');
            $actif = isset($_POST['actif']) ? 1 : 0;
            $ordre = (int)personnelPost('ordre_affichage', '0');
            if ($nom === '' || $qualite === '') throw new RuntimeException('Le nom et la qualité du signataire sont obligatoires.');
            if ($id > 0) {
                $old = $pdo->prepare('SELECT * FROM signataire_impression WHERE id=?'); $old->execute(array($id)); $oldRow=$old->fetch();
                $pdo->prepare('UPDATE signataire_impression SET nom_complet=?,qualite=?,actif=?,ordre_affichage=? WHERE id=?')->execute(array($nom,$qualite,$actif,$ordre,$id));
                logAudit('update','signataire_impression',(string)$id,$oldRow,$_POST);
                flash('success','Le signataire a été modifié.');
            } else {
                $pdo->prepare('INSERT INTO signataire_impression(nom_complet,qualite,actif,ordre_affichage) VALUES(?,?,?,?)')->execute(array($nom,$qualite,$actif,$ordre));
                logAudit('create','signataire_impression',(string)$pdo->lastInsertId(),null,$_POST);
                flash('success','Le signataire a été ajouté.');
            }
        } elseif ($action === 'delete_signataire') {
            $id=(int)personnelPost('id');
            $pdo->prepare('DELETE FROM signataire_impression WHERE id=?')->execute(array($id));
            logAudit('delete','signataire_impression',(string)$id);
            flash('success','Le signataire a été supprimé.');
        } elseif ($action === 'save_personnel') {
            $codeAgent = (int)personnelPost('CODE_AGENT');
            $oldCode = (int)personnelPost('OLD_CODE_AGENT', (string)$codeAgent);
            $noms = personnelPost('NOMS');
            $codeSite = (int)personnelPost('CODE_SITE');
            $codeEntite = (int)personnelPost('CODE_ENTITE');
            $divisionId = (int)personnelPost('ID_DIV');
            $gradeId = (int)personnelPost('ID_GRADE');
            $fonctionId = (int)personnelPost('CODE_FONCTION');
            if ($codeAgent <= 0 || $noms === '' || $codeSite <= 0 || $codeEntite <= 0) {
                throw new RuntimeException('Le code agent, les noms, le site et l’entité sont obligatoires.');
            }

            $siteRow = personnelFetchEntity($pdo, $codeSite);
            $appRow = personnelFetchMembership($pdo, $codeEntite);
            if (!$siteRow) throw new RuntimeException('Le site sélectionné est introuvable.');
            if (!$appRow) throw new RuntimeException('L’entité sélectionnée est introuvable.');
            $divisionRow = null;
            if ($divisionId > 0) {
                $divisionRow = personnelFetchDivision($pdo, $divisionId);
                if (!$divisionRow) throw new RuntimeException('La division sélectionnée est introuvable.');
            }
            $gradeRow = null;
            if ($gradeId > 0) {
                $gradeRow = personnelFetchGrade($pdo, $gradeId);
                if (!$gradeRow) throw new RuntimeException('Le grade sélectionné est introuvable.');
            }
            $fonctionRow = null;
            if ($fonctionId > 0) {
                $fonctionRow = personnelFetchFunction($pdo, $fonctionId);
                if (!$fonctionRow) throw new RuntimeException('La fonction sélectionnée est introuvable.');
            }
            if (!empty($appRow['Entite']) && (int)$appRow['Entite'] !== $codeSite) {
                throw new RuntimeException('L’entité d’appartenance ne correspond pas au site sélectionné.');
            }

            $siteLabel = personnelNull($siteRow['Site']);
            $entityLabel = personnelNull($appRow['Entite']);

            $old = null;
            $stmtOld = $pdo->prepare('SELECT * FROM personnel WHERE CODE_AGENT=?');
            $stmtOld->execute(array($oldCode));
            $old = $stmtOld->fetch();

            if ($old) {
                $stmt = $pdo->prepare('UPDATE personnel SET CODE_AGENT=?, NOMS=?, CODE_SITE=?, SITE=?, CODE_ENTITE=?, ENTITE=?, CODE_DIV=?, DIVISION=?, CODE_GRADE=?, GRADES=?, CODE_FONCTION=?, FONCTION_AGENT=?, MATRICULE=? WHERE CODE_AGENT=?');
                $stmt->execute(array(
                    $codeAgent, $noms, $codeSite, $siteLabel, $codeEntite, $entityLabel,
                    $divisionRow ? personnelNull($divisionRow['CODE_DIV']) : null, $divisionRow ? personnelNull($divisionRow['DIVISION']) : null,
                    $gradeRow ? personnelNull($gradeRow['Code']) : null, $gradeRow ? personnelNull($gradeRow['sigle_grade']) : null,
                    $fonctionRow ? (int)$fonctionRow['id_fonction'] : null, $fonctionRow ? personnelNull($fonctionRow['Libelle_Fonction']) : null,
                    personnelNull(personnelPost('MATRICULE')), $oldCode
                ));
                logAudit('update', 'personnel', (string)$codeAgent, $old, $_POST);
                flash('success', 'La fiche du personnel a été mise à jour. Les libellés SITE et ENTITE ont été synchronisés automatiquement.');
            } else {
                $stmt = $pdo->prepare('INSERT INTO personnel (CODE_AGENT,NOMS,CODE_SITE,SITE,CODE_ENTITE,ENTITE,CODE_DIV,DIVISION,CODE_GRADE,GRADES,CODE_FONCTION,FONCTION_AGENT,MATRICULE) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)');
                $stmt->execute(array(
                    $codeAgent, $noms, $codeSite, $siteLabel, $codeEntite, $entityLabel,
                    $divisionRow ? personnelNull($divisionRow['CODE_DIV']) : null, $divisionRow ? personnelNull($divisionRow['DIVISION']) : null,
                    $gradeRow ? personnelNull($gradeRow['Code']) : null, $gradeRow ? personnelNull($gradeRow['sigle_grade']) : null,
                    $fonctionRow ? (int)$fonctionRow['id_fonction'] : null, $fonctionRow ? personnelNull($fonctionRow['Libelle_Fonction']) : null,
                    personnelNull(personnelPost('MATRICULE'))
                ));
                logAudit('create', 'personnel', (string)$codeAgent, null, $_POST);
                flash('success', 'Le membre du personnel a été ajouté.');
            }
        } elseif ($action === 'delete_personnel') {
            $code = (int)personnelPost('CODE_AGENT');
            $stmt = $pdo->prepare('SELECT * FROM personnel WHERE CODE_AGENT=?');
            $stmt->execute(array($code));
            $old = $stmt->fetch();
            if ($old) {
                $pdo->prepare('DELETE FROM personnel WHERE CODE_AGENT=?')->execute(array($code));
                logAudit('delete', 'personnel', (string)$code, $old, null);
                flash('success', 'La fiche du personnel a été supprimée.');
            }
        } elseif ($action === 'save_entite') {
            $id = (int)personnelPost('IdEntite');
            $site = personnelPost('Site');
            $comment = personnelPost('CommentaireEnt');
            if ($site === '') throw new RuntimeException('La désignation technique du site est obligatoire.');
            if ($id > 0) {
                $old = personnelFetchEntity($pdo, $id);
                $pdo->prepare('UPDATE entite SET Site=?, CommentaireEnt=? WHERE IdEntite=?')->execute(array($site, personnelNull($comment), $id));
                $pdo->prepare('UPDATE personnel SET SITE=? WHERE CODE_SITE=?')->execute(array($site, $id));
                logAudit('update', 'entite', (string)$id, $old, $_POST);
                flash('success', 'Le site a été modifié et ses libellés ont été propagés au personnel.');
            } else {
                $pdo->prepare('INSERT INTO entite (Site, CommentaireEnt) VALUES (?,?)')->execute(array($site, personnelNull($comment)));
                $id = (int)$pdo->lastInsertId();
                logAudit('create', 'entite', (string)$id, null, $_POST);
                flash('success', 'Le site a été ajouté.');
            }
        } elseif ($action === 'delete_entite') {
            $id = (int)personnelPost('IdEntite');
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM personnel WHERE CODE_SITE=?');
            $stmt->execute(array($id));
            $usedPersonnel = (int)$stmt->fetchColumn();
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM appartenance WHERE Entite=?');
            $stmt->execute(array($id));
            $usedApp = (int)$stmt->fetchColumn();
            if ($usedPersonnel || $usedApp) throw new RuntimeException('Suppression impossible : ce site est encore utilisé par du personnel ou des appartenances.');
            $old = personnelFetchEntity($pdo, $id);
            $pdo->prepare('DELETE FROM entite WHERE IdEntite=?')->execute(array($id));
            logAudit('delete', 'entite', (string)$id, $old, null);
            flash('success', 'Le site a été supprimé.');
        } elseif ($action === 'save_appartenance') {
            $id = (int)personnelPost('IdAppartenance');
            $designation = personnelPost('DesignationAppart');
            $entity = (int)personnelPost('Entite');
            $comment = personnelPost('CommentaireAppart');
            if ($designation === '' || $entity <= 0) throw new RuntimeException('La désignation et le site de rattachement sont obligatoires.');
            if (!personnelFetchEntity($pdo, $entity)) throw new RuntimeException('Le site de rattachement est introuvable.');
            if ($id > 0) {
                $old = personnelFetchMembership($pdo, $id);
                $pdo->prepare('UPDATE appartenance SET DesignationAppart=?, Entite=?, CommentaireAppart=? WHERE IdAppartenance=?')->execute(array($designation, $entity, personnelNull($comment), $id));
                $pdo->prepare('UPDATE personnel SET CODE_SITE=?, SITE=(SELECT Site FROM entite WHERE IdEntite=?), ENTITE=? WHERE CODE_ENTITE=?')->execute(array($entity, $entity, (string)$entity, $id));
                logAudit('update', 'appartenance', (string)$id, $old, $_POST);
                flash('success', 'L’appartenance a été modifiée et propagée au personnel concerné.');
            } else {
                $pdo->prepare('INSERT INTO appartenance (DesignationAppart,Entite,CommentaireAppart) VALUES (?,?,?)')->execute(array($designation, $entity, personnelNull($comment)));
                $id = (int)$pdo->lastInsertId();
                logAudit('create', 'appartenance', (string)$id, null, $_POST);
                flash('success', 'L’appartenance a été ajoutée.');
            }
        } elseif ($action === 'delete_appartenance') {
            $id = (int)personnelPost('IdAppartenance');
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM personnel WHERE CODE_ENTITE=?');
            $stmt->execute(array($id));
            if ((int)$stmt->fetchColumn() > 0) throw new RuntimeException('Suppression impossible : cette appartenance est encore affectée à du personnel.');
            $old = personnelFetchMembership($pdo, $id);
            $pdo->prepare('DELETE FROM appartenance WHERE IdAppartenance=?')->execute(array($id));
            logAudit('delete', 'appartenance', (string)$id, $old, null);
            flash('success', 'L’appartenance a été supprimée.');
        } elseif ($action === 'save_division') {
            $id = (int)personnelPost('ID_DIV');
            $oldId = (int)personnelPost('OLD_ID_DIV', (string)$id);
            $libelle = personnelPost('DIVISION');
            $code = (int)personnelPost('CODE_DIV');
            if ($id <= 0 || $libelle === '' || $code <= 0) throw new RuntimeException('ID, libellé et code de division sont obligatoires.');
            $old = personnelFetchDivision($pdo, $oldId);
            if ($old) {
                $pdo->prepare('UPDATE division SET ID_DIV=?, DIVISION=?, CODE_DIV=? WHERE ID_DIV=?')->execute(array($id,$libelle,$code,$oldId));
                $pdo->prepare('UPDATE personnel SET CODE_DIV=?, DIVISION=? WHERE CODE_DIV=?')->execute(array($code,$libelle,$old['CODE_DIV']));
                logAudit('update','division',(string)$id,$old,$_POST);
                flash('success','La division a été modifiée et propagée au personnel.');
            } else {
                $pdo->prepare('INSERT INTO division (ID_DIV,DIVISION,CODE_DIV) VALUES (?,?,?)')->execute(array($id,$libelle,$code));
                logAudit('create','division',(string)$id,null,$_POST);
                flash('success','La division a été ajoutée.');
            }
        } elseif ($action === 'delete_division') {
            $id=(int)personnelPost('ID_DIV');
            $old=personnelFetchDivision($pdo,$id);
            if ($old) {
                $st=$pdo->prepare('SELECT COUNT(*) FROM personnel WHERE CODE_DIV=?'); $st->execute(array($old['CODE_DIV']));
                if ((int)$st->fetchColumn()>0) throw new RuntimeException('Suppression impossible : cette division est utilisée par du personnel.');
                $pdo->prepare('DELETE FROM division WHERE ID_DIV=?')->execute(array($id));
                logAudit('delete','division',(string)$id,$old,null);
                flash('success','La division a été supprimée.');
            }

        } elseif ($action === 'save_grade') {
            $id=(int)personnelPost('id_gr');
            $sigle=personnelPost('sigle_grade');
            $libelle=personnelPost('Libelle_complete');
            $code=personnelNull(personnelPost('Code'));
            $comment=personnelNull(personnelPost('Commentaire'));
            $ordre=personnelNull(personnelPost('ordre_gr'));
            $categorie=personnelNull(personnelPost('Categorie'));
            if ($libelle==='') throw new RuntimeException('Le libellé complet du grade est obligatoire.');
            $data=array(personnelNull($sigle),$libelle,$code,$comment,$ordre,$categorie);
            if ($id>0) {
                $st=$pdo->prepare('SELECT * FROM grade WHERE id_gr=?'); $st->execute(array($id)); $old=$st->fetch();
                $pdo->prepare('UPDATE grade SET sigle_grade=?,Libelle_complete=?,Code=?,Commentaire=?,ordre_gr=?,Categorie=? WHERE id_gr=?')->execute(array_merge($data,array($id)));
                if ($old) {
                    $pdo->prepare('UPDATE personnel SET CODE_GRADE=?, GRADES=? WHERE CODE_GRADE=? OR GRADES=?')->execute(array($code,personnelNull($sigle),$old['Code'],$old['sigle_grade']));
                }
                logAudit('update','grade',(string)$id,$old,$_POST); flash('success','Le grade a été modifié et propagé au personnel.');
            } else {
                $pdo->prepare('INSERT INTO grade (sigle_grade,Libelle_complete,Code,Commentaire,ordre_gr,Categorie) VALUES (?,?,?,?,?,?)')->execute($data);
                $id=(int)$pdo->lastInsertId(); logAudit('create','grade',(string)$id,null,$_POST); flash('success','Le grade a été ajouté.');
            }
        } elseif ($action === 'delete_grade') {
            $id=(int)personnelPost('id_gr');
            $st=$pdo->prepare('SELECT * FROM grade WHERE id_gr=?'); $st->execute(array($id)); $old=$st->fetch();
            if ($old) {
                $check=$pdo->prepare('SELECT COUNT(*) FROM personnel WHERE CODE_GRADE=? OR GRADES=?'); $check->execute(array($old['Code'],$old['sigle_grade']));
                if ((int)$check->fetchColumn()>0) throw new RuntimeException('Suppression impossible : ce grade est utilisé par du personnel.');
                $pdo->prepare('DELETE FROM grade WHERE id_gr=?')->execute(array($id)); logAudit('delete','grade',(string)$id,$old,null); flash('success','Le grade a été supprimé.');
            }
        } elseif ($action === 'save_fonction') {
            $id=(int)personnelPost('id_fonction');
            $libelle=personnelPost('Libelle_Fonction');
            if ($libelle==='') throw new RuntimeException('Le libellé de la fonction est obligatoire.');
            $data=array($libelle,personnelNull(personnelPost('Sigle_Fonction')),personnelNull(personnelPost('Commentaires_Fonction')),personnelNull(personnelPost('Obs_Fonction')),personnelNull(personnelPost('Etat_Fonction')));
            if ($id>0) {
                $st=$pdo->prepare('SELECT * FROM fonction WHERE id_fonction=?'); $st->execute(array($id)); $old=$st->fetch();
                $pdo->prepare('UPDATE fonction SET Libelle_Fonction=?,Sigle_Fonction=?,Commentaires_Fonction=?,Obs_Fonction=?,Etat_Fonction=? WHERE id_fonction=?')->execute(array_merge($data,array($id)));
                $pdo->prepare('UPDATE personnel SET FONCTION_AGENT=? WHERE CODE_FONCTION=?')->execute(array($libelle,$id));
                logAudit('update','fonction',(string)$id,$old,$_POST); flash('success','La fonction a été modifiée.');
            } else {
                $pdo->prepare('INSERT INTO fonction (Libelle_Fonction,Sigle_Fonction,Commentaires_Fonction,Obs_Fonction,Etat_Fonction) VALUES (?,?,?,?,?)')->execute($data);
                $id=(int)$pdo->lastInsertId(); logAudit('create','fonction',(string)$id,null,$_POST); flash('success','La fonction a été ajoutée.');
            }
        } elseif ($action === 'delete_fonction') {
            $id=(int)personnelPost('id_fonction');
            $st=$pdo->prepare('SELECT * FROM fonction WHERE id_fonction=?'); $st->execute(array($id)); $old=$st->fetch();
            if ($old) { $check=$pdo->prepare('SELECT COUNT(*) FROM personnel WHERE CODE_FONCTION=?'); $check->execute(array($id)); if ((int)$check->fetchColumn()>0) throw new RuntimeException('Suppression impossible : cette fonction est attribuée à du personnel.'); $pdo->prepare('DELETE FROM fonction WHERE id_fonction=?')->execute(array($id)); logAudit('delete','fonction',(string)$id,$old,null); flash('success','La fonction a été supprimée.'); }
        } elseif ($action === 'sync_labels') {
            $sql = "UPDATE personnel p
                    LEFT JOIN entite e ON e.IdEntite=p.CODE_SITE
                    LEFT JOIN appartenance a ON a.IdAppartenance=p.CODE_ENTITE
                    LEFT JOIN fonction f ON f.id_fonction=p.CODE_FONCTION
                    SET p.SITE=COALESCE(NULLIF(e.Site,''),p.SITE),
                        p.ENTITE=COALESCE(CAST(a.Entite AS CHAR),p.ENTITE),
                        p.FONCTION_AGENT=COALESCE(NULLIF(f.Libelle_Fonction,''),p.FONCTION_AGENT)";
            $count = $pdo->exec($sql);
            logAudit('synchronise', 'personnel', null, null, array('lignes'=>$count));
            flash('success', $count . ' fiche(s) ont été synchronisée(s) avec les tables ENTITE et APPARTENANCE.');
        }
    } catch (Throwable $e) {
        flash('danger', h($e->getMessage()));
    }
    $retourImpression = isset($_POST['retour_impression']) && $_POST['retour_impression'] === '1';
    redirect($retourImpression ? 'personnels.php?ouvrir_signataires_impression=1' : 'personnels.php');
}

$sites = $pdo->query("SELECT e.IdEntite,e.Site,e.CommentaireEnt,COUNT(DISTINCT p.CODE_AGENT) effectif,COUNT(DISTINCT a.IdAppartenance) appartenances
                      FROM entite e
                      LEFT JOIN personnel p ON p.CODE_SITE=e.IdEntite
                      LEFT JOIN appartenance a ON a.Entite=e.IdEntite
                      GROUP BY e.IdEntite,e.Site,e.CommentaireEnt
                      ORDER BY COALESCE(NULLIF(e.CommentaireEnt,''),e.Site)")->fetchAll();
$divisions = $pdo->query("SELECT d.ID_DIV,d.DIVISION,d.CODE_DIV,COUNT(DISTINCT p.CODE_AGENT) AS effectif FROM division d LEFT JOIN personnel p ON p.CODE_DIV=d.CODE_DIV GROUP BY d.ID_DIV,d.DIVISION,d.CODE_DIV ORDER BY d.DIVISION,d.CODE_DIV")->fetchAll();
$fonctions = $pdo->query("SELECT id_fonction,Libelle_Fonction,Sigle_Fonction,Commentaires_Fonction,Obs_Fonction,Etat_Fonction FROM fonction ORDER BY Libelle_Fonction")->fetchAll();
// Référentiel utilisé par les listes de qualité des signataires.
$qualitesFonction = array();
foreach ($fonctions as $fonctionRef) {
    $libelleQualite = trim((string)$fonctionRef['Libelle_Fonction']);
    if ($libelleQualite === '') continue;
    $qualitesFonction[] = array(
        'valeur' => $libelleQualite,
        'sigle' => trim((string)$fonctionRef['Sigle_Fonction']),
        'etat' => trim((string)$fonctionRef['Etat_Fonction'])
    );
}
$grades = $pdo->query("SELECT id_gr,sigle_grade,Libelle_complete,Code,Commentaire,ordre_gr,Categorie FROM grade ORDER BY ordre_gr, Libelle_complete")->fetchAll();
$signataires = $pdo->query("SELECT * FROM signataire_impression ORDER BY actif DESC, ordre_affichage, nom_complet")->fetchAll();
// Dernier code agent utilisé et prochain code disponible pour chaque grade.
// La proposition évite également les collisions avec un CODE_AGENT déjà attribué à un autre grade.
$codesAgentsUtilises = array();
foreach ($pdo->query("SELECT CODE_AGENT FROM personnel WHERE CODE_AGENT IS NOT NULL ORDER BY CODE_AGENT")->fetchAll(PDO::FETCH_COLUMN) as $codeExistant) {
    $codesAgentsUtilises[(int)$codeExistant] = true;
}
$codeSuggestionsParGrade = array();
foreach ($grades as $gradeRef) {
    $stmtDernierCode = $pdo->prepare("SELECT MAX(CAST(CODE_AGENT AS UNSIGNED)) FROM personnel WHERE CODE_GRADE=? AND (GRADES=? OR (?='' AND (GRADES IS NULL OR TRIM(GRADES)='')))");
    $stmtDernierCode->execute(array($gradeRef['Code'], (string)$gradeRef['sigle_grade'], (string)$gradeRef['sigle_grade']));
    $dernierCode = (int)$stmtDernierCode->fetchColumn();
    $prochainCode = $dernierCode > 0 ? $dernierCode + 1 : 1;
    while (isset($codesAgentsUtilises[$prochainCode])) { $prochainCode++; }
    $codeSuggestionsParGrade[(string)$gradeRef['id_gr']] = array(
        'dernier' => $dernierCode > 0 ? $dernierCode : null,
        'suivant' => $prochainCode,
        'grade' => (string)($gradeRef['sigle_grade'] ?: $gradeRef['Libelle_complete'])
    );
}
$appartenances = $pdo->query("SELECT a.IdAppartenance,a.DesignationAppart,a.Entite,a.CommentaireAppart,
                              e.Site site_libelle,COUNT(p.CODE_AGENT) effectif
                              FROM appartenance a
                              LEFT JOIN entite e ON e.IdEntite=a.Entite
                              LEFT JOIN personnel p ON p.CODE_ENTITE=a.IdAppartenance
                              GROUP BY a.IdAppartenance,a.DesignationAppart,a.Entite,a.CommentaireAppart,e.CommentaireEnt,e.Site
                              ORDER BY site_libelle,a.DesignationAppart")->fetchAll();
$personnels = $pdo->query("SELECT p.*, COALESCE(NULLIF(e.Site,''),p.SITE) SITE_REF,
                          COALESCE(CAST(a.Entite AS CHAR),p.ENTITE) ENTITE_REF,
                          COALESCE(d.CODE_DIV,p.CODE_DIV) CODE_DIV_REF,
                          COALESCE(NULLIF(d.DIVISION,''),p.DIVISION) DIVISION_REF,
                          d.ID_DIV ID_DIV_REF,
                          COALESCE(NULLIF(f.Libelle_Fonction,''),p.FONCTION_AGENT) FONCTION_AGENT_REF,
                          a.DesignationAppart, e.Site SiteTechnique
                          FROM personnel p
                          LEFT JOIN entite e ON e.IdEntite=p.CODE_SITE
                          LEFT JOIN appartenance a ON a.IdAppartenance=p.CODE_ENTITE
                          LEFT JOIN division d ON d.CODE_DIV=p.CODE_DIV
                          LEFT JOIN fonction f ON f.id_fonction=p.CODE_FONCTION
                          ORDER BY p.NOMS,p.CODE_AGENT")->fetchAll();

$stats = array(
    'total' => (int)$pdo->query('SELECT COUNT(*) FROM personnel')->fetchColumn(),
    'sites' => (int)$pdo->query('SELECT COUNT(DISTINCT CODE_SITE) FROM personnel WHERE CODE_SITE IS NOT NULL')->fetchColumn(),
    'entites' => (int)$pdo->query('SELECT COUNT(DISTINCT CODE_ENTITE) FROM personnel WHERE CODE_ENTITE IS NOT NULL')->fetchColumn(),
    'fonctions' => (int)$pdo->query("SELECT COUNT(DISTINCT CODE_FONCTION) FROM personnel WHERE CODE_FONCTION IS NOT NULL")->fetchColumn(),
    'grades' => (int)$pdo->query("SELECT COUNT(DISTINCT GRADES) FROM personnel WHERE GRADES IS NOT NULL AND TRIM(GRADES)<>''")->fetchColumn(),
    'sansMatricule' => (int)$pdo->query("SELECT COUNT(*) FROM personnel WHERE MATRICULE IS NULL OR TRIM(MATRICULE)='' ")->fetchColumn(),
    'nonRattaches' => (int)$pdo->query('SELECT COUNT(*) FROM personnel WHERE CODE_SITE IS NULL OR CODE_ENTITE IS NULL')->fetchColumn()
);

$chartSites = $pdo->query("SELECT COALESCE(CAST(p.CODE_SITE AS CHAR),'__NULL__') id,
                                  COALESCE(NULLIF(e.Site,''),NULLIF(p.SITE,''),'Non renseigné') label,COUNT(*) total
                           FROM personnel p LEFT JOIN entite e ON e.IdEntite=p.CODE_SITE
                           GROUP BY p.CODE_SITE,label ORDER BY total DESC LIMIT 12")->fetchAll();
$chartEntities = $pdo->query("SELECT COALESCE(CAST(p.CODE_ENTITE AS CHAR),'__NULL__') id,
                                    COALESCE(NULLIF(TRIM(a.DesignationAppart),''),NULLIF(TRIM(a.CommentaireAppart),''),NULLIF(TRIM(p.ENTITE),''),'Non renseignée') label,COUNT(*) total
                              FROM personnel p LEFT JOIN appartenance a ON a.IdAppartenance=p.CODE_ENTITE
                              GROUP BY p.CODE_ENTITE,label ORDER BY total DESC LIMIT 12")->fetchAll();
$chartGrades = $pdo->query("SELECT COALESCE(NULLIF(TRIM(GRADES),''),'__NULL__') id,
                                  COALESCE(NULLIF(TRIM(GRADES),''),'Non renseigné') label,COUNT(*) total
                            FROM personnel GROUP BY id,label ORDER BY total DESC LIMIT 10")->fetchAll();

require __DIR__ . '/partials/layout.php';
?>

<div class="personnel-hero">
  <div>
    <span class="eyebrow"><i class="bi bi-diagram-3"></i> Référentiel organisationnel</span>
    <h2>Tableau de bord du personnel</h2>
    <p>Visualisez les effectifs, gérez les sites et appartenances, puis organisez librement les colonnes du registre.</p>
  </div>
  <div class="hero-actions">
    <?php if ($canWrite): ?>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#personnelModal" data-mode="create"><i class="bi bi-person-plus"></i> Nouveau personnel</button>
    <form method="post" class="d-inline" onsubmit="return confirm('Synchroniser tous les libellés SITE et ENTITE ?');">
      <input type="hidden" name="action" value="sync_labels">
      <button class="btn btn-outline-primary"><i class="bi bi-arrow-repeat"></i> Synchroniser les libellés</button>
    </form>
    <?php endif; ?>
  </div>
</div>

<div class="personnel-kpis">
  <article><span class="kpi-icon blue"><i class="bi bi-people"></i></span><div><small>Effectif total</small><strong><?php echo number_format($stats['total'],0,',',' '); ?></strong></div></article>
  <article><span class="kpi-icon green"><i class="bi bi-geo-alt"></i></span><div><small>Sites occupés</small><strong><?php echo $stats['sites']; ?></strong></div></article>
  <article><span class="kpi-icon violet"><i class="bi bi-building"></i></span><div><small>Entités actives</small><strong><?php echo $stats['entites']; ?></strong></div></article>
  <article><span class="kpi-icon amber"><i class="bi bi-award"></i></span><div><small>Grades renseignés</small><strong><?php echo $stats['grades']; ?></strong></div></article>
  <article><span class="kpi-icon red"><i class="bi bi-person-exclamation"></i></span><div><small>Sans matricule</small><strong><?php echo $stats['sansMatricule']; ?></strong></div></article>
  <article><span class="kpi-icon slate"><i class="bi bi-link-45deg"></i></span><div><small>Non rattachés</small><strong><?php echo $stats['nonRattaches']; ?></strong></div></article>
</div>

<div class="row g-4 mb-4">
  <div class="col-xl-7"><div class="card personnel-chart-card"><div class="card-header"><div><span>Effectifs par site</span><small>12 principaux sites · cliquez sur une barre</small></div></div><div class="card-body"><canvas id="personnelSiteChart" height="120"></canvas></div></div></div>
  <div class="col-xl-5"><div class="card personnel-chart-card"><div class="card-header"><div><span>Répartition par grade</span><small>Cliquez sur une portion pour voir les agents</small></div></div><div class="card-body"><canvas id="personnelGradeChart" height="155"></canvas></div></div></div>
</div>
<div class="card personnel-chart-card mb-4"><div class="card-header"><div><span>Principales entités d’affectation</span><small>Effectif classé par appartenance · cliquez sur une barre</small></div></div><div class="card-body"><canvas id="personnelEntityChart" height="80"></canvas></div></div>

<script type="application/json" id="personnelChartData"><?php echo json_encode(array('sites'=>$chartSites,'entities'=>$chartEntities,'grades'=>$chartGrades), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); ?></script>
<script type="application/json" id="personnelCodeSuggestions"><?php echo json_encode($codeSuggestionsParGrade, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); ?></script>

<div class="card personnel-workspace">
  <div class="card-header workspace-header">
    <div><h3>Référentiel du personnel</h3><p>Les modifications sont enregistrées dans le journal d’audit.</p></div>
    <ul class="nav nav-pills" id="personnelTabs" role="tablist">
      <li class="nav-item"><button class="nav-link active" data-bs-toggle="pill" data-bs-target="#tab-personnel"><i class="bi bi-people"></i> Personnel <span><?php echo count($personnels); ?></span></button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-sites"><i class="bi bi-geo-alt"></i> Sites <span><?php echo count($sites); ?></span></button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-appartenances"><i class="bi bi-diagram-2"></i> Appartenances <span><?php echo count($appartenances); ?></span></button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-divisions"><i class="bi bi-building-gear"></i> Divisions <span><?php echo count($divisions); ?></span></button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-fonctions"><i class="bi bi-briefcase"></i> Fonctions <span><?php echo count($fonctions); ?></span></button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-grades"><i class="bi bi-award"></i> Grades <span><?php echo count($grades); ?></span></button></li>
      <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-signataires"><i class="bi bi-pen"></i> Signataires <span><?php echo count($signataires); ?></span></button></li>
    </ul>
  </div>
  <div class="card-body">
    <div class="tab-content">
      <div class="tab-pane fade show active" id="tab-personnel">
        <div class="table-toolbar-note"><i class="bi bi-arrows-move"></i><span>Glissez les en-têtes pour permuter les colonnes. Utilisez <strong>Colonnes</strong> pour afficher/masquer et <strong>Regrouper par</strong> pour créer des groupes dynamiques.</span></div>
        <div class="table-responsive">
        <table id="personnelDynamicTable" class="table table-hover align-middle w-100 dynamic-personnel-table" data-no-datatable="true">
          <thead><tr><th>Code agent</th><th>Noms</th><th>Code site</th><th>Site</th><th>Code entité</th><th>Entité</th><th>Code division</th><th>Division</th><th>Code grade</th><th>Grade</th><th>Code fonction</th><th>Fonction agent</th><th>Matricule</th><th class="no-print" data-orderable="false">Actions</th></tr></thead>
          <tbody>
          <?php foreach ($personnels as $p): ?>
            <tr>
              <td><?php echo h($p['CODE_AGENT']); ?></td><td><strong><?php echo h($p['NOMS']); ?></strong></td><td><?php echo h($p['CODE_SITE']); ?></td><td><?php echo h($p['SITE_REF']); ?></td><td><?php echo h($p['CODE_ENTITE']); ?></td><td><?php echo h($p['ENTITE_REF']); ?></td><td><?php echo h($p['CODE_DIV_REF']); ?></td><td><?php echo h($p['DIVISION_REF']); ?></td><td><?php echo h($p['CODE_GRADE']); ?></td><td><?php echo h($p['GRADES']); ?></td><td><?php echo h($p['CODE_FONCTION']); ?></td><td><?php echo h($p['FONCTION_AGENT_REF']); ?></td><td><?php echo h($p['MATRICULE']); ?></td>
              <td class="text-nowrap action-cell no-print">
                <?php if ($canWrite): ?>
                <button class="btn btn-sm btn-soft-primary edit-personnel" data-bs-toggle="modal" data-bs-target="#personnelModal" data-record='<?php echo h(json_encode($p, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)); ?>'><i class="bi bi-pencil-square"></i><span>Modifier</span></button>
                <form method="post" class="d-inline" onsubmit="return confirm('Supprimer définitivement cette fiche ?');"><input type="hidden" name="action" value="delete_personnel"><input type="hidden" name="CODE_AGENT" value="<?php echo h($p['CODE_AGENT']); ?>"><button class="btn btn-sm btn-soft-danger"><i class="bi bi-trash3"></i><span>Supprimer</span></button></form>
                <?php else: ?><span class="badge text-bg-secondary">Lecture</span><?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
        </div>
      </div>

      <div class="tab-pane fade" id="tab-sites">
        <div class="section-actions"><?php if ($canWrite): ?><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#siteModal" data-mode="create"><i class="bi bi-plus-lg"></i> Nouveau site</button><?php endif; ?></div>
        <div class="table-responsive"><table class="table table-hover data-table"><thead><tr><th>ID</th><th>Code / site technique</th><th>Libellé affiché</th><th>Appartenances</th><th>Effectif</th><th class="no-print">Actions</th></tr></thead><tbody>
          <?php foreach ($sites as $s): ?><tr class="effectif-row" tabindex="0" role="button" data-effectif-type="site" data-effectif-id="<?php echo h($s['IdEntite']); ?>" data-effectif-label="<?php echo h($s['Site'] ?: $s['CommentaireEnt']); ?>"><td><?php echo h($s['IdEntite']); ?></td><td><?php echo h($s['Site']); ?></td><td><strong><?php echo h($s['CommentaireEnt']); ?></strong></td><td><?php echo h($s['appartenances']); ?></td><td><span class="badge rounded-pill text-bg-primary"><?php echo h($s['effectif']); ?></span></td><td class="action-cell no-print"><?php if ($canWrite): ?><button class="btn btn-sm btn-soft-primary edit-site" data-bs-toggle="modal" data-bs-target="#siteModal" data-record='<?php echo h(json_encode($s,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)); ?>'><i class="bi bi-pencil-square"></i><span>Modifier</span></button> <form method="post" class="d-inline" onsubmit="return confirm('Supprimer ce site ?');"><input type="hidden" name="action" value="delete_entite"><input type="hidden" name="IdEntite" value="<?php echo h($s['IdEntite']); ?>"><button class="btn btn-sm btn-soft-danger"><i class="bi bi-trash3"></i><span>Supprimer</span></button></form><?php endif; ?></td></tr><?php endforeach; ?>
        </tbody></table></div>
      </div>

      <div class="tab-pane fade" id="tab-appartenances">
        <div class="section-actions"><?php if ($canWrite): ?><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#appartenanceModal" data-mode="create"><i class="bi bi-plus-lg"></i> Nouvelle appartenance</button><?php endif; ?></div>
        <div class="table-responsive"><table class="table table-hover data-table"><thead><tr><th>ID</th><th>Désignation</th><th>Site de rattachement</th><th>Libellé affiché</th><th>Effectif</th><th class="no-print">Actions</th></tr></thead><tbody>
          <?php foreach ($appartenances as $a): ?><tr class="effectif-row" tabindex="0" role="button" data-effectif-type="appartenance" data-effectif-id="<?php echo h($a['IdAppartenance']); ?>" data-effectif-label="<?php echo h($a['DesignationAppart']); ?>"><td><?php echo h($a['IdAppartenance']); ?></td><td><strong><?php echo h($a['DesignationAppart']); ?></strong></td><td><?php echo h($a['site_libelle']); ?></td><td><?php echo h($a['CommentaireAppart']); ?></td><td><span class="badge rounded-pill text-bg-info"><?php echo h($a['effectif']); ?></span></td><td class="action-cell no-print"><?php if ($canWrite): ?><button class="btn btn-sm btn-soft-primary edit-appartenance" data-bs-toggle="modal" data-bs-target="#appartenanceModal" data-record='<?php echo h(json_encode($a,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)); ?>'><i class="bi bi-pencil-square"></i><span>Modifier</span></button> <form method="post" class="d-inline" onsubmit="return confirm('Supprimer cette appartenance ?');"><input type="hidden" name="action" value="delete_appartenance"><input type="hidden" name="IdAppartenance" value="<?php echo h($a['IdAppartenance']); ?>"><button class="btn btn-sm btn-soft-danger"><i class="bi bi-trash3"></i><span>Supprimer</span></button></form><?php endif; ?></td></tr><?php endforeach; ?>
        </tbody></table></div>
      </div>

      <div class="tab-pane fade" id="tab-divisions">
        <div class="section-actions"><?php if ($canWrite): ?><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#divisionModal"><i class="bi bi-plus-lg"></i> Nouvelle division</button><?php endif; ?></div>
        <div class="table-responsive"><table class="table table-hover data-table"><thead><tr><th>ID</th><th>Code</th><th>Division</th><th>Effectif</th><th class="no-print">Actions</th></tr></thead><tbody>
        <?php foreach($divisions as $d): ?><tr class="effectif-row" tabindex="0" role="button" data-effectif-type="division" data-effectif-id="<?php echo h($d['CODE_DIV']); ?>" data-effectif-label="<?php echo h($d['DIVISION']); ?>"><td><?php echo h($d['ID_DIV']); ?></td><td><?php echo h($d['CODE_DIV']); ?></td><td><strong><?php echo h($d['DIVISION']); ?></strong></td><td><span class="badge rounded-pill text-bg-success"><?php echo h($d['effectif']); ?></span></td><td class="action-cell no-print"><?php if($canWrite): ?><button class="btn btn-sm btn-soft-primary edit-division" data-bs-toggle="modal" data-bs-target="#divisionModal" data-record='<?php echo h(json_encode($d,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)); ?>'><i class="bi bi-pencil-square"></i><span>Modifier</span></button> <form method="post" class="d-inline" onsubmit="return confirm('Supprimer cette division ?');"><input type="hidden" name="action" value="delete_division"><input type="hidden" name="ID_DIV" value="<?php echo h($d['ID_DIV']); ?>"><button class="btn btn-sm btn-soft-danger"><i class="bi bi-trash3"></i><span>Supprimer</span></button></form><?php endif; ?></td></tr><?php endforeach; ?>
        </tbody></table></div>
      </div>

      <div class="tab-pane fade" id="tab-fonctions">
        <div class="section-actions"><?php if ($canWrite): ?><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#fonctionModal"><i class="bi bi-plus-lg"></i> Nouvelle fonction</button><?php endif; ?></div>
        <div class="table-responsive"><table class="table table-hover data-table"><thead><tr><th>ID</th><th>Fonction</th><th>Sigle</th><th>État</th><th class="no-print">Actions</th></tr></thead><tbody>
        <?php foreach($fonctions as $f): ?><tr><td><?php echo h($f['id_fonction']); ?></td><td><strong><?php echo h($f['Libelle_Fonction']); ?></strong></td><td><?php echo h($f['Sigle_Fonction']); ?></td><td><?php echo h($f['Etat_Fonction']); ?></td><td class="action-cell no-print"><?php if($canWrite): ?><button class="btn btn-sm btn-soft-primary edit-fonction" data-bs-toggle="modal" data-bs-target="#fonctionModal" data-record='<?php echo h(json_encode($f,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)); ?>'><i class="bi bi-pencil-square"></i><span>Modifier</span></button> <form method="post" class="d-inline" onsubmit="return confirm('Supprimer cette fonction ?');"><input type="hidden" name="action" value="delete_fonction"><input type="hidden" name="id_fonction" value="<?php echo h($f['id_fonction']); ?>"><button class="btn btn-sm btn-soft-danger"><i class="bi bi-trash3"></i><span>Supprimer</span></button></form><?php endif; ?></td></tr><?php endforeach; ?>
        </tbody></table></div>
      <div class="tab-pane fade" id="tab-grades">
        <div class="section-actions"><?php if ($canWrite): ?><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#gradeModal"><i class="bi bi-plus-lg"></i> Nouveau grade</button><?php endif; ?></div>
        <div class="table-responsive"><table class="table table-hover align-middle data-table"><thead><tr><th>ID</th><th>Sigle</th><th>Libellé complet</th><th>Code</th><th>Ordre</th><th>Catégorie</th><th class="no-print">Actions</th></tr></thead><tbody>
        <?php foreach($grades as $g): ?><tr><td><?php echo h($g['id_gr']); ?></td><td><strong><?php echo h($g['sigle_grade']); ?></strong></td><td><?php echo h($g['Libelle_complete']); ?></td><td><?php echo h($g['Code']); ?></td><td><?php echo h($g['ordre_gr']); ?></td><td><?php echo h($g['Categorie']); ?></td><td class="action-cell no-print"><?php if($canWrite): ?><button class="btn btn-sm btn-soft-primary edit-grade" data-bs-toggle="modal" data-bs-target="#gradeModal" data-record='<?php echo h(json_encode($g,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)); ?>'><i class="bi bi-pencil-square"></i><span>Modifier</span></button> <form method="post" class="d-inline" onsubmit="return confirm('Supprimer ce grade ?');"><input type="hidden" name="action" value="delete_grade"><input type="hidden" name="id_gr" value="<?php echo h($g['id_gr']); ?>"><button class="btn btn-sm btn-soft-danger"><i class="bi bi-trash3"></i><span>Supprimer</span></button></form><?php endif; ?></td></tr><?php endforeach; ?>
        </tbody></table></div>
      </div>
      <div class="tab-pane fade" id="tab-signataires">
        <div class="section-actions"><?php if ($canManageSignataires): ?><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#signataireModal"><i class="bi bi-plus-lg"></i> Nouveau signataire</button><?php endif; ?></div>
        <div class="table-responsive"><table class="table table-hover align-middle data-table"><thead><tr><th>Nom complet</th><th>Qualité / fonction</th><th>Ordre</th><th>État</th><th class="no-print">Actions</th></tr></thead><tbody>
        <?php foreach($signataires as $sg): ?><tr><td><strong><?php echo h($sg['nom_complet']); ?></strong></td><td><?php echo h($sg['qualite']); ?></td><td><?php echo h($sg['ordre_affichage']); ?></td><td><?php echo $sg['actif']?'<span class="badge text-bg-success">Actif</span>':'<span class="badge text-bg-secondary">Inactif</span>'; ?></td><td class="action-cell no-print"><?php if($canManageSignataires): ?><button class="btn btn-sm btn-soft-primary edit-signataire" data-bs-toggle="modal" data-bs-target="#signataireModal" data-record='<?php echo h(json_encode($sg,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)); ?>'><i class="bi bi-pencil-square"></i><span>Modifier</span></button> <form method="post" class="d-inline" onsubmit="return confirm('Supprimer ce signataire ?');"><input type="hidden" name="action" value="delete_signataire"><input type="hidden" name="id" value="<?php echo h($sg['id']); ?>"><button class="btn btn-sm btn-soft-danger"><i class="bi bi-trash3"></i><span>Supprimer</span></button></form><?php endif; ?></td></tr><?php endforeach; ?>
        <?php if(empty($signataires)): ?><tr><td colspan="5" class="text-center text-muted">Aucun signataire enregistré.</td></tr><?php endif; ?>
        </tbody></table></div>
      </div>
      </div>
    </div>
  </div>
</div>

<?php if ($canWrite): ?>

<div class="modal fade" id="effectifDetailModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-xl modal-dialog-scrollable"><div class="modal-content"><div class="modal-header"><div><h5 class="modal-title"><i class="bi bi-people-fill"></i> Détail de l’effectif</h5><div class="text-muted small" id="effectifDetailSubtitle"></div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><div class="d-flex align-items-center justify-content-between gap-3 mb-3"><div class="effectif-total-card"><span>Effectif total</span><strong id="effectifDetailCount">0</strong></div><button type="button" class="btn btn-outline-primary btn-sm" id="effectifPrintBtn"><i class="bi bi-printer"></i> Imprimer la liste</button></div><div class="table-responsive"><table class="table table-hover align-middle" id="effectifDetailTable"><thead><tr><th>Code agent</th><th>Noms</th><th>Site</th><th>Entité</th><th>Division</th><th>Grade</th><th>Code fonction</th><th>Fonction agent</th><th>Matricule</th></tr></thead><tbody></tbody></table></div></div></div></div></div>

<div class="modal fade" id="personnelModal" tabindex="-1"><div class="modal-dialog modal-xl modal-dialog-scrollable"><form method="post" class="modal-content"><div class="modal-header"><div><h5 class="modal-title">Fiche du personnel</h5><small>Le site et l’entité textuels seront renseignés automatiquement.</small></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" name="action" value="save_personnel"><input type="hidden" name="OLD_CODE_AGENT" id="OLD_CODE_AGENT"><div class="row g-3">
  <div class="col-md-3"><label class="form-label">Code agent *</label><input class="form-control" type="number" min="1" name="CODE_AGENT" id="CODE_AGENT" required><div id="gradeCodeSuggestion" class="grade-code-suggestion mt-2" hidden><div><span class="suggestion-label">Dernier code pour <strong id="gradeCodeName">ce grade</strong></span><span id="lastGradeAgentCode" class="suggestion-last">—</span></div><div><span class="suggestion-label">Code suivant disponible</span><button type="button" id="applyNextAgentCode" class="suggestion-next" title="Utiliser ce code"><span id="nextGradeAgentCode">—</span><i class="bi bi-arrow-down-circle"></i></button></div></div></div>
  <div class="col-md-9"><label class="form-label">Noms complets *</label><input class="form-control" name="NOMS" id="NOMS" maxlength="150" required></div>
  <div class="col-md-6"><label class="form-label">Site *</label><select class="form-select" name="CODE_SITE" id="CODE_SITE" required><option value="">Sélectionner…</option><?php foreach ($sites as $s): ?><option value="<?php echo h($s['IdEntite']); ?>"><?php echo h($s['Site'] . ' [' . $s['IdEntite'] . ']'); ?></option><?php endforeach; ?></select><div class="form-text">Alimente automatiquement personnel.SITE depuis entite.Site.</div></div>
  <div class="col-md-6"><label class="form-label">Entité / appartenance *</label><select class="form-select" name="CODE_ENTITE" id="CODE_ENTITE" required><option value="">Sélectionner…</option><?php foreach ($appartenances as $a): ?><option value="<?php echo h($a['IdAppartenance']); ?>" data-site="<?php echo h($a['Entite']); ?>"><?php echo h($a['DesignationAppart'] . ' — Entite=' . $a['Entite'] . ' [' . $a['IdAppartenance'] . ']'); ?></option><?php endforeach; ?></select><div class="form-text">Alimente automatiquement personnel.ENTITE depuis appartenance.Entite.</div></div>
  <div class="col-12"><label class="form-label">Division</label><select class="form-select" name="ID_DIV" id="ID_DIV"><option value="">Non affectée</option><?php foreach ($divisions as $d): ?><option value="<?php echo h($d['ID_DIV']); ?>" data-code="<?php echo h($d['CODE_DIV']); ?>"><?php echo h($d['DIVISION'] . ' [' . $d['CODE_DIV'] . ']'); ?></option><?php endforeach; ?></select><div class="form-text">Le code et le libellé de la division sont remplis automatiquement depuis la table division.</div></div>
  <div class="col-md-7"><label class="form-label">Grade</label><select class="form-select" name="ID_GRADE" id="ID_GRADE"><option value="">Non affecté</option><?php foreach ($grades as $g): ?><option value="<?php echo h($g['id_gr']); ?>" data-code="<?php echo h($g['Code']); ?>" data-sigle="<?php echo h($g['sigle_grade']); ?>"><?php echo h(($g['sigle_grade'] ?: '—') . ' — ' . $g['Libelle_complete'] . ' [' . $g['Code'] . ']'); ?></option><?php endforeach; ?></select><div class="form-text">CODE_GRADE et GRADES sont renseignés automatiquement depuis la table grade.</div></div><div class="col-md-7"><label class="form-label">Fonction de l’agent</label><select class="form-select js-searchable-function" name="CODE_FONCTION" id="CODE_FONCTION" data-search-placeholder="Rechercher une fonction…"><option value="">Non affectée</option><?php foreach ($fonctions as $f): ?><option value="<?php echo h($f['id_fonction']); ?>" data-libelle="<?php echo h($f['Libelle_Fonction']); ?>"><?php echo h(($f['Sigle_Fonction'] ? $f['Sigle_Fonction'] . ' — ' : '') . $f['Libelle_Fonction']); ?></option><?php endforeach; ?></select><div class="form-text">CODE_FONCTION et FONCTION_AGENT sont renseignés automatiquement depuis la table fonction.</div></div><div class="col-md-5"><label class="form-label">Matricule</label><input class="form-control" name="MATRICULE" id="MATRICULE" maxlength="50"></div>
</div></div><div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button><button class="btn btn-primary"><i class="bi bi-check2-circle"></i> Enregistrer</button></div></form></div></div>

<div class="modal fade" id="siteModal" tabindex="-1"><div class="modal-dialog"><form method="post" class="modal-content"><div class="modal-header"><h5 class="modal-title">Site / entité géographique</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" name="action" value="save_entite"><input type="hidden" name="IdEntite" id="IdEntite"><div class="mb-3"><label class="form-label">Code ou désignation technique *</label><input class="form-control" name="Site" id="Site" maxlength="45" required></div><div><label class="form-label">Libellé institutionnel</label><textarea class="form-control" name="CommentaireEnt" id="CommentaireEnt" rows="3"></textarea><div class="form-text">Le champ personnel.SITE est alimenté directement par la valeur Site ci-dessus.</div></div></div><div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button><button class="btn btn-primary"><i class="bi bi-check2-circle"></i> Enregistrer les données</button></div></form></div></div>

<div class="modal fade" id="appartenanceModal" tabindex="-1"><div class="modal-dialog modal-lg"><form method="post" class="modal-content"><div class="modal-header"><h5 class="modal-title">Entité d’appartenance</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" name="action" value="save_appartenance"><input type="hidden" name="IdAppartenance" id="IdAppartenance"><div class="row g-3"><div class="col-12"><label class="form-label">Désignation *</label><input class="form-control" name="DesignationAppart" id="DesignationAppart" maxlength="200" required></div><div class="col-12"><label class="form-label">Site de rattachement *</label><select class="form-select" name="Entite" id="AppEntite" required><option value="">Sélectionner…</option><?php foreach ($sites as $s): ?><option value="<?php echo h($s['IdEntite']); ?>"><?php echo h($s['CommentaireEnt'] ?: $s['Site']); ?></option><?php endforeach; ?></select></div><div class="col-12"><label class="form-label">Libellé institutionnel</label><textarea class="form-control" name="CommentaireAppart" id="CommentaireAppart" rows="3"></textarea><div class="form-text">Le champ personnel.ENTITE est alimenté directement par appartenance.Entite.</div></div></div></div><div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button><button class="btn btn-primary"><i class="bi bi-check2-circle"></i> Enregistrer les données</button></div></form></div></div>

<div class="modal fade" id="divisionModal" tabindex="-1"><div class="modal-dialog"><form method="post" class="modal-content"><div class="modal-header"><h5 class="modal-title">Division</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" name="action" value="save_division"><input type="hidden" name="OLD_ID_DIV" id="OLD_ID_DIV"><div class="row g-3"><div class="col-md-4"><label class="form-label">ID *</label><input type="number" min="1" class="form-control" name="ID_DIV" id="DIV_ID_DIV" required></div><div class="col-md-4"><label class="form-label">Code *</label><input type="number" min="1" class="form-control" name="CODE_DIV" id="DIV_CODE_DIV" required></div><div class="col-12"><label class="form-label">Libellé *</label><input class="form-control" name="DIVISION" id="DIV_DIVISION" maxlength="150" required></div></div></div><div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button><button class="btn btn-primary"><i class="bi bi-check2-circle"></i> Enregistrer les données</button></div></form></div></div>


<div class="modal fade" id="gradeModal" tabindex="-1"><div class="modal-dialog modal-lg"><form method="post" class="modal-content"><div class="modal-header"><h5 class="modal-title">Grade</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" name="action" value="save_grade"><input type="hidden" name="id_gr" id="id_gr"><div class="row g-3"><div class="col-md-3"><label class="form-label">Sigle</label><input class="form-control" name="sigle_grade" id="sigle_grade" maxlength="10"></div><div class="col-md-3"><label class="form-label">Code</label><input type="number" class="form-control" name="Code" id="GradeCode"></div><div class="col-md-2"><label class="form-label">Ordre</label><input type="number" min="1" class="form-control" name="ordre_gr" id="ordre_gr"></div><div class="col-12"><label class="form-label">Libellé complet *</label><textarea class="form-control" name="Libelle_complete" id="Libelle_complete" rows="2" required></textarea></div><div class="col-12"><label class="form-label">Catégorie</label><input class="form-control" name="Categorie" id="Categorie" maxlength="45"></div><div class="col-12"><label class="form-label">Commentaire</label><textarea class="form-control" name="Commentaire" id="GradeCommentaire" rows="2"></textarea></div></div></div><div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button><button class="btn btn-primary"><i class="bi bi-check2-circle"></i> Enregistrer les données</button></div></form></div></div>

<div class="modal fade" id="signataireModal" tabindex="-1"><div class="modal-dialog"><form method="post" class="modal-content"><div class="modal-header"><h5 class="modal-title">Signataire</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" name="action" value="save_signataire"><input type="hidden" name="id" id="signataire_id"><div class="mb-3"><label class="form-label">Nom complet *</label><input class="form-control" name="nom_complet" id="signataire_nom" required></div><div class="mb-3"><label class="form-label" for="signataire_qualite">Qualité / fonction *</label><select class="form-select js-searchable-function" name="qualite" id="signataire_qualite" required data-search-placeholder="Rechercher une qualité ou une fonction…"><option value="">— Sélectionner une fonction —</option><?php foreach($qualitesFonction as $qf): ?><option value="<?php echo h($qf['valeur']); ?>"><?php echo h($qf['valeur']); ?><?php echo $qf['sigle']!=='' ? ' — '.h($qf['sigle']) : ''; ?><?php echo ($qf['etat']!=='' && !in_array(strtolower($qf['etat']),array('1','actif','active'),true)) ? ' (inactive)' : ''; ?></option><?php endforeach; ?></select><div class="form-text">Liste chargée directement depuis la table <code>fonction</code>.</div></div><div class="row g-3"><div class="col-md-6"><label class="form-label">Ordre d’affichage</label><input type="number" class="form-control" name="ordre_affichage" id="signataire_ordre" value="0"></div><div class="col-md-6 d-flex align-items-end"><div class="form-check mb-2"><input class="form-check-input" type="checkbox" name="actif" value="1" id="signataire_actif" checked><label class="form-check-label" for="signataire_actif">Signataire actif</label></div></div></div></div><div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button><button class="btn btn-primary"><i class="bi bi-check2-circle"></i> Enregistrer les données</button></div></form></div></div>

<div class="modal fade" id="printSignataireModal" tabindex="-1"><div class="modal-dialog modal-lg modal-dialog-scrollable"><div class="modal-content"><div class="modal-header"><div><h5 class="modal-title"><i class="bi bi-pen"></i> Choisir le signataire</h5><div class="text-muted small">Le nom et la qualité seront placés au bas du document imprimé.</div></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body">
<?php if ($canWrite): ?><div class="d-flex justify-content-end mb-3"><button type="button" class="btn btn-success" data-bs-toggle="collapse" data-bs-target="#quickSignerForm" aria-expanded="false" aria-controls="quickSignerForm"><i class="bi bi-person-plus"></i> Ajouter un signataire</button></div><div class="collapse mb-4" id="quickSignerForm"><form method="post" class="card card-body border-success"><input type="hidden" name="action" value="save_signataire"><input type="hidden" name="retour_impression" value="1"><div class="row g-3"><div class="col-md-6"><label class="form-label">Nom complet *</label><input class="form-control" name="nom_complet" required autocomplete="name" placeholder="Nom du signataire"></div><div class="col-md-6"><label class="form-label">Qualité / fonction *</label><select class="form-select js-searchable-function" name="qualite" required data-search-placeholder="Rechercher une qualité ou une fonction…"><option value="">— Sélectionner une fonction —</option><?php foreach($qualitesFonction as $qf): ?><option value="<?php echo h($qf['valeur']); ?>"><?php echo h($qf['valeur']); ?><?php echo $qf['sigle']!=='' ? ' — '.h($qf['sigle']) : ''; ?><?php echo ($qf['etat']!=='' && !in_array(strtolower($qf['etat']),array('1','actif','active'),true)) ? ' (inactive)' : ''; ?></option><?php endforeach; ?></select><div class="form-text">Données provenant de la table <code>fonction</code>.</div></div><div class="col-md-4"><label class="form-label">Ordre d’affichage</label><input type="number" class="form-control" name="ordre_affichage" value="0" min="0"></div><div class="col-md-4 d-flex align-items-end"><div class="form-check mb-2"><input class="form-check-input" type="checkbox" name="actif" value="1" id="quick_signataire_actif" checked><label class="form-check-label" for="quick_signataire_actif">Signataire actif</label></div></div><div class="col-md-4 d-flex align-items-end justify-content-md-end"><button class="btn btn-success w-100"><i class="bi bi-check2-circle"></i> Enregistrer et choisir</button></div></div></form></div><?php endif; ?>
<div class="table-responsive"><table class="table table-hover align-middle"><thead><tr><th style="width:48px"></th><th>Nom complet</th><th>Qualité / fonction</th></tr></thead><tbody id="printSignataireRows"><?php foreach($signataires as $sg): if(!$sg['actif']) continue; ?><tr class="signataire-choice" role="button" tabindex="0" data-id="<?php echo h($sg['id']); ?>" data-nom="<?php echo h($sg['nom_complet']); ?>" data-qualite="<?php echo h($sg['qualite']); ?>"><td><input class="form-check-input" type="radio" name="print_signataire" value="<?php echo h($sg['id']); ?>"></td><td><strong><?php echo h($sg['nom_complet']); ?></strong></td><td><?php echo h($sg['qualite']); ?></td></tr><?php endforeach; ?><?php if(empty(array_filter($signataires,function($x){return !empty($x['actif']);}))): ?><tr><td colspan="3" class="text-center text-muted">Aucun signataire actif. Utilisez le bouton « Ajouter un signataire » ci-dessus.</td></tr><?php endif; ?></tbody></table></div></div><div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button><button type="button" class="btn btn-primary" id="confirmPrintWithSigner"><i class="bi bi-printer"></i> Imprimer</button></div></div></div></div>

<div class="modal fade" id="fonctionModal" tabindex="-1"><div class="modal-dialog modal-lg"><form method="post" class="modal-content"><div class="modal-header"><h5 class="modal-title">Fonction</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" name="action" value="save_fonction"><input type="hidden" name="id_fonction" id="id_fonction"><div class="row g-3"><div class="col-md-8"><label class="form-label">Libellé *</label><input class="form-control" name="Libelle_Fonction" id="Libelle_Fonction" required></div><div class="col-md-4"><label class="form-label">Sigle</label><input class="form-control" name="Sigle_Fonction" id="Sigle_Fonction"></div><div class="col-md-4"><label class="form-label">État</label><input class="form-control" name="Etat_Fonction" id="Etat_Fonction" value="1"></div><div class="col-12"><label class="form-label">Commentaires</label><textarea class="form-control" name="Commentaires_Fonction" id="Commentaires_Fonction" rows="2"></textarea></div><div class="col-12"><label class="form-label">Observations</label><textarea class="form-control" name="Obs_Fonction" id="Obs_Fonction" rows="2"></textarea></div></div></div><div class="modal-footer"><button type="button" class="btn btn-light" data-bs-dismiss="modal">Annuler</button><button class="btn btn-primary"><i class="bi bi-check2-circle"></i> Enregistrer les données</button></div></form></div></div>
<?php endif; ?>

<?php require __DIR__ . '/partials/footer.php'; ?>
