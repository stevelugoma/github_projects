-- Mise à niveau des référentiels Division et Fonction
CREATE TABLE IF NOT EXISTS division (
  ID_DIV INT(2) NOT NULL,
  DIVISION VARCHAR(55) DEFAULT NULL,
  CODE_DIV INT(3) DEFAULT NULL,
  PRIMARY KEY (ID_DIV),
  KEY idx_division_code (CODE_DIV)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

CREATE TABLE IF NOT EXISTS fonction (
  id_fonction INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  Libelle_Fonction VARCHAR(200) NOT NULL,
  Sigle_Fonction VARCHAR(45) DEFAULT NULL,
  Commentaires_Fonction TEXT,
  Obs_Fonction TEXT,
  Etat_Fonction VARCHAR(10) DEFAULT NULL,
  PRIMARY KEY (id_fonction)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Synchronisation conforme aux règles demandées
UPDATE personnel p
LEFT JOIN entite e ON e.IdEntite=p.CODE_SITE
LEFT JOIN appartenance a ON a.IdAppartenance=p.CODE_ENTITE
SET p.SITE=COALESCE(NULLIF(e.Site,''),p.SITE),
    p.ENTITE=COALESCE(CAST(a.Entite AS CHAR),p.ENTITE);
