<?php
$pageTitle = 'Congés & Missions';
$activePage = 'conges.php';
require_once __DIR__ . '/helpers.php';

$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    exigerPermission('conges.manage','conges.php');
    $action = $_POST['action'] ?? '';
    if ($action === 'save') {
        $numId = trim($_POST['numero_identification'] ?? '');
        $data = [
            'numero_identification' => $numId,
            'type'       => trim($_POST['type'] ?? 'annuel'),
            'date_debut' => $_POST['date_debut'] ?? null,
            'date_fin'   => $_POST['date_fin'] ?? null,
            'reference'  => trim($_POST['reference'] ?? ''),
            'statut'     => $_POST['statut'] ?? 'validee',
        ];
        if (!$numId || !$data['date_debut'] || !$data['date_fin']) {
            flash('error', 'Agent, date de début et date de fin sont obligatoires.');
            redirect('conges.php');
        }
        $id = (int)($_POST['id'] ?? 0);
        if ($id) {
            $old = $pdo->prepare("SELECT * FROM conge WHERE id=?"); $old->execute([$id]); $oldRow=$old->fetch();
            $pdo->prepare("UPDATE conge SET numero_identification=?,type=?,date_debut=?,date_fin=?,reference=?,statut=? WHERE id=?")
                ->execute([$numId,$data['type'],$data['date_debut'],$data['date_fin'],$data['reference'],$data['statut'],$id]);
            logAudit('update','conge',$id,$oldRow,$data);
            flash('success','Congé modifié.');
        } else {
            $pdo->prepare("INSERT INTO conge (numero_identification,type,date_debut,date_fin,reference,statut) VALUES (?,?,?,?,?,?)")
                ->execute([$numId,$data['type'],$data['date_debut'],$data['date_fin'],$data['reference'],$data['statut']]);
            logAudit('create','conge',$pdo->lastInsertId(),null,$data);
            flash('success','Congé enregistré.');
        }
        // recalculer les présences sur la période du congé
        recalculerPresences($data['date_debut'], $data['date_fin']);
        redirect('conges.php');
    }
    if ($action === 'delete') {
        $id = (int)$_POST['id'];
        $pdo->prepare("DELETE FROM conge WHERE id=?")->execute([$id]);
        logAudit('delete','conge',$id);
        flash('success','Congé supprimé.');
        redirect('conges.php');
    }
}
if (($_GET['action'] ?? '') === 'delete') {
    exigerPermission('conges.manage','conges.php');
    $pdo->prepare("DELETE FROM conge WHERE id=?")->execute([(int)$_GET['id']]);
    logAudit('delete','conge',(int)$_GET['id']);
    flash('success','Congé supprimé.');
    redirect('conges.php');
}

$editId = ($_GET['action'] ?? '') === 'edit' ? (int)($_GET['id'] ?? 0) : 0;
$editRow = null;
if ($editId) {
    $s = $pdo->prepare("SELECT * FROM conge WHERE id=?"); $s->execute([$editId]);
    $editRow = $s->fetch();
}
$agents = $pdo->query("SELECT numero_identification, nom_complet FROM agents WHERE statut=1 ORDER BY nom_complet")->fetchAll();

// filtres
$fDateD = $_GET['date_debut'] ?? ''; $fDateF = $_GET['date_fin'] ?? '';
$fNum   = trim($_GET['numero'] ?? ''); $fType = $_GET['type'] ?? '';
$fEtat  = $_GET['etat'] ?? '';

$where = []; $params = [];
if ($fNum)  { $where[] = "c.numero_identification LIKE ?"; $params[] = "%$fNum%"; }
if ($fType) { $where[] = "c.type=?"; $params[] = $fType; }
$today = date('Y-m-d');
if ($fEtat === 'en_cours') { $where[] = "c.statut='validee' AND c.date_debut<=? AND c.date_fin>=?"; $params[]=$today; $params[]=$today; }
if ($fEtat === 'avenir')   { $where[] = "c.date_debut>?"; $params[]=$today; }
if ($fEtat === 'termine')  { $where[] = "c.date_fin<?"; $params[]=$today; }
$whereSql = $where ? ('WHERE '.implode(' AND ',$where)) : '';

include __DIR__ . '/partials/layout.php';
?>

<!-- Stats rapides -->
<?php
$enCours = (int)$pdo->query("SELECT COUNT(*) FROM conge WHERE statut='validee' AND date_debut<=CURDATE() AND date_fin>=CURDATE()")->fetchColumn();
$aVenir  = (int)$pdo->query("SELECT COUNT(*) FROM conge WHERE date_debut>CURDATE()")->fetchColumn();
?>
<div class="stat-grid">
    <div class="stat-card purple"><div class="stat-icon">🏖️</div><div><div class="stat-value"><?php echo $enCours; ?></div><div class="stat-label">En congé aujourd'hui</div></div></div>
    <div class="stat-card blue"><div class="stat-icon">📅</div><div><div class="stat-value"><?php echo $aVenir; ?></div><div class="stat-label">Congés à venir</div></div></div>
</div>

<div class="card">
    <div class="card-header"><h2><?php echo $editRow ? '✏️ Modifier' : '➕ Nouveau congé / mission'; ?></h2></div>
    <form method="post" action="conges.php">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?php echo (int)($editRow['id'] ?? 0); ?>">
        <div class="form-grid">
            <div class="form-group">
                <label>Agent *</label>
                <select name="numero_identification" required>
                    <option value="">— Sélectionner —</option>
                    <?php foreach ($agents as $ag): ?>
                        <option value="<?php echo h($ag['numero_identification']); ?>" <?php echo ($editRow['numero_identification']??'')===$ag['numero_identification']?'selected':''; ?>><?php echo h($ag['numero_identification'].' — '.($ag['nom_complet']?:'sans nom')); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Type</label>
                <select name="type">
                    <?php foreach (['annuel'=>'Congé annuel','maladie'=>'Congé maladie','maternité'=>'Maternité','paternité'=>'Paternité','exceptionnel'=>'Exceptionnel','mission'=>'Mission','autre'=>'Autre'] as $k=>$v): ?>
                        <option value="<?php echo $k; ?>" <?php echo ($editRow['type']??'annuel')===$k?'selected':''; ?>><?php echo $v; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group"><label>Date début *</label><input type="date" name="date_debut" required value="<?php echo h($editRow['date_debut'] ?? ''); ?>"></div>
            <div class="form-group"><label>Date fin *</label><input type="date" name="date_fin" required value="<?php echo h($editRow['date_fin'] ?? ''); ?>"></div>
            <div class="form-group"><label>Référence / Décision</label><input type="text" name="reference" value="<?php echo h($editRow['reference'] ?? ''); ?>" placeholder="N° de la décision..."></div>
            <div class="form-group">
                <label>Statut</label>
                <select name="statut">
                    <?php foreach (['validee'=>'Validé','en_attente'=>'En attente','rejetee'=>'Rejeté'] as $k=>$v): ?>
                        <option value="<?php echo $k; ?>" <?php echo ($editRow['statut']??'validee')===$k?'selected':''; ?>><?php echo $v; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-success">💾 Enregistrer</button>
            <?php if ($editRow): ?><a href="conges.php" class="btn btn-secondary">Annuler</a><?php endif; ?>
        </div>
    </form>
</div>

<div class="filters">
    <form method="get">
        <div class="form-group"><label>N° / Matricule</label><input type="search" name="numero" value="<?php echo h($fNum); ?>"></div>
        <div class="form-group">
            <label>Type</label>
            <select name="type"><option value="">Tous</option>
                <?php foreach (['annuel'=>'Congé annuel','maladie'=>'Maladie','maternité'=>'Maternité','mission'=>'Mission','exceptionnel'=>'Exceptionnel'] as $k=>$v): ?>
                    <option value="<?php echo $k; ?>" <?php echo $fType===$k?'selected':''; ?>><?php echo $v; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label>État</label>
            <select name="etat"><option value="">Tous</option>
                <option value="en_cours" <?php echo $fEtat==='en_cours'?'selected':''; ?>>En cours</option>
                <option value="avenir" <?php echo $fEtat==='avenir'?'selected':''; ?>>À venir</option>
                <option value="termine" <?php echo $fEtat==='termine'?'selected':''; ?>>Terminé</option>
            </select>
        </div>
        <div class="form-group" style="flex:0"><button type="submit" class="btn">🔎 Filtrer</button><a href="conges.php" class="btn btn-outline btn-sm">Reset</a></div>
    </form>
</div>

<?php
$stmt = $pdo->prepare("SELECT c.*, a.nom_complet, a.service
    FROM conge c JOIN agents a ON a.numero_identification=c.numero_identification
    $whereSql ORDER BY c.date_debut DESC");
$stmt->execute($params);
$conges = $stmt->fetchAll();
?>
<div class="card">
    <div class="card-header"><h2>Liste des congés & missions <span class="text-muted">(<?php echo count($conges); ?>)</span></h2></div>
    <div class="table-wrap">
        <table class="data-table">
            <thead><tr><th>N°</th><th>Agent</th><th>Service</th><th>Type</th><th>Du</th><th>Au</th><th>Référence</th><th>État</th><th class="actions">Actions</th></tr></thead>
            <tbody>
            <?php if (empty($conges)): ?>
                <tr class="empty-row"><td colspan="9">Aucun congé enregistré.</td></tr>
            <?php else: foreach ($conges as $c):
                $etat = ($c['date_fin'] < $today) ? 'Terminé' : (($c['date_debut'] > $today) ? 'À venir' : 'En cours');
                $etatBadge = $etat==='En cours'?'badge-green':($etat==='À venir'?'badge-blue':'badge-gray');
            ?>
                <tr>
                    <td class="num"><?php echo h($c['numero_identification']); ?></td>
                    <td><?php echo h($c['nom_complet'] ?: '—'); ?></td>
                    <td><?php echo h($c['service'] ?: '—'); ?></td>
                    <td><span class="badge badge-purple"><?php echo h($c['type']); ?></span></td>
                    <td><?php echo formatDateFr($c['date_debut']); ?></td>
                    <td><?php echo formatDateFr($c['date_fin']); ?></td>
                    <td><small><?php echo h($c['reference'] ?: '—'); ?></small></td>
                    <td><span class="badge <?php echo $etatBadge; ?>"><?php echo $etat; ?></span></td>
                    <td class="actions">
                        <a href="conges.php?action=edit&id=<?php echo (int)$c['id']; ?>" title="Modifier">✏️</a>
                        <a href="conges.php?action=delete&id=<?php echo (int)$c['id']; ?>" title="Supprimer" onclick="return confirm('Supprimer ce congé ?')">🗑️</a>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/partials/footer.php'; ?>
