<?php
$pageTitle = 'Gestion des agents';
$activePage = 'agents.php';
require_once __DIR__ . '/helpers.php';

$pdo = db();
$action = $_GET['action'] ?? 'list';

// Référentiel unique des fonctions : tous les champs « Fonction » de l'application
// doivent proposer les valeurs de la table fonction au lieu d'une saisie libre.
$fonctionsReferentiel = [];
$appartenancesReferentiel = [];
$sitesReferentiel = [];
try {
    $appartenancesReferentiel = $pdo->query("SELECT IdAppartenance, DesignationAppart, CommentaireAppart FROM appartenance ORDER BY COALESCE(NULLIF(TRIM(DesignationAppart),''), CommentaireAppart)")->fetchAll();
    $sitesReferentiel = $pdo->query("SELECT IdEntite, Site, CommentaireEnt FROM entite WHERE Site IS NOT NULL AND TRIM(Site)<>'' ORDER BY Site")->fetchAll();
} catch (Throwable $e) {
    $appartenancesReferentiel = [];
    $sitesReferentiel = [];
}
try {
    $fonctionsReferentiel = $pdo->query("SELECT id_fonction, Libelle_Fonction, Sigle_Fonction, Etat_Fonction FROM fonction WHERE Libelle_Fonction IS NOT NULL AND TRIM(Libelle_Fonction)<>'' ORDER BY Libelle_Fonction")
                               ->fetchAll();
} catch (Throwable $e) {
    // Compatibilité pendant une installation/migration incomplète.
    $fonctionsReferentiel = [];
}


// ============================================================
//  TRAITEMENT DES ACTIONS
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    exigerPermission('agents.manage','agents.php');

    // ---- Ajout / modification ----
    if (($_POST['action'] ?? '') === 'save') {
        $numeroId = trim($_POST['numero_identification'] ?? '');
        if ($numeroId === '') {
            flash('error', 'Le numéro d\'identification est obligatoire (RG-01).');
            redirect('agents.php?action=' . ($_POST['id_existant'] ? 'edit&id=' . urlencode($_POST['id_existant']) : 'add'));
        }

        $data = [
            'numero_identification' => $numeroId,
            'nom_complet' => trim($_POST['nom_complet'] ?? ''),
            'postnom'     => trim($_POST['postnom'] ?? ''),
            'prenom'      => trim($_POST['prenom'] ?? ''),
            'sexe'        => $_POST['sexe'] ?? '',
            'telephone'   => trim($_POST['telephone'] ?? ''),
            'fonction'    => trim($_POST['fonction'] ?? ''),
            'service'     => trim($_POST['service'] ?? ''),
            'site'        => trim($_POST['site'] ?? ''),
            'date_engagement' => ($_POST['date_engagement'] ?? '') ?: null,
            'numero_carte'    => trim($_POST['numero_carte'] ?? ''),
            'statut'          => isset($_POST['statut']) ? 1 : 0,
        ];

        $idExistant = $_POST['id_existant'] ?? '';
        try {
            if ($idExistant !== '') {
                // Modification (RG-02)
                $old = $pdo->prepare("SELECT * FROM agents WHERE numero_identification=?");
                $old->execute([$idExistant]);
                $oldRow = $old->fetch();

                $stmt = $pdo->prepare("UPDATE agents SET
                    numero_identification=:numero_identification, nom_complet=:nom_complet,
                    postnom=:postnom, prenom=:prenom, sexe=:sexe, telephone=:telephone,
                    fonction=:fonction, service=:service, site=:site,
                    date_engagement=:date_engagement, numero_carte=:numero_carte, statut=:statut
                    WHERE numero_identification=:old_id");
                $data['old_id'] = $idExistant;
                $stmt->execute($data);
                logAudit('update', 'agent', $numeroId, $oldRow, $data);
                flash('success', "Agent « $numeroId » modifié avec succès.");
            } else {
                // Création (RG-01, F-AG-06 : unicité)
                $check = $pdo->prepare("SELECT 1 FROM agents WHERE numero_identification=?");
                $check->execute([$numeroId]);
                if ($check->fetch()) {
                    flash('error', "Un agent avec le numéro « $numeroId » existe déjà (REC-02).");
                    redirect('agents.php?action=add');
                }
                $stmt = $pdo->prepare("INSERT INTO agents
                    (numero_identification, nom_complet, postnom, prenom, sexe, telephone,
                     fonction, service, site, date_engagement, numero_carte, statut)
                    VALUES
                    (:numero_identification, :nom_complet, :postnom, :prenom, :sexe, :telephone,
                     :fonction, :service, :site, :date_engagement, :numero_carte, :statut)");
                $stmt->execute($data);
                logAudit('create', 'agent', $numeroId, null, $data);
                flash('success', "Agent « $numeroId » créé avec succès (REC-01).");
            }
        } catch (PDOException $e) {
            flash('error', 'Erreur : ' . $e->getMessage());
        }
        redirect('agents.php');
    }

    // ---- Suppression définitive ----
    if (($_POST['action'] ?? '') === 'delete') {
        $numeroId = trim($_POST['numero_identification'] ?? '');
        if ($numeroId !== '') {
            $old = $pdo->prepare("SELECT * FROM agents WHERE numero_identification=?");
            $old->execute([$numeroId]);
            $oldRow = $old->fetch();
            if ($oldRow) {
                try {
                    $pdo->beginTransaction();
                    foreach (['presence_journaliere','passage_brut','absence','conge','affectation_horaire'] as $table) {
                        $pdo->prepare("DELETE FROM `$table` WHERE numero_identification=?")->execute([$numeroId]);
                    }
                    $pdo->prepare("DELETE FROM agents WHERE numero_identification=?")->execute([$numeroId]);
                    $pdo->commit();
                    logAudit('delete', 'agent', $numeroId, $oldRow, null);
                    flash('success', "Agent « $numeroId » et ses données associées supprimés.");
                } catch (Throwable $e) {
                    if ($pdo->inTransaction()) $pdo->rollBack();
                    flash('error', 'Suppression impossible : ' . $e->getMessage());
                }
            }
        }
        redirect('agents.php');
    }

    // ---- Import Excel/CSV ----
    if (($_POST['action'] ?? '') === 'import' && !empty($_FILES['fichier']['tmp_name'])) {
        importerAgents($_FILES['fichier']);
        redirect('agents.php');
    }
}

// Désactivation / réactivation (RG-09 : suppression logique)
if ($action === 'toggle' && isset($_GET['id'])) {
    exigerPermission('agents.manage','agents.php');
    $stmt = $pdo->prepare("SELECT statut, nom_complet FROM agents WHERE numero_identification=?");
    $stmt->execute([$_GET['id']]);
    $a = $stmt->fetch();
    if ($a) {
        $newStatut = $a['statut'] ? 0 : 1;
        $pdo->prepare("UPDATE agents SET statut=? WHERE numero_identification=?")
            ->execute([$newStatut, $_GET['id']]);
        logAudit($newStatut ? 'reactivate' : 'deactivate', 'agent', $_GET['id']);
        flash('success', "Agent " . ($newStatut ? 'réactivé' : 'désactivé') . " : " . $a['nom_complet']);
    }
    redirect('agents.php');
}

// ============================================================
//  FONCTION D'IMPORT DES AGENTS (FACE2000)
// ============================================================
function importerAgents($file) {
    global $pdo;
    $tmp = $file['tmp_name'];
    $nomFichier = $file['name'];
    $ext = strtolower(pathinfo($nomFichier, PATHINFO_EXTENSION));

    try {
        if ($ext === 'xlsx') {
            $rows = XlsxReader::read($tmp);
        } elseif ($ext === 'csv') {
            // essai auto du séparateur
            $rows = XlsxReader::readCsv($tmp, ',');
            if (empty($rows)) $rows = XlsxReader::readCsv($tmp, ';');
        } else {
            flash('error', "Format non supporté. Utilisez .xlsx ou .csv.");
            return;
        }
    } catch (Throwable $e) {
        flash('error', "Lecture du fichier impossible : " . $e->getMessage());
        return;
    }

    if (empty($rows)) { flash('error', "Le fichier est vide."); return; }

    // Détection des colonnes (les en-têtes FACE2000 varient en casse/accents)
    // XlsxReader::read() et readCsv() renvoient déjà des lignes associatives
    // dont les clés sont les en-têtes. Il faut donc détecter les colonnes
    // à partir des clés, et non à partir des valeurs de la première ligne.
    $first = array_keys($rows[0]);
    $col = detecterColonnesAgents($first);

    $lus = 0; $acceptes = 0; $rejets = [];
    foreach ($rows as $i => $r) {
        $lus++;
        $numId = nettoyerVal($r[$col['ID Number']] ?? null);
        $nom   = nettoyerVal($r[$col['Name']] ?? null);

        if ($numId === '' || $numId === null) {
            $rejets[] = "Ligne " . ($i + 2) . " : numéro d'identification manquant";
            continue;
        }
        // nom vide => anomalie signalée mais on garde l'agent (RG-15)
        $carte = nettoyerVal($r[$col['Card']] ?? null);
        $groupe = nettoyerVal($r[$col['Group']] ?? null);
        $privilege = nettoyerVal($r[$col['Privilege']] ?? null);
        $dept = nettoyerVal($r[$col['Department']] ?? null);

        // carte = 0 signifie pas de carte
        if ($carte === '0' || $carte === '') $carte = null;

        try {
            $stmt = $pdo->prepare("INSERT INTO agents
                (numero_identification, nom_complet, numero_carte, groupe_device,
                 privilege_device, departement_source, statut)
                VALUES (?,?,?,?,?,?,1)
                ON DUPLICATE KEY UPDATE
                  nom_complet=COALESCE(NULLIF(VALUES(nom_complet),''), nom_complet),
                  numero_carte=VALUES(numero_carte),
                  groupe_device=VALUES(groupe_device),
                  privilege_device=VALUES(privilege_device),
                  departement_source=VALUES(departement_source)");
            $stmt->execute([$numId, $nom ?: null, $carte, $groupe, $privilege, $dept]);
            $acceptes++;
        } catch (PDOException $e) {
            $rejets[] = "Ligne " . ($i + 2) . " ($numId) : " . $e->getMessage();
        }
    }

    // enregistrement du lot
    $lot = $pdo->prepare("INSERT INTO import_lot
        (nom_fichier, type_import, utilisateur_id, nb_lues, nb_acceptees, nb_rejetees, rapport)
        VALUES (?, 'agents', ?, ?, ?, ?, ?)");
    $rapport = $rejets ? implode("\n", array_slice($rejets, 0, 50)) : '';
    $lot->execute([$nomFichier, $_SESSION['user']['id'] ?? null, $lus, $acceptes, count($rejets), $rapport]);
    logAudit('import', 'agent', null, null, "Fichier: $nomFichier — $acceptes/$lus acceptés");

    $msg = "Import terminé : <b>$acceptes</b> agent(s) importé(s) sur <b>$lus</b> lignes lues.";
    if ($rejets) $msg .= " <b>" . count($rejets) . "</b> rejet(s).";
    flash($rejets ? 'warning' : 'success', $msg);
}

/** Détecte les colonnes FACE2000 en tolérant les variations d'en-tête. */
function detecterColonnesAgents($first) {
    $map = [];
    foreach ($first as $key => $val) {
        $norm = strtolower(trim((string)$val));
        $norm = preg_replace('/[^a-z]/', '', $norm);
        if (in_array($norm, ['idnumber', 'id', 'identification', 'numeroidentification', 'matricule', 'numero'], true) && !isset($map['ID Number'])) {
            $map['ID Number'] = $val;
        } elseif (in_array($norm, ['name', 'nom', 'nomcomplet'], true) && !isset($map['Name'])) {
            $map['Name'] = $val;
        } elseif ($norm === 'card' && !isset($map['Card'])) {
            $map['Card'] = $val;
        } elseif ($norm === 'group' && !isset($map['Group'])) {
            $map['Group'] = $val;
        } elseif ($norm === 'privilege' && !isset($map['Privilege'])) {
            $map['Privilege'] = $val;
        } elseif ($norm === 'department' && !isset($map['Department'])) {
            $map['Department'] = $val;
        }
    }
    // fallback par position si rien trouvé
    if (!isset($map['ID Number'])) $map['ID Number'] = isset($first[1]) ? $first[1] : 'ID Number';
    if (!isset($map['Name']))      $map['Name']      = isset($first[2]) ? $first[2] : 'Name';
    if (!isset($map['Card']))      $map['Card']      = isset($first[3]) ? $first[3] : 'Card';
    if (!isset($map['Group']))     $map['Group']     = isset($first[4]) ? $first[4] : 'Group';
    if (!isset($map['Privilege'])) $map['Privilege'] = isset($first[5]) ? $first[5] : 'Privilege';
    if (!isset($map['Department']))$map['Department']= isset($first[0]) ? $first[0] : 'Department';
    return $map;
}

function nettoyerVal($v) {
    if ($v === null) return '';
    return trim((string)$v);
}

include __DIR__ . '/partials/layout.php';

// ============================================================
//  VUES
// ============================================================
if ($action === 'add' || $action === 'edit'):
    $agent = null;
    if ($action === 'edit' && isset($_GET['id'])) {
        $stmt = $pdo->prepare("SELECT * FROM agents WHERE numero_identification=?");
        $stmt->execute([$_GET['id']]);
        $agent = $stmt->fetch();
        if (!$agent) { flash('error', 'Agent introuvable.'); redirect('agents.php'); }
    }
?>
<div class="card">
    <div class="card-header">
        <h2><?php echo $agent ? '✏️ Modifier l\'agent' : '➕ Nouvel agent'; ?></h2>
        <a href="agents.php" class="btn btn-sm btn-outline">← Retour à la liste</a>
    </div>
    <form method="post" action="agents.php">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id_existant" value="<?php echo h($agent['numero_identification'] ?? ''); ?>">
        <div class="form-grid">
            <div class="form-group">
                <label>N° identification * <span class="text-danger">(clé unique — RG-01)</span></label>
                <input type="text" name="numero_identification" required
                       value="<?php echo h($agent['numero_identification'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>Nom complet</label>
                <input type="text" name="nom_complet" value="<?php echo h($agent['nom_complet'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>Postnom</label>
                <input type="text" name="postnom" value="<?php echo h($agent['postnom'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>Prénom</label>
                <input type="text" name="prenom" value="<?php echo h($agent['prenom'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>Sexe</label>
                <select name="sexe">
                    <option value="">—</option>
                    <option value="M" <?php echo (($agent['sexe'] ?? '')==='M')?'selected':''; ?>>Masculin</option>
                    <option value="F" <?php echo (($agent['sexe'] ?? '')==='F')?'selected':''; ?>>Féminin</option>
                </select>
            </div>
            <div class="form-group">
                <label>Téléphone</label>
                <input type="text" name="telephone" value="<?php echo h($agent['telephone'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label for="agent_fonction">Fonction</label>
                <select name="fonction" id="agent_fonction" class="js-searchable-function" data-search-placeholder="Rechercher une fonction…">
                    <option value="">— Non affectée —</option>
                    <?php
                    $fonctionActuelle = trim((string)($agent['fonction'] ?? ''));
                    $fonctionTrouvee = false;
                    foreach ($fonctionsReferentiel as $fonctionRef):
                        $libelleFonction = trim((string)$fonctionRef['Libelle_Fonction']);
                        $estSelectionnee = ($fonctionActuelle !== '' && strcasecmp($fonctionActuelle, $libelleFonction) === 0);
                        if ($estSelectionnee) $fonctionTrouvee = true;
                        $etatFonction = strtolower(trim((string)($fonctionRef['Etat_Fonction'] ?? '')));
                        $inactive = ($etatFonction !== '' && !in_array($etatFonction, ['1','actif','active'], true));
                    ?>
                        <option value="<?php echo h($libelleFonction); ?>" <?php echo $estSelectionnee ? 'selected' : ''; ?>>
                            <?php echo h((!empty($fonctionRef['Sigle_Fonction']) ? $fonctionRef['Sigle_Fonction'].' — ' : '').$libelleFonction.($inactive ? ' (inactive)' : '')); ?>
                        </option>
                    <?php endforeach; ?>
                    <?php if ($fonctionActuelle !== '' && !$fonctionTrouvee): ?>
                        <option value="<?php echo h($fonctionActuelle); ?>" selected><?php echo h($fonctionActuelle); ?> (ancienne valeur)</option>
                    <?php endif; ?>
                </select>
                <small>Liste chargée directement depuis la table <code>fonction</code>.</small>
            </div>
            <div class="form-group">
                <label for="agent_service">Service / appartenance</label>
                <select name="service" id="agent_service" class="js-searchable-function" data-search-placeholder="Rechercher un service…">
                    <option value="">— Non affecté —</option>
                    <?php
                    $serviceActuel = trim((string)($agent['service'] ?? ''));
                    $serviceTrouve = false;
                    foreach ($appartenancesReferentiel as $app):
                        $libelleService = trim((string)($app['DesignationAppart'] ?: $app['CommentaireAppart']));
                        if ($libelleService === '') continue;
                        $sel = $serviceActuel !== '' && strcasecmp($serviceActuel, $libelleService) === 0;
                        if ($sel) $serviceTrouve = true;
                    ?>
                        <option value="<?php echo h($libelleService); ?>" <?php echo $sel?'selected':''; ?>><?php echo h($libelleService); ?></option>
                    <?php endforeach; ?>
                    <?php if ($serviceActuel !== '' && !$serviceTrouve): ?><option value="<?php echo h($serviceActuel); ?>" selected><?php echo h($serviceActuel); ?> (ancienne valeur)</option><?php endif; ?>
                </select>
                <small>Liste chargée depuis la table <code>appartenance</code>.</small>
            </div>
            <div class="form-group">
                <label for="agent_site">Site / entité</label>
                <select name="site" id="agent_site" class="js-searchable-function" data-search-placeholder="Rechercher un site…">
                    <option value="">— Non affecté —</option>
                    <?php
                    $siteActuel = trim((string)($agent['site'] ?? ''));
                    $siteTrouve = false;
                    foreach ($sitesReferentiel as $siteRef):
                        $libelleSite = trim((string)$siteRef['Site']);
                        $sel = $siteActuel !== '' && strcasecmp($siteActuel, $libelleSite) === 0;
                        if ($sel) $siteTrouve = true;
                    ?>
                        <option value="<?php echo h($libelleSite); ?>" <?php echo $sel?'selected':''; ?>><?php echo h($libelleSite); ?></option>
                    <?php endforeach; ?>
                    <?php if ($siteActuel !== '' && !$siteTrouve): ?><option value="<?php echo h($siteActuel); ?>" selected><?php echo h($siteActuel); ?> (ancienne valeur)</option><?php endif; ?>
                </select>
                <small>Liste chargée depuis la table <code>entite</code>.</small>
            </div>
            <div class="form-group">
                <label>Date d'engagement</label>
                <input type="date" name="date_engagement" value="<?php echo h($agent['date_engagement'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>N° carte</label>
                <input type="text" name="numero_carte" value="<?php echo h($agent['numero_carte'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>Statut</label>
                <label style="font-weight:normal;display:flex;align-items:center;gap:8px;margin-top:6px">
                    <input type="checkbox" name="statut" value="1" <?php echo (!isset($agent) || $agent['statut']) ? 'checked' : ''; ?>>
                    Agent actif
                </label>
            </div>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-success">💾 Enregistrer</button>
            <a href="agents.php" class="btn btn-secondary">Annuler</a>
        </div>
    </form>
</div>

<?php elseif ($action === 'view' && isset($_GET['id'])):
    $stmt = $pdo->prepare("SELECT * FROM agents WHERE numero_identification=?");
    $stmt->execute([$_GET['id']]);
    $a = $stmt->fetch();
    if (!$a) { flash('error', 'Agent introuvable.'); redirect('agents.php'); }

    // stats de présence de l'agent
    $stats = $pdo->prepare("SELECT
        COUNT(*) AS jours,
        SUM(retard_minutes>0) AS retards,
        SUM(retard_minutes) AS total_min_retard,
        MIN(date_presence) AS premier_jour,
        MAX(date_presence) AS dernier_jour
        FROM presence_journaliere WHERE numero_identification=?");
    $stats->execute([$_GET['id']]);
    $s = $stats->fetch();
?>
<div class="card">
    <div class="card-header">
        <h2>Fiche agent — <?php echo h($a['nom_complet'] ?: '—'); ?></h2>
        <div class="card-actions">
            <a href="agents.php?action=edit&id=<?php echo urlencode($a['numero_identification']); ?>" class="btn btn-sm">✏️ Modifier</a>
            <a href="agents.php" class="btn btn-sm btn-outline">← Retour</a>
        </div>
    </div>
    <div style="display:flex;gap:30px;flex-wrap:wrap">
        <dl class="detail-grid" style="flex:1;min-width:280px">
            <dt>N° identification</dt><dd class="num"><?php echo h($a['numero_identification']); ?></dd>
            <dt>Nom complet</dt><dd><?php echo h($a['nom_complet'] ?: '—'); ?></dd>
            <dt>Sexe</dt><dd><?php echo $a['sexe']==='M'?'Masculin':($a['sexe']==='F'?'Féminin':'—'); ?></dd>
            <dt>Fonction</dt><dd><?php echo h($a['fonction'] ?: '—'); ?></dd>
            <dt>Service</dt><dd><?php echo h($a['service'] ?: '—'); ?></dd>
            <dt>Site</dt><dd><?php echo h($a['site'] ?: '—'); ?></dd>
            <dt>Téléphone</dt><dd><?php echo h($a['telephone'] ?: '—'); ?></dd>
            <dt>Date d'engagement</dt><dd><?php echo formatDateFr($a['date_engagement']); ?></dd>
            <dt>N° carte</dt><dd><?php echo h($a['numero_carte'] ?: '—'); ?></dd>
            <dt>Groupe terminal</dt><dd><?php echo h($a['groupe_device'] ?: '—'); ?></dd>
            <dt>Privilège terminal</dt><dd><?php echo h($a['privilege_device'] ?: '—'); ?></dd>
            <dt>Statut</dt><dd><?php echo $a['statut'] ? badgeStatut('present') : '<span class="badge badge-gray">Inactif</span>'; ?></dd>
        </dl>
        <div style="flex:1;min-width:240px">
            <h3 style="margin-bottom:12px;color:var(--c-primary)">📊 Synthèse de présence</h3>
            <div class="stat-grid" style="grid-template-columns:1fr 1fr">
                <div class="stat-card blue"><div class="stat-icon">📅</div><div><div class="stat-value"><?php echo (int)$s['jours']; ?></div><div class="stat-label">Jours pointés</div></div></div>
                <div class="stat-card yellow"><div class="stat-icon">⏰</div><div><div class="stat-value"><?php echo (int)$s['retards']; ?></div><div class="stat-label">Retards</div></div></div>
                <div class="stat-card red"><div class="stat-icon">⏱️</div><div><div class="stat-value"><?php echo (int)$s['total_min_retard']; ?></div><div class="stat-label">Min. de retard</div></div></div>
                <div class="stat-card gray"><div class="stat-icon">📆</div><div><div class="stat-value" style="font-size:14px"><?php echo formatDateFr($s['premier_jour']); ?></div><div class="stat-label">1er pointage</div></div></div>
            </div>
        </div>
    </div>
</div>

<?php else: // LISTE ?>

<?php
// ---- FILTRES ----
$where = []; $params = [];
$fNum   = trim($_GET['numero'] ?? '');
$fNom   = trim($_GET['nom'] ?? '');
$fSexe  = $_GET['sexe'] ?? '';
$fServ  = trim($_GET['service'] ?? '');
$fStatut= $_GET['statut'] ?? '';

if ($fNum !== '')   { $where[] = "numero_identification LIKE ?"; $params[] = "%$fNum%"; }
if ($fNom !== '')   { $where[] = "nom_complet LIKE ?";            $params[] = "%$fNom%"; }
if ($fSexe !== '')  { $where[] = "sexe=?";                        $params[] = $fSexe; }
if ($fServ !== '')  { $where[] = "service LIKE ?";                $params[] = "%$fServ%"; }
if ($fStatut !== ''){ $where[] = "statut=" . ((int)$fStatut); }

$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

// Chargement complet : aucun LIMIT côté serveur.
// DataTables affiche toutes les lignes par défaut et conserve la recherche/tri.
$countStmt = $pdo->prepare("SELECT COUNT(*) FROM agents $whereSql");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();

$stmt = $pdo->prepare("SELECT * FROM agents $whereSql ORDER BY nom_complet");
$stmt->execute($params);
$agents = $stmt->fetchAll();

// liste des services existants pour le filtre
$services = $pdo->query("SELECT DISTINCT service FROM agents WHERE service IS NOT NULL AND service<>'' ORDER BY service")->fetchAll(PDO::FETCH_COLUMN);
?>
<div class="filters">
    <form method="get">
        <div class="form-group"><label>N° identification</label><input type="search" name="numero" value="<?php echo h($fNum); ?>"></div>
        <div class="form-group"><label>Nom</label><input type="search" name="nom" value="<?php echo h($fNom); ?>"></div>
        <div class="form-group">
            <label>Sexe</label>
            <select name="sexe"><option value="">Tous</option>
                <option value="M" <?php echo $fSexe==='M'?'selected':''; ?>>Masculin</option>
                <option value="F" <?php echo $fSexe==='F'?'selected':''; ?>>Féminin</option>
            </select>
        </div>
        <div class="form-group">
            <label>Service</label>
            <select name="service"><option value="">Tous</option>
                <?php foreach ($services as $s): ?>
                    <option value="<?php echo h($s); ?>" <?php echo $fServ===$s?'selected':''; ?>><?php echo h($s); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Statut</label>
            <select name="statut"><option value="">Tous</option>
                <option value="1" <?php echo $fStatut==='1'?'selected':''; ?>>Actif</option>
                <option value="0" <?php echo $fStatut==='0'?'selected':''; ?>>Inactif</option>
            </select>
        </div>
        <div class="form-group" style="flex:0">
            <button type="submit" class="btn">🔎 Filtrer</button>
            <a href="agents.php" class="btn btn-outline btn-sm">Reset</a>
        </div>
    </form>
</div>

<div class="card">
    <div class="card-header">
        <h2>Liste des agents <span class="text-muted">(<?php echo $total; ?>)</span></h2>
        <div class="card-actions">
            <?php if (aPermission('agents.manage')): ?>
                <button type="button" class="btn btn-sm" onclick="document.getElementById('importBox').style.display='block'">📥 Importer Excel</button>
                <a href="agents.php?action=add" class="btn btn-sm btn-success">➕ Nouvel agent</a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Zone d'import -->
    <div id="importBox" style="display:none;margin-bottom:16px">
        <div class="upload-zone">
            <form method="post" enctype="multipart/form-data" style="display:flex;flex-direction:column;gap:12px;align-items:center">
                <input type="hidden" name="action" value="import">
                <p>📁 Sélectionnez le fichier <b>AGENTS.xlsx</b> exporté du terminal XI FACE2000</p>
                <input type="file" name="fichier" accept=".xlsx,.csv" required>
                <button type="submit" class="btn">🚀 Importer les agents</button>
                <small class="text-muted">Colonnes reconnues : Department, ID Number, Name, Card, Group, Privilege</small>
            </form>
        </div>
    </div>

    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>N° Identification</th>
                    <th>Nom complet</th>
                    <th>Sexe</th>
                    <th>Fonction</th>
                    <th>Service</th>
                    <th>Site</th>
                    <th>Statut</th>
                    <th class="actions">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($agents)): ?>
                <tr class="empty-row"><td colspan="8">Aucun agent trouvé. Importez le fichier <b>AGENTS.xlsx</b> pour commencer.</td></tr>
            <?php else: foreach ($agents as $a): ?>
                <tr>
                    <td class="num"><?php echo h($a['numero_identification']); ?></td>
                    <td><?php echo h($a['nom_complet'] ?: '<i class="text-muted">sans nom</i>'); ?></td>
                    <td><?php echo $a['sexe'] ? h($a['sexe']) : '—'; ?></td>
                    <td><?php echo h($a['fonction'] ?: '—'); ?></td>
                    <td><?php echo h($a['service'] ?: '—'); ?></td>
                    <td><?php echo h($a['site'] ?: '—'); ?></td>
                    <td><?php echo $a['statut'] ? '<span class="badge badge-green">Actif</span>' : '<span class="badge badge-gray">Inactif</span>'; ?></td>
                    <td class="actions">
                        <a href="agents.php?action=view&id=<?php echo urlencode($a['numero_identification']); ?>" title="Voir">👁️</a>
                        <?php if (aPermission('agents.manage')): ?>
                            <a href="agents.php?action=edit&id=<?php echo urlencode($a['numero_identification']); ?>" title="Modifier">✏️</a>
                            <a href="agents.php?action=toggle&id=<?php echo urlencode($a['numero_identification']); ?>" title="<?php echo $a['statut']?'Désactiver':'Réactiver'; ?>"
                               onclick="return confirm('<?php echo $a['statut']?'Désactiver':'Réactiver'; ?> cet agent ?')">
                                <?php echo $a['statut'] ? '🚫' : '✅'; ?>
                            </a>
                            <form method="post" action="agents.php" style="display:inline" onsubmit="return confirm('Supprimer définitivement cet agent et toutes ses présences, absences, congés et pointages ? Cette action est irréversible.');">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="numero_identification" value="<?php echo h($a['numero_identification']); ?>">
                                <button type="submit" class="btn-link" title="Supprimer définitivement" aria-label="Supprimer définitivement">🗑️</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>

</div>
<?php endif; ?>

<?php include __DIR__ . '/partials/footer.php'; ?>
