<?php
$pageTitle = 'Horaires';
$activePage = 'horaires.php';
require_once __DIR__ . '/helpers.php';

$pdo = db();
$action = $_GET['action'] ?? 'list';

// Mise à niveau automatique pour les installations existantes.
function gpEnsureAllaitementColumns($pdo) {
    $columns = array(
        'horaire_base_id' => 'INT NULL',
        'duree_minutes' => 'INT NULL',
        'modalite' => "VARCHAR(30) NULL",
        'observation' => 'TEXT NULL'
    );
    foreach ($columns as $name => $definition) {
        $st = $pdo->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='affectation_horaire' AND COLUMN_NAME=?");
        $st->execute(array($name));
        if (!(int)$st->fetchColumn()) {
            $pdo->exec("ALTER TABLE affectation_horaire ADD COLUMN `" . $name . "` " . $definition);
        }
    }
}
gpEnsureAllaitementColumns($pdo);

function gpMinutesToTime($minutes) {
    $minutes = (($minutes % 1440) + 1440) % 1440;
    return sprintf('%02d:%02d:00', floor($minutes / 60), $minutes % 60);
}
function gpTimeToMinutes($time) {
    $parts = explode(':', $time);
    return ((int)$parts[0] * 60) + (int)$parts[1];
}


// ============================================================
//  TRAITEMENT : Horaires généraux / service / site
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_horaire') {
    exigerPermission('horaires.manage','horaires.php');
    $data = [
        'libelle'  => trim($_POST['libelle'] ?? ''),
        'portee'   => $_POST['portee'] ?? 'general',
        'cible'    => trim($_POST['cible'] ?? ''),
        'heure_entree' => $_POST['heure_entree'] ?? '08:00',
        'heure_sortie' => $_POST['heure_sortie'] ?? '16:00',
        'tolerance_min'=> (int)($_POST['tolerance_min'] ?? 0),
        'jours_ouvrables' => $_POST['jours_ouvrables'] ?? '12345',
        'date_effet'=> $_POST['date_effet'] ?: null,
        'actif'     => isset($_POST['actif']) ? 1 : 0,
    ];
    if ($data['libelle'] === '') { flash('error','Le libellé est obligatoire.'); redirect('horaires.php'); }
    if ($data['portee'] === 'general') $data['cible'] = null;

    $id = (int)($_POST['id'] ?? 0);
    if ($id) {
        $pdo->prepare("UPDATE horaire SET libelle=?,portee=?,cible=?,heure_entree=?,heure_sortie=?,tolerance_min=?,jours_ouvrables=?,date_effet=?,actif=? WHERE id=?")
            ->execute([$data['libelle'],$data['portee'],$data['cible'],$data['heure_entree'].':00',$data['heure_sortie'].':00',$data['tolerance_min'],$data['jours_ouvrables'],$data['date_effet'],$data['actif'],$id]);
        logAudit('update','horaire',$id,null,$data);
        flash('success','Horaire modifié.');
    } else {
        $pdo->prepare("INSERT INTO horaire (libelle,portee,cible,heure_entree,heure_sortie,tolerance_min,jours_ouvrables,date_effet,actif) VALUES (?,?,?,?,?,?,?,?,?)")
            ->execute([$data['libelle'],$data['portee'],$data['cible'],$data['heure_entree'].':00',$data['heure_sortie'].':00',$data['tolerance_min'],$data['jours_ouvrables'],$data['date_effet'],$data['actif']]);
        logAudit('create','horaire',$pdo->lastInsertId(),null,$data);
        flash('success','Horaire créé.');
    }
    redirect('horaires.php');
}

// ============================================================
//  TRAITEMENT : Heures d'allaitement (création et mise à jour)
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_allaitement') {
    $idAff = (int)($_POST['id_affectation'] ?? 0);
    $numero = trim($_POST['numero_identification'] ?? '');
    $horaireBaseId = (int)($_POST['horaire_base_id'] ?? 0);
    $dateDebut = $_POST['date_debut'] ?? '';
    $dateFin = $_POST['date_fin'] ?? '';
    $duree = (int)($_POST['duree_minutes'] ?? 60);
    $modalite = $_POST['modalite'] ?? 'sortie_anticipee';
    $decision = trim($_POST['decision_ref'] ?? '');
    $observation = trim($_POST['observation'] ?? '');

    $modalitesValides = array('arrivee_tardive','sortie_anticipee','repartie');
    if (!in_array($modalite, $modalitesValides, true)) $modalite = 'sortie_anticipee';

    if ($numero === '' || !$horaireBaseId || $dateDebut === '' || $dateFin === '') {
        flash('error', 'Agente, horaire de base et intervalle de dates sont obligatoires.');
        redirect('horaires.php?action=allaitement' . ($idAff ? '&edit_allaitement='.$idAff : ''));
    }
    if ($dateFin < $dateDebut) {
        flash('error', 'La date de fin doit être postérieure ou égale à la date de début.');
        redirect('horaires.php?action=allaitement' . ($idAff ? '&edit_allaitement='.$idAff : ''));
    }
    if ($duree < 15 || $duree > 180) {
        flash('error', 'La durée quotidienne doit être comprise entre 15 et 180 minutes.');
        redirect('horaires.php?action=allaitement' . ($idAff ? '&edit_allaitement='.$idAff : ''));
    }

    $stmtAgent = $pdo->prepare("SELECT nom_complet, sexe FROM agents WHERE numero_identification=? AND statut=1");
    $stmtAgent->execute(array($numero));
    $agente = $stmtAgent->fetch();
    if (!$agente) {
        flash('error', 'Agente introuvable ou inactive.');
        redirect('horaires.php?action=allaitement');
    }

    $stmtBase = $pdo->prepare("SELECT * FROM horaire WHERE id=? AND actif=1");
    $stmtBase->execute(array($horaireBaseId));
    $base = $stmtBase->fetch();
    if (!$base) {
        flash('error', 'Horaire de base introuvable ou inactif.');
        redirect('horaires.php?action=allaitement');
    }

    $check = $pdo->prepare("SELECT id FROM affectation_horaire
        WHERE numero_identification=? AND date_debut<=? AND date_fin>=? AND id<>?");
    $check->execute(array($numero, $dateFin, $dateDebut, $idAff));
    if ($check->fetch()) {
        flash('error', 'Cet intervalle chevauche déjà une autre affectation horaire de l\'agente.');
        redirect('horaires.php?action=allaitement' . ($idAff ? '&edit_allaitement='.$idAff : ''));
    }

    $entreeMin = gpTimeToMinutes($base['heure_entree']);
    $sortieMin = gpTimeToMinutes($base['heure_sortie']);
    if ($modalite === 'arrivee_tardive') $entreeMin += $duree;
    elseif ($modalite === 'sortie_anticipee') $sortieMin -= $duree;
    else {
        $debutPart = (int)floor($duree / 2);
        $finPart = $duree - $debutPart;
        $entreeMin += $debutPart;
        $sortieMin -= $finPart;
    }
    if ($sortieMin <= $entreeMin) {
        flash('error', 'La réduction choisie produit un horaire invalide.');
        redirect('horaires.php?action=allaitement' . ($idAff ? '&edit_allaitement='.$idAff : ''));
    }

    $labelsModalite = array(
        'arrivee_tardive' => 'arrivée différée',
        'sortie_anticipee' => 'sortie anticipée',
        'repartie' => 'répartie entrée/sortie'
    );
    $nom = trim($agente['nom_complet'] ? $agente['nom_complet'] : $numero);
    $libelle = 'Allaitement - ' . $nom . ' - ' . $duree . ' min';
    $motif = "Heure d'allaitement : " . $duree . ' min/jour, modalité ' . $labelsModalite[$modalite]
        . '. Horaire de base : ' . $base['libelle'] . '.';

    try {
        $pdo->beginTransaction();
        if ($idAff) {
            $oldStmt = $pdo->prepare("SELECT * FROM affectation_horaire WHERE id=? AND type='allaitement'");
            $oldStmt->execute(array($idAff));
            $old = $oldStmt->fetch();
            if (!$old) throw new Exception("Autorisation d'allaitement introuvable.");
            $horaireId = (int)$old['horaire_id'];
            $pdo->prepare("UPDATE horaire SET libelle=?,portee='individuel',cible=?,heure_entree=?,heure_sortie=?,tolerance_min=?,jours_ouvrables=?,date_effet=?,actif=1 WHERE id=?")
                ->execute(array($libelle,$numero,gpMinutesToTime($entreeMin),gpMinutesToTime($sortieMin),(int)$base['tolerance_min'],$base['jours_ouvrables'],$dateDebut,$horaireId));
            $pdo->prepare("UPDATE affectation_horaire SET numero_identification=?,horaire_id=?,type='allaitement',date_debut=?,date_fin=?,motif=?,decision_ref=?,valide=1,horaire_base_id=?,duree_minutes=?,modalite=?,observation=? WHERE id=?")
                ->execute(array($numero,$horaireId,$dateDebut,$dateFin,$motif,$decision,$horaireBaseId,$duree,$modalite,$observation,$idAff));
            $affId = $idAff;
            $message = "Heures d'allaitement mises à jour.";
        } else {
            $stmtH = $pdo->prepare("INSERT INTO horaire (libelle,portee,cible,heure_entree,heure_sortie,tolerance_min,jours_ouvrables,date_effet,actif) VALUES (?,?,?,?,?,?,?,?,1)");
            $stmtH->execute(array($libelle,'individuel',$numero,gpMinutesToTime($entreeMin),gpMinutesToTime($sortieMin),(int)$base['tolerance_min'],$base['jours_ouvrables'],$dateDebut));
            $horaireId = (int)$pdo->lastInsertId();
            $stmtA = $pdo->prepare("INSERT INTO affectation_horaire (numero_identification,horaire_id,type,date_debut,date_fin,motif,decision_ref,valide,horaire_base_id,duree_minutes,modalite,observation) VALUES (?,?,?,?,?,?,?,1,?,?,?,?)");
            $stmtA->execute(array($numero,$horaireId,'allaitement',$dateDebut,$dateFin,$motif,$decision,$horaireBaseId,$duree,$modalite,$observation));
            $affId = (int)$pdo->lastInsertId();
            $message = "Heures d'allaitement enregistrées.";
        }
        $pdo->commit();
        logAudit($idAff ? 'update' : 'create','affectation_allaitement',$affId,null,array(
            'numero_identification'=>$numero,'horaire_base_id'=>$horaireBaseId,'duree_minutes'=>$duree,
            'modalite'=>$modalite,'heure_entree'=>gpMinutesToTime($entreeMin),'heure_sortie'=>gpMinutesToTime($sortieMin),
            'date_debut'=>$dateDebut,'date_fin'=>$dateFin,'decision_ref'=>$decision,'observation'=>$observation
        ));
        recalculerPresences($dateDebut, $dateFin);
        flash('success', $message . ' Horaire appliqué : ' . substr(gpMinutesToTime($entreeMin),0,5) . ' - ' . substr(gpMinutesToTime($sortieMin),0,5) . '.');
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('error', "Impossible d'enregistrer les heures d'allaitement : " . $e->getMessage());
    }
    redirect('horaires.php?action=allaitement');
}

// ============================================================
//  TRAITEMENT : Affectation horaire (allaitement inclus)
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_affectation') {
    exigerPermission('horaires.manage','horaires.php');
    $data = [
        'numero_identification' => trim($_POST['numero_identification'] ?? ''),
        'horaire_id'  => (int)($_POST['horaire_id'] ?? 0),
        'type'        => $_POST['type'] ?? 'individuel',
        'date_debut'  => $_POST['date_debut'] ?? null,
        'date_fin'    => $_POST['date_fin'] ?? null,
        'motif'       => trim($_POST['motif'] ?? ''),
        'decision_ref'=> trim($_POST['decision_ref'] ?? ''),
        'valide'      => isset($_POST['valide']) ? 1 : 0,
    ];
    if (!$data['numero_identification'] || !$data['horaire_id'] || !$data['date_debut'] || !$data['date_fin']) {
        flash('error','Agent, horaire, dates de début et de fin sont obligatoires.');
        redirect('horaires.php?action=affectations');
    }
    // RG-05 : vérifier le non-chevauchement des périodes pour un même agent
    $check = $pdo->prepare("SELECT id FROM affectation_horaire
        WHERE numero_identification=? AND date_debut<=? AND date_fin>=? AND id<>?");
    $idAff = (int)($_POST['id'] ?? 0);
    $check->execute([$data['numero_identification'], $data['date_fin'], $data['date_debut'], $idAff]);
    if ($check->fetch()) {
        flash('error','Les périodes d\'horaire personnalisé ne doivent pas se chevaucher (RG-05).');
        redirect('horaires.php?action=affectations');
    }

    if ($idAff) {
        $pdo->prepare("UPDATE affectation_horaire SET numero_identification=?,horaire_id=?,type=?,date_debut=?,date_fin=?,motif=?,decision_ref=?,valide=? WHERE id=?")
            ->execute([$data['numero_identification'],$data['horaire_id'],$data['type'],$data['date_debut'],$data['date_fin'],$data['motif'],$data['decision_ref'],$data['valide'],$idAff]);
        logAudit('update','affectation_horaire',$idAff,null,$data);
        flash('success','Affectation modifiée.');
    } else {
        $pdo->prepare("INSERT INTO affectation_horaire (numero_identification,horaire_id,type,date_debut,date_fin,motif,decision_ref,valide) VALUES (?,?,?,?,?,?,?,?)")
            ->execute([$data['numero_identification'],$data['horaire_id'],$data['type'],$data['date_debut'],$data['date_fin'],$data['motif'],$data['decision_ref'],$data['valide']]);
        logAudit('create','affectation_horaire',$pdo->lastInsertId(),null,$data);
        flash('success','Affectation d\'horaire créée.');
    }
    redirect('horaires.php?action=affectations');
}

// suppression
if (($_GET['action'] ?? '') === 'del_horaire') {
    $pdo->prepare("DELETE FROM horaire WHERE id=?")->execute([(int)$_GET['id']]);
    logAudit('delete','horaire',(int)$_GET['id']);
    flash('success','Horaire supprimé.');
    redirect('horaires.php');
}
if (($_GET['action'] ?? '') === 'del_aff') {
    $idDel = (int)$_GET['id'];
    $stDel = $pdo->prepare("SELECT horaire_id, type FROM affectation_horaire WHERE id=?");
    $stDel->execute([$idDel]);
    $affDel = $stDel->fetch();
    $pdo->prepare("DELETE FROM affectation_horaire WHERE id=?")->execute([$idDel]);
    if ($affDel && $affDel['type'] === 'allaitement') {
        $pdo->prepare("DELETE FROM horaire WHERE id=? AND portee='individuel'")->execute([(int)$affDel['horaire_id']]);
    }
    logAudit('delete','affectation_horaire',$idDel);
    flash('success','Affectation supprimée.');
    redirect('horaires.php?action=' . (($affDel && $affDel['type'] === 'allaitement') ? 'allaitement' : 'affectations'));
}

// données pour formulaires
$agents = $pdo->query("SELECT numero_identification, nom_complet FROM agents WHERE statut=1 ORDER BY nom_complet")->fetchAll();
$horaires = $pdo->query("SELECT * FROM horaire ORDER BY portee, libelle")->fetchAll();
$editAllaitement = null;
if ($action === 'allaitement' && !empty($_GET['edit_allaitement'])) {
    $stEdit = $pdo->prepare("SELECT af.*, h.heure_entree, h.heure_sortie FROM affectation_horaire af JOIN horaire h ON h.id=af.horaire_id WHERE af.id=? AND af.type='allaitement'");
    $stEdit->execute(array((int)$_GET['edit_allaitement']));
    $editAllaitement = $stEdit->fetch();
}


include __DIR__ . '/partials/layout.php';

$porteeLabels = ['general'=>'Général','service'=>'Service','site'=>'Site','categorie'=>'Catégorie','individuel'=>'Individuel'];

if ($action === 'allaitement'):
    $horairesBase = $pdo->query("SELECT * FROM horaire WHERE actif=1 AND portee<>'individuel' ORDER BY portee, libelle")->fetchAll();
?>
<div class="card">
    <div class="card-header">
        <h2>🤱 Définir les heures d'allaitement</h2>
        <a href="horaires.php" class="btn btn-outline btn-sm">← Horaires</a>
    </div>
    <p class="text-muted">Définissez une réduction quotidienne temporaire. L'application génère automatiquement l'horaire individuel et l'utilise pour calculer les retards pendant la période.</p>
    <div class="alert alert-info">
        <b>Principe de calcul :</b> la durée peut être prise en arrivée différée, en sortie anticipée ou répartie entre l'entrée et la sortie. La durée autorisée et la période doivent correspondre à la décision RH applicable dans votre entreprise.
    </div>

    <form method="post" action="horaires.php">
        <input type="hidden" name="action" value="save_allaitement">
        <input type="hidden" name="id_affectation" value="<?php echo (int)($editAllaitement['id'] ?? 0); ?>">
        <div class="form-grid">
            <div class="form-group">
                <label>Agente concernée *</label>
                <select name="numero_identification" required>
                    <option value="">— Sélectionner —</option>
                    <?php foreach ($agents as $ag): ?>
                        <option value="<?php echo h($ag['numero_identification']); ?>" <?php echo ($editAllaitement && $editAllaitement['numero_identification']===$ag['numero_identification'])?'selected':''; ?>><?php echo h($ag['numero_identification'].' — '.($ag['nom_complet']?:'sans nom')); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Horaire normal de référence *</label>
                <select name="horaire_base_id" id="horaireBase" required>
                    <option value="">— Sélectionner —</option>
                    <?php foreach ($horairesBase as $ho): ?>
                        <option value="<?php echo (int)$ho['id']; ?>" <?php echo ($editAllaitement && (int)$editAllaitement['horaire_base_id']===(int)$ho['id'])?'selected':''; ?> data-entree="<?php echo h(substr($ho['heure_entree'],0,5)); ?>" data-sortie="<?php echo h(substr($ho['heure_sortie'],0,5)); ?>">
                            <?php echo h($ho['libelle'].' ('.formatHeure($ho['heure_entree']).' - '.formatHeure($ho['heure_sortie']).')'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Durée quotidienne accordée *</label>
                <div style="display:flex;gap:8px;align-items:center">
                    <input type="number" id="dureeAllaitement" name="duree_minutes" min="15" max="180" step="15" value="<?php echo (int)($editAllaitement['duree_minutes'] ?? 60); ?>" required>
                    <span class="text-muted">minutes</span>
                </div>
            </div>
            <div class="form-group">
                <label>Modalité *</label>
                <select name="modalite" id="modaliteAllaitement" required>
                    <option value="sortie_anticipee" <?php echo ($editAllaitement && $editAllaitement['modalite']==='sortie_anticipee')?'selected':''; ?>>Sortie anticipée</option>
                    <option value="arrivee_tardive" <?php echo ($editAllaitement && $editAllaitement['modalite']==='arrivee_tardive')?'selected':''; ?>>Arrivée différée</option>
                    <option value="repartie" <?php echo ($editAllaitement && $editAllaitement['modalite']==='repartie')?'selected':''; ?>>Répartie entre entrée et sortie</option>
                </select>
            </div>
            <div class="form-group"><label>Date de début *</label><input type="date" name="date_debut" value="<?php echo h($editAllaitement['date_debut'] ?? ''); ?>" required></div>
            <div class="form-group"><label>Date de fin *</label><input type="date" name="date_fin" value="<?php echo h($editAllaitement['date_fin'] ?? ''); ?>" required></div>
            <div class="form-group"><label>Décision / Référence</label><input type="text" name="decision_ref" value="<?php echo h($editAllaitement['decision_ref'] ?? ''); ?>" placeholder="N° décision RH, note de service..."></div>
            <div class="form-group" style="grid-column:1/-1"><label>Observation</label><textarea name="observation" rows="2" placeholder="Précisions éventuelles..."><?php echo h($editAllaitement['observation'] ?? ''); ?></textarea></div>
        </div>
        <div id="apercuAllaitement" class="alert alert-info" style="margin-top:16px">Sélectionnez un horaire de référence pour afficher l'aperçu.</div>
        <div class="form-actions"><button type="submit" class="btn btn-success"><?php echo $editAllaitement ? '💾 Mettre à jour les heures d\'allaitement' : '💾 Enregistrer les heures d\'allaitement'; ?></button></div>
    </form>
</div>

<?php
$allaitements = $pdo->query("SELECT af.*, a.nom_complet, h.libelle, h.heure_entree, h.heure_sortie
    FROM affectation_horaire af
    JOIN agents a ON a.numero_identification=af.numero_identification
    JOIN horaire h ON h.id=af.horaire_id
    WHERE af.type='allaitement'
    ORDER BY af.date_fin DESC, a.nom_complet")->fetchAll();
?>
<div class="card">
    <div class="card-header"><h2>Autorisations d'allaitement</h2></div>
    <div class="table-wrap">
        <table class="data-table">
            <thead><tr><th>Agente</th><th>Horaire appliqué</th><th>Période</th><th>Décision</th><th>État</th><th>Observation</th><th class="actions">Action</th></tr></thead>
            <tbody>
            <?php if (empty($allaitements)): ?>
                <tr class="empty-row"><td colspan="7">Aucune heure d'allaitement définie.</td></tr>
            <?php else: foreach ($allaitements as $af):
                $today = date('Y-m-d');
                $etat = ($af['date_fin'] < $today) ? 'Expirée' : (($af['date_debut'] > $today) ? 'À venir' : 'Active');
                $etatBadge = $etat==='Active'?'badge-green':($etat==='À venir'?'badge-blue':'badge-gray');
            ?>
                <tr>
                    <td><b><?php echo h($af['nom_complet']); ?></b><br><small class="text-muted"><?php echo h($af['numero_identification']); ?></small></td>
                    <td><?php echo formatHeure($af['heure_entree']).' - '.formatHeure($af['heure_sortie']); ?></td>
                    <td><?php echo formatDateFr($af['date_debut']).' au '.formatDateFr($af['date_fin']); ?></td>
                    <td><?php echo h($af['decision_ref'] ?: '—'); ?></td>
                    <td><span class="badge <?php echo $etatBadge; ?>"><?php echo $etat; ?></span></td>
                    <td><small><?php echo h($af['motif'] ?: '—'); ?></small></td>
                    <td class="actions"><a href="horaires.php?action=allaitement&edit_allaitement=<?php echo (int)$af['id']; ?>" title="Modifier">✏️</a> <a href="horaires.php?action=del_aff&id=<?php echo (int)$af['id']; ?>" onclick="return confirm('Supprimer cette autorisation d’allaitement ?')" title="Supprimer">🗑️</a></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
<script>
(function () {
    var base = document.getElementById('horaireBase');
    var duree = document.getElementById('dureeAllaitement');
    var modalite = document.getElementById('modaliteAllaitement');
    var apercu = document.getElementById('apercuAllaitement');
    function toMinutes(v) { var p=v.split(':'); return parseInt(p[0],10)*60+parseInt(p[1],10); }
    function toTime(m) { m=(m+1440)%1440; var h=Math.floor(m/60), n=m%60; return (h<10?'0':'')+h+':'+(n<10?'0':'')+n; }
    function updatePreview() {
        var option = base.options[base.selectedIndex];
        if (!option || !option.getAttribute('data-entree')) { apercu.innerHTML="Sélectionnez un horaire de référence pour afficher l'aperçu."; return; }
        var e=toMinutes(option.getAttribute('data-entree')), s=toMinutes(option.getAttribute('data-sortie')), d=parseInt(duree.value,10)||0;
        if (modalite.value==='arrivee_tardive') e+=d;
        else if (modalite.value==='sortie_anticipee') s-=d;
        else { var p=Math.floor(d/2); e+=p; s-=(d-p); }
        apercu.innerHTML='<b>Aperçu de l’horaire appliqué :</b> '+toTime(e)+' - '+toTime(s)+' ('+d+' min accordées par jour).';
    }
    base.addEventListener('change',updatePreview); duree.addEventListener('input',updatePreview); modalite.addEventListener('change',updatePreview); updatePreview();
})();
</script>

<?php elseif ($action === 'affectations'):
?>
<div class="card">
    <div class="card-header"><h2>🕒 Affectations d'horaires personnalisés <span class="text-muted">(allaitement, mission, individuel)</span></h2></div>
    <p class="text-muted">Permet d'attribuer un horaire spécifique à un agent pour une période donnée. Utilisé notamment pour les <b>femmes allaitantes</b> (RG-11).</p>

    <form method="post" action="horaires.php" class="mt-2">
        <input type="hidden" name="action" value="save_affectation">
        <div class="form-grid">
            <div class="form-group">
                <label>Agente / Agent *</label>
                <select name="numero_identification" required>
                    <option value="">— Sélectionner —</option>
                    <?php foreach ($agents as $ag): ?>
                        <option value="<?php echo h($ag['numero_identification']); ?>"><?php echo h($ag['numero_identification'].' — '.($ag['nom_complet']?:'sans nom')); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Horaire appliqué *</label>
                <select name="horaire_id" required>
                    <option value="">— Sélectionner —</option>
                    <?php foreach ($horaires as $ho): ?>
                        <option value="<?php echo (int)$ho['id']; ?>"><?php echo h($ho['libelle'].' ('.formatHeure($ho['heure_entree']).'-'.formatHeure($ho['heure_sortie']).')'); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Type</label>
                <select name="type">
                    <option value="individuel">Individuel</option>
                    <option value="allaitement">Allaitement 🤱</option>
                    <option value="mission">Mission</option>
                    <option value="autre">Autre</option>
                </select>
            </div>
            <div class="form-group"><label>Date début *</label><input type="date" name="date_debut" required></div>
            <div class="form-group"><label>Date fin *</label><input type="date" name="date_fin" required></div>
            <div class="form-group"><label>Décision / Référence</label><input type="text" name="decision_ref" placeholder="N° de la décision..."></div>
            <div class="form-group" style="grid-column:1/-1">
                <label>Motif / Observation</label>
                <textarea name="motif" rows="2"></textarea>
            </div>
            <div class="form-group">
                <label>Validation</label>
                <label style="font-weight:normal;display:flex;align-items:center;gap:8px;margin-top:6px">
                    <input type="checkbox" name="valide" value="1" checked> Validé
                </label>
            </div>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-success">💾 Enregistrer l'affectation</button>
        </div>
    </form>
</div>

<?php
$affs = $pdo->query("SELECT af.*, a.nom_complet, h.libelle, h.heure_entree, h.heure_sortie
    FROM affectation_horaire af
    JOIN agents a ON a.numero_identification=af.numero_identification
    JOIN horaire h ON h.id=af.horaire_id
    ORDER BY af.date_debut DESC")->fetchAll();
?>
<div class="card">
    <div class="card-header"><h2>Affectations en cours</h2></div>
    <div class="table-wrap">
        <table class="data-table">
            <thead><tr><th>Agent</th><th>Type</th><th>Horaire</th><th>Du</th><th>Au</th><th>État</th><th>Décision</th><th class="actions">Action</th></tr></thead>
            <tbody>
            <?php if (empty($affs)): ?>
                <tr class="empty-row"><td colspan="8">Aucune affectation d'horaire.</td></tr>
            <?php else: foreach ($affs as $af):
                $today = date('Y-m-d');
                $etat = ($af['date_fin'] < $today) ? 'Expirée' : (($af['date_debut'] > $today) ? 'À venir' : 'Active');
                $etatBadge = $etat==='Active'?'badge-green':($etat==='À venir'?'badge-blue':'badge-gray');
                $typeBadge = $af['type']==='allaitement'?'badge-purple':($af['type']==='mission'?'badge-orange':'badge-blue');
            ?>
                <tr>
                    <td><?php echo h($af['nom_complet']); ?> <small class="text-muted">(<?php echo h($af['numero_identification']); ?>)</small></td>
                    <td><span class="badge <?php echo $typeBadge; ?>"><?php echo h($af['type']); ?></span></td>
                    <td><?php echo h($af['libelle']); ?> <small>(<?php echo formatHeure($af['heure_entree']).'-'.formatHeure($af['heure_sortie']); ?>)</small></td>
                    <td><?php echo formatDateFr($af['date_debut']); ?></td>
                    <td><?php echo formatDateFr($af['date_fin']); ?></td>
                    <td><span class="badge <?php echo $etatBadge; ?>"><?php echo $etat; ?></span></td>
                    <td><small><?php echo h($af['decision_ref'] ?: '—'); ?></small></td>
                    <td class="actions"><a href="horaires.php?action=del_aff&id=<?php echo (int)$af['id']; ?>" onclick="return confirm('Supprimer cette affectation ?')">🗑️</a></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
<p class="mt-2"><a href="horaires.php" class="btn btn-outline btn-sm">← Gestion des horaires</a></p>

<?php else: // gestion des horaires ?>

<div class="card">
    <div class="card-header"><h2>🕒 Définir un horaire</h2></div>
    <form method="post" action="horaires.php">
        <input type="hidden" name="action" value="save_horaire">
        <input type="hidden" name="id" value="<?php echo (int)($_GET['edit'] ?? 0); ?>">
        <?php
        $editH = null;
        if (!empty($_GET['edit'])) {
            $s = $pdo->prepare("SELECT * FROM horaire WHERE id=?"); $s->execute([(int)$_GET['edit']]);
            $editH = $s->fetch();
        }
        ?>
        <div class="form-grid">
            <div class="form-group"><label>Libellé *</label><input type="text" name="libelle" required value="<?php echo h($editH['libelle'] ?? ''); ?>" placeholder="ex: Horaire standard"></div>
            <div class="form-group">
                <label>Portée</label>
                <select name="portee" id="porteeSel" onchange="toggleCible()">
                    <?php foreach ($porteeLabels as $k=>$v): ?>
                        <option value="<?php echo $k; ?>" <?php echo ($editH['portee']??'general')===$k?'selected':''; ?>><?php echo $v; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" id="cibleBox">
                <label>Cible (service / site / catégorie)</label>
                <input type="text" name="cible" value="<?php echo h($editH['cible'] ?? ''); ?>" placeholder="ex: Comptabilité">
            </div>
            <div class="form-group"><label>Heure d'entrée *</label><input type="time" name="heure_entree" required value="<?php echo h(substr($editH['heure_entree'] ?? '08:00',0,5)); ?>"></div>
            <div class="form-group"><label>Heure de sortie *</label><input type="time" name="heure_sortie" required value="<?php echo h(substr($editH['heure_sortie'] ?? '16:00',0,5)); ?>"></div>
            <div class="form-group"><label>Tolérance (min)</label><input type="number" name="tolerance_min" min="0" value="<?php echo (int)($editH['tolerance_min'] ?? 5); ?>"></div>
            <div class="form-group"><label>Date d'effet</label><input type="date" name="date_effet" value="<?php echo h($editH['date_effet'] ?? ''); ?>"></div>
            <div class="form-group">
                <label>Statut</label>
                <label style="font-weight:normal;display:flex;align-items:center;gap:8px;margin-top:6px">
                    <input type="checkbox" name="actif" value="1" <?php echo (!isset($editH) || $editH['actif'])?'checked':''; ?>> Actif
                </label>
            </div>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-success">💾 Enregistrer</button>
            <?php if ($editH): ?><a href="horaires.php" class="btn btn-secondary">Annuler</a><?php endif; ?>
        </div>
    </form>
</div>

<div class="card">
    <div class="card-header">
        <h2>Horaires définis</h2>
        <div style="display:flex;gap:8px;flex-wrap:wrap"><a href="horaires.php?action=allaitement" class="btn btn-success btn-sm">🤱 Heures d'allaitement</a><a href="horaires.php?action=affectations" class="btn btn-sm">📋 Autres affectations</a></div>
    </div>
    <div class="table-wrap">
        <table class="data-table">
            <thead><tr><th>Libellé</th><th>Portée</th><th>Cible</th><th>Entrée</th><th>Sortie</th><th>Tolérance</th><th>Effet</th><th>Statut</th><th class="actions">Actions</th></tr></thead>
            <tbody>
            <?php if (empty($horaires)): ?>
                <tr class="empty-row"><td colspan="9">Aucun horaire défini. L'horaire par défaut est <?php echo parametre('heure_entree_ref'); ?>-<?php echo parametre('heure_sortie_ref'); ?> avec <?php echo parametre('tolerance_min'); ?> min de tolérance.</td></tr>
            <?php else: foreach ($horaires as $ho): ?>
                <tr>
                    <td><?php echo h($ho['libelle']); ?></td>
                    <td><span class="badge badge-blue"><?php echo $porteeLabels[$ho['portee']] ?? $ho['portee']; ?></span></td>
                    <td><?php echo h($ho['cible'] ?: '—'); ?></td>
                    <td><?php echo formatHeure($ho['heure_entree']); ?></td>
                    <td><?php echo formatHeure($ho['heure_sortie']); ?></td>
                    <td><?php echo (int)$ho['tolerance_min']; ?> min</td>
                    <td><?php echo formatDateFr($ho['date_effet']); ?></td>
                    <td><?php echo $ho['actif']?'<span class="badge badge-green">Actif</span>':'<span class="badge badge-gray">Inactif</span>'; ?></td>
                    <td class="actions">
                        <a href="horaires.php?edit=<?php echo (int)$ho['id']; ?>" title="Modifier">✏️</a>
                        <a href="horaires.php?action=del_horaire&id=<?php echo (int)$ho['id']; ?>" title="Supprimer" onclick="return confirm('Supprimer cet horaire ?')">🗑️</a>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
<script>
function toggleCible() {
    var p = document.getElementById('porteeSel').value;
    document.getElementById('cibleBox').style.display = (p === 'general') ? 'none' : 'block';
}
toggleCible();
</script>
<?php endif; ?>

<?php include __DIR__ . '/partials/footer.php'; ?>
