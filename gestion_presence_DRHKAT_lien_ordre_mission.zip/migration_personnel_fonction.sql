-- Mise à jour du référentiel PERSONNEL : fonction de l'agent
ALTER TABLE personnel ADD COLUMN CODE_FONCTION INT(10) UNSIGNED NULL AFTER GRADES;
ALTER TABLE personnel ADD COLUMN FONCTION_AGENT VARCHAR(200) NULL AFTER CODE_FONCTION;
ALTER TABLE personnel ADD INDEX idx_personnel_fonction (CODE_FONCTION);

-- Synchronise les libellés pour les codes déjà renseignés.
UPDATE personnel p
LEFT JOIN fonction f ON f.id_fonction = p.CODE_FONCTION
SET p.FONCTION_AGENT = f.Libelle_Fonction
WHERE p.CODE_FONCTION IS NOT NULL;
