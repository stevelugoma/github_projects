<?php
require_once __DIR__ . '/auth.php';
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store');

function botJson($ok, $message, $data = array()) {
    http_response_code($ok ? 200 : 400);
    echo json_encode(array_merge(array('ok'=>$ok, 'message'=>$message), $data), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
function botNorm($s) {
    $s = trim((string)$s);
    $s = function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
    if (function_exists('iconv')) { $a=@iconv('UTF-8','ASCII//TRANSLIT//IGNORE',$s); if ($a!==false) $s=$a; }
    $s = preg_replace('/[^a-z0-9\s\-\/]/', ' ', $s);
    return trim(preg_replace('/\s+/', ' ', $s));
}
function botHas($q, $words) { foreach ((array)$words as $w) if (strpos($q, botNorm($w)) !== false) return true; return false; }
function botTableExists($pdo, $table) { try { $s=$pdo->prepare('SHOW TABLES LIKE ?'); $s->execute(array($table)); return (bool)$s->fetchColumn(); } catch (Throwable $e) { return false; } }
function botColumns($pdo,$table) { try { $out=array(); foreach($pdo->query('DESCRIBE `'.str_replace('`','',$table).'`')->fetchAll() as $r) $out[$r['Field']]=true; return $out; } catch(Throwable $e){ return array(); } }
function botCount($pdo,$sql,$params=array()){ $s=$pdo->prepare($sql);$s->execute($params);return (int)$s->fetchColumn(); }
function botRows($pdo,$sql,$params=array()){ $s=$pdo->prepare($sql);$s->execute($params);return $s->fetchAll(); }
function botCtx($key,$value=null){ if(!isset($_SESSION['drhkat_bot'])) $_SESSION['drhkat_bot']=array(); if(func_num_args()===2){$_SESSION['drhkat_bot'][$key]=$value;return $value;} return isset($_SESSION['drhkat_bot'][$key])?$_SESSION['drhkat_bot'][$key]:null; }
function botRemember($intent,$filter=array()){ botCtx('last_intent',$intent); botCtx('last_filter',$filter); }
function botDateRange($q){
    $today=date('Y-m-d');
    if(botHas($q,array('aujourd hui','ce jour'))) return array($today,$today,"aujourd’hui");
    if(botHas($q,array('hier'))) { $d=date('Y-m-d',strtotime('-1 day')); return array($d,$d,'hier'); }
    if(botHas($q,array('cette semaine','semaine en cours'))) return array(date('Y-m-d',strtotime('monday this week')),date('Y-m-d',strtotime('sunday this week')),'cette semaine');
    if(botHas($q,array('ce mois','mois en cours'))) return array(date('Y-m-01'),date('Y-m-t'),'ce mois');
    if(botHas($q,array('mois dernier','dernier mois','mois precedent'))) { $t=strtotime('first day of last month'); return array(date('Y-m-01',$t),date('Y-m-t',$t),'le mois dernier'); }
    if(preg_match('#(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})#',$q,$m)){ $d=sprintf('%04d-%02d-%02d',$m[3],$m[2],$m[1]); return array($d,$d,'le '.$m[1].'/'.$m[2].'/'.$m[3]); }
    return null;
}
function botExtractAfter($question,$patterns){ $term=$question; foreach($patterns as $p) $term=preg_replace($p,'',$term); return trim($term," \t\n\r\0\x0B?!.,;:\""); }
function botLinks($label,$url){ return array(array('label'=>$label,'url'=>$url)); }
function botSuggestions($items){ return array_values(array_unique($items)); }
function botPersonTable($rows){
    $out=array(); foreach($rows as $r) $out[]=array(
        isset($r['CODE_AGENT'])?$r['CODE_AGENT']:'—', isset($r['NOMS'])?$r['NOMS']:'—',
        !empty($r['SITE'])?$r['SITE']:'—', !empty($r['ENTITE'])?$r['ENTITE']:'—',
        !empty($r['DIVISION'])?$r['DIVISION']:'—', !empty($r['GRADES'])?$r['GRADES']:'—',
        !empty($r['FONCTION_AGENT'])?$r['FONCTION_AGENT']:'—'
    );
    return array('columns'=>array('Code','Noms','Site','Appartenance','Division','Grade','Fonction'),'rows'=>$out);
}
function botClosest($term,$values){
    $n=botNorm($term); $best=null;$score=999;
    foreach($values as $v){$vn=botNorm($v); if($vn==='' )continue; if(strpos($vn,$n)!==false||strpos($n,$vn)!==false)return $v; $d=levenshtein(substr($n,0,120),substr($vn,0,120)); if($d<$score){$score=$d;$best=$v;}}
    return ($score<=max(3,(int)(strlen($n)*0.38)))?$best:null;
}

if($_SERVER['REQUEST_METHOD']!=='POST') botJson(false,'Méthode non autorisée.');
$question=trim(isset($_POST['question'])?$_POST['question']:'');
$page=basename(isset($_POST['page'])?$_POST['page']:'');
if($question==='') botJson(false,'Écrivez votre demande.');
if(strlen($question)>800) botJson(false,'La demande est trop longue.');
$q=botNorm($question); $pdo=db(); ensurePersonnelFunctionColumns($pdo);

if(botHas($q,array('reinitialiser conversation','nouvelle conversation','effacer conversation'))){ unset($_SESSION['drhkat_bot']); botJson(true,'La conversation a été réinitialisée.',array('suggestions'=>array('Effectif total','Résumé RH','Retards ce mois'))); }

$nav=array(
 'personnel'=>array('Personnels','personnels.php','Tableau de bord RH, registre, sites, appartenances, divisions, grades, fonctions et signataires.'),
 'agent'=>array('Agents','agents.php','Référentiel biométrique et imports des agents.'),
 'presence'=>array('Présences','presences.php','Import et consultation des pointages journaliers.'),
 'retard'=>array('Retards','retards.php','Analyse, classement et justification des retards.'),
 'absence'=>array('Absences','absences.php','Saisie, validation et suivi des absences.'),
 'conge'=>array('Congés & missions','conges.php','Gestion des congés, missions, périodes et décisions.'),
 'horaire'=>array('Horaires','horaires.php','Horaires généraux, par cible et affectations individuelles.'),
 'rapport'=>array('Rapports','rapports.php','Synthèses, exports, impressions et fiches individuelles.'),
 'administration'=>array('Administration','administration.php','Paramètres, utilisateurs, jours fériés et audit.'),
 'signataire'=>array('Signataires','personnels.php?tab=signataires','Signataires des impressions et qualités issues des fonctions.'),
 'fonction'=>array('Fonctions','personnels.php?tab=fonctions','Référentiel des fonctions.'),
 'grade'=>array('Grades','personnels.php?tab=grades','Référentiel des grades et catégories.'),
 'division'=>array('Divisions','personnels.php?tab=divisions','Référentiel et effectifs par division.'),
 'appartenance'=>array('Appartenances','personnels.php?tab=appartenances','Référentiel et effectifs par appartenance.'),
 'site'=>array('Sites','personnels.php?tab=sites','Référentiel et effectifs par site.')
);

if(botHas($q,array('bonjour','bonsoir','salut','hello'))){ botJson(true,"Bonjour. Je peux analyser les données RH, retrouver un personnel, comparer les effectifs, résumer les présences ou vous guider dans l’application. Vous pouvez aussi poser une question de suivi, par exemple : « détaille » ou « et pour la division Informatique ? ».",array('suggestions'=>array('Résumé RH','Top 10 des sites','Retards ce mois','Chercher un personnel'))); }
if(botHas($q,array('aide','que peux tu','capacites','commandes','plus intelligent'))){ botJson(true,"Je comprends les formulations courantes et certaines fautes de frappe. Je peux :\n• calculer les effectifs globaux ou par site, appartenance, division et grade ;\n• afficher les personnes correspondant à un résultat ;\n• analyser présences, retards, absences et congés par période ;\n• signaler les données manquantes ;\n• expliquer et ouvrir les menus ;\n• poursuivre une question précédente avec « détaille », « qui sont-ils ? » ou « et pour… ».\nJe reste en lecture seule.",array('suggestions'=>array('Résumé RH','Personnel sans division','Top 5 des grades','Présences aujourd’hui'))); }

if(botHas($q,array('ou est','comment aller','ouvrir','ou gerer','comment ajouter','comment modifier','comment supprimer','a quoi sert'))){
 foreach($nav as $key=>$n){ if(strpos($q,botNorm($key))!==false||strpos($q,botNorm($n[0]))!==false) botJson(true,$n[2],array('links'=>botLinks('Ouvrir '.$n[0],$n[1]),'suggestions'=>array('Que puis-je faire sur cette page ?'))); }
}
if(botHas($q,array('imprimer','impression','signer rapport'))){ botJson(true,"Cliquez sur le bouton Imprimer de la liste ou du rapport. La fenêtre de signataire s’ouvre, permet de choisir ou d’ajouter un signataire, puis le document est généré avec le logo, l’en-tête institutionnel et la zone de signature.",array('links'=>botLinks('Ouvrir les rapports','rapports.php'),'suggestions'=>array('Où gérer les signataires ?'))); }

// Contexte de suivi : détail du dernier ensemble.
if(botHas($q,array('detaille','detailler','qui sont ils','qui sont elles','affiche la liste','montre la liste','lesquels','lesquelles'))){
 $f=botCtx('last_filter');
 if(is_array($f)&&isset($f['column'])&&isset($f['value'])&&botTableExists($pdo,'personnel')){
   $allowed=array('SITE','ENTITE','DIVISION','GRADES','FONCTION_AGENT'); $col=in_array($f['column'],$allowed,true)?$f['column']:null;
   if($col){ $rows=botRows($pdo,"SELECT CODE_AGENT,NOMS,SITE,ENTITE,DIVISION,GRADES,CODE_FONCTION,FONCTION_AGENT FROM personnel WHERE `$col` LIKE ? ORDER BY NOMS LIMIT 100",array('%'.$f['value'].'%')); botJson(true,count($rows)." personne(s) trouvée(s) pour « ".$f['value']." ».",array('table'=>botPersonTable($rows),'links'=>botLinks('Ouvrir le registre','personnels.php?tab=personnel'),'suggestions'=>array('Effectif total','Résumé RH'))); }
 }
}

// Recherche personne, y compris question directe contenant un nom/code.
if(botHas($q,array('chercher','cherche','trouver','trouve','qui est','fiche de','matricule','code agent'))){
 $term=botExtractAfter($question,array('/.*(?:chercher|cherche|trouver|trouve|qui est|fiche de|matricule|code agent)\s*/iu'));
 if($term!==''&&botTableExists($pdo,'personnel')){
  $rows=botRows($pdo,"SELECT CODE_AGENT,NOMS,SITE,ENTITE,DIVISION,GRADES,CODE_FONCTION,FONCTION_AGENT,MATRICULE FROM personnel WHERE NOMS LIKE ? OR CAST(CODE_AGENT AS CHAR)=? OR MATRICULE LIKE ? ORDER BY NOMS LIMIT 20",array('%'.$term.'%',$term,'%'.$term.'%'));
  if($rows){ botRemember('person_search',array('term'=>$term)); botJson(true,count($rows)." résultat(s) pour « ".$term." ».",array('table'=>botPersonTable($rows),'links'=>botLinks('Ouvrir le registre','personnels.php?tab=personnel'),'suggestions'=>array('Effectif total','Personnel sans division'))); }
  botJson(true,"Aucun personnel trouvé pour « ".$term." ». Vérifiez le nom, le code agent ou le matricule.",array('suggestions'=>array('Chercher ABASI','Ouvrir le registre')));
 }
}

// Résumé RH enrichi.
if(botHas($q,array('resume rh','résumé rh','synthese rh','tableau de bord rh','situation du personnel'))){
 $total=botTableExists($pdo,'personnel')?botCount($pdo,'SELECT COUNT(*) FROM personnel'):0;
 $sites=botTableExists($pdo,'personnel')?botCount($pdo,"SELECT COUNT(DISTINCT SITE) FROM personnel WHERE SITE IS NOT NULL AND TRIM(SITE)<>''"):0;
 $divs=botTableExists($pdo,'personnel')?botCount($pdo,"SELECT COUNT(DISTINCT DIVISION) FROM personnel WHERE DIVISION IS NOT NULL AND TRIM(DIVISION)<>''"):0;
 $grades=botTableExists($pdo,'personnel')?botCount($pdo,"SELECT COUNT(DISTINCT GRADES) FROM personnel WHERE GRADES IS NOT NULL AND TRIM(GRADES)<>''"):0;
 $incomplets=botTableExists($pdo,'personnel')?botCount($pdo,"SELECT COUNT(*) FROM personnel WHERE SITE IS NULL OR TRIM(SITE)='' OR DIVISION IS NULL OR TRIM(DIVISION)='' OR GRADES IS NULL OR TRIM(GRADES)=''"):0;
 botJson(true,"Situation RH actuelle : ".$total." personnels répartis sur ".$sites." sites, ".$divs." divisions et ".$grades." grades. ".$incomplets." fiche(s) ont au moins une information organisationnelle manquante.",array('metrics'=>array(array('label'=>'Personnel','value'=>$total),array('label'=>'Sites','value'=>$sites),array('label'=>'Divisions','value'=>$divs),array('label'=>'Grades','value'=>$grades),array('label'=>'Fiches incomplètes','value'=>$incomplets)),'links'=>botLinks('Ouvrir le tableau de bord RH','personnels.php'),'suggestions'=>array('Top 10 des sites','Personnel sans division','Top 5 des grades'))); }

if(botHas($q,array('effectif total','combien de personnel','nombre de personnel','total personnel'))){ $n=botTableExists($pdo,'personnel')?botCount($pdo,'SELECT COUNT(*) FROM personnel'):0; botRemember('total'); botJson(true,"L’effectif total est de ".$n." personne(s).",array('metrics'=>array(array('label'=>'Effectif total','value'=>$n)),'links'=>botLinks('Voir le personnel','personnels.php?tab=personnel'),'suggestions'=>array('Top 10 des sites','Répartition par division','Personnel sans grade'))); }

// Données manquantes / qualité.
if(botHas($q,array('sans site','site non renseigne','site manquant'))) $missing=array('SITE','site');
elseif(botHas($q,array('sans division','division non renseignee','division manquante'))) $missing=array('DIVISION','division');
elseif(botHas($q,array('sans grade','grade non renseigne','grade manquant'))) $missing=array('GRADES','grade');
elseif(botHas($q,array('sans fonction','fonction non renseignee','fonction manquante'))) $missing=array('FONCTION_AGENT','fonction');
elseif(botHas($q,array('sans appartenance','entite non renseignee','appartenance manquante'))) $missing=array('ENTITE','appartenance');
else $missing=null;
if($missing&&botTableExists($pdo,'personnel')){ $rows=botRows($pdo,"SELECT CODE_AGENT,NOMS,SITE,ENTITE,DIVISION,GRADES,CODE_FONCTION,FONCTION_AGENT FROM personnel WHERE `".$missing[0]."` IS NULL OR TRIM(`".$missing[0]."`)='' ORDER BY NOMS LIMIT 100"); botJson(true,count($rows)." fiche(s) sans ".$missing[1]." renseigné(e).",array('table'=>botPersonTable($rows),'links'=>botLinks('Corriger dans le registre','personnels.php?tab=personnel'),'suggestions'=>array('Personnel sans site','Personnel sans division','Personnel sans grade'))); }

// Agrégations top/répartition.
$group=null;$label=null;$url=null;
if(botHas($q,array('par site','des sites','sites les plus','top site'))) {$group='SITE';$label='sites';$url='personnels.php?tab=sites';}
elseif(botHas($q,array('par division','des divisions','divisions les plus','top division'))) {$group='DIVISION';$label='divisions';$url='personnels.php?tab=divisions';}
elseif(botHas($q,array('par grade','des grades','grades les plus','top grade'))) {$group='GRADES';$label='grades';$url='personnels.php?tab=grades';}
elseif(botHas($q,array('par fonction','des fonctions','fonctions les plus','top fonction'))) {$group='FONCTION_AGENT';$label='fonctions';$url='personnels.php?tab=fonctions';}
elseif(botHas($q,array('par appartenance','des appartenances','entites les plus','top appartenance'))) {$group='ENTITE';$label='appartenances';$url='personnels.php?tab=appartenances';}
if($group && botHas($q,array('top','repartition','répartition','classement','effectif par','les plus nombreux','afficher les')) && botTableExists($pdo,'personnel')){
 $limit=10;if(preg_match('/\b(\d{1,2})\b/',$q,$m))$limit=max(1,min(30,(int)$m[1]));
 $rows=botRows($pdo,"SELECT COALESCE(NULLIF(TRIM(`$group`),''),'Non renseigné') libelle, COUNT(*) effectif FROM personnel GROUP BY COALESCE(NULLIF(TRIM(`$group`),''),'Non renseigné') ORDER BY effectif DESC, libelle LIMIT ".$limit);
 $table=array('columns'=>array(ucfirst(rtrim($label,'s')),'Effectif'),'rows'=>array()); foreach($rows as $r)$table['rows'][]=array($r['libelle'],(int)$r['effectif']);
 botRemember('group',array('column'=>$group)); botJson(true,"Voici le classement des ".$label." par effectif.",array('table'=>$table,'links'=>botLinks('Ouvrir les '.$label,$url),'suggestions'=>array('Effectif total','Résumé RH'))); }

// Effectif ciblé avec rapprochement tolérant.
$target=null;$column=null;$targetLabel=null;$targetUrl=null;
if(botHas($q,array('site'))) {$column='SITE';$targetLabel='site';$targetUrl='personnels.php?tab=sites';$patterns=array('/.*(?:effectif|personnel|agents|combien).*?site\s*(?:de|du|d[eu]|:)??\s*/iu','/.*site\s*/iu');}
if(botHas($q,array('division'))) {$column='DIVISION';$targetLabel='division';$targetUrl='personnels.php?tab=divisions';$patterns=array('/.*(?:effectif|personnel|agents|combien).*?division\s*(?:de|du|d[eu]|:)??\s*/iu','/.*division\s*/iu');}
if(botHas($q,array('appartenance','entite'))) {$column='ENTITE';$targetLabel='appartenance';$targetUrl='personnels.php?tab=appartenances';$patterns=array('/.*(?:effectif|personnel|agents|combien).*?(?:appartenance|entite)\s*(?:de|du|d[eu]|:)??\s*/iu','/.*(?:appartenance|entite)\s*/iu');}
if(botHas($q,array('grade'))) {$column='GRADES';$targetLabel='grade';$targetUrl='personnels.php?tab=grades';$patterns=array('/.*(?:effectif|personnel|agents|combien).*?grade\s*(?:de|du|d[eu]|:)??\s*/iu','/.*grade\s*/iu');}
if(botHas($q,array('fonction'))) {$column='FONCTION_AGENT';$targetLabel='fonction';$targetUrl='personnels.php?tab=fonctions';$patterns=array('/.*(?:effectif|personnel|agents|combien).*?fonction\s*(?:de|du|d[eu]|:)??\s*/iu','/.*fonction\s*/iu');}
if($column && botHas($q,array('effectif','personnel','agents','combien','et pour')) && botTableExists($pdo,'personnel')){
 $target=botExtractAfter($question,$patterns);
 if(botHas($q,array('et pour')) && $target===''){ $target=botExtractAfter($question,array('/.*et pour\s*/iu')); }
 if($target!==''){
  $vals=botRows($pdo,"SELECT DISTINCT `$column` v FROM personnel WHERE `$column` IS NOT NULL AND TRIM(`$column`)<>''"); $list=array();foreach($vals as $v)$list[]=$v['v']; $match=botClosest($target,$list); if(!$match)$match=$target;
  $rows=botRows($pdo,"SELECT CODE_AGENT,NOMS,SITE,ENTITE,DIVISION,GRADES,CODE_FONCTION,FONCTION_AGENT FROM personnel WHERE `$column` LIKE ? ORDER BY NOMS LIMIT 100",array('%'.$match.'%'));
  botRemember('filter',array('column'=>$column,'value'=>$match));
  $msg="Le ".$targetLabel." « ".$match." » compte ".count($rows)." personne(s)."; if($match!==$target)$msg.=" J’ai rapproché votre saisie de ce libellé.";
  botJson(true,$msg,array('metrics'=>array(array('label'=>'Effectif','value'=>count($rows))),'table'=>count($rows)<=20?botPersonTable($rows):null,'links'=>botLinks('Ouvrir les '.$targetLabel.'s',$targetUrl),'suggestions'=>array('Détaille','Effectif total','Résumé RH')));
 }
}

// Statistiques de présence avec période.
$range=botDateRange($q); if(!$range) $range=array(date('Y-m-d'),date('Y-m-d'),'aujourd’hui');
if(botHas($q,array('presence','présence','presents','présents','retard','absence','conge','congé'))){
 if(botHas($q,array('retard'))&&botTableExists($pdo,'presence_journaliere')){
  $n=botCount($pdo,"SELECT COUNT(*) FROM presence_journaliere WHERE date_presence BETWEEN ? AND ? AND retard_minutes>0",array($range[0],$range[1]));
  $mins=botCount($pdo,"SELECT COALESCE(SUM(retard_minutes),0) FROM presence_journaliere WHERE date_presence BETWEEN ? AND ? AND retard_minutes>0",array($range[0],$range[1]));
  $top=botRows($pdo,"SELECT p.numero_identification,a.nom_complet,COUNT(*) nb,SUM(p.retard_minutes) minutes FROM presence_journaliere p LEFT JOIN agents a ON a.numero_identification=p.numero_identification WHERE p.date_presence BETWEEN ? AND ? AND p.retard_minutes>0 GROUP BY p.numero_identification,a.nom_complet ORDER BY minutes DESC LIMIT 10",array($range[0],$range[1]));
  $t=array('columns'=>array('N°','Agent','Retards','Minutes'),'rows'=>array());foreach($top as $r)$t['rows'][]=array($r['numero_identification'],$r['nom_complet']?:'—',(int)$r['nb'],(int)$r['minutes']);
  botJson(true,"Pour ".$range[2].", ".$n." retard(s) totalisent ".$mins." minute(s).",array('metrics'=>array(array('label'=>'Retards','value'=>$n),array('label'=>'Minutes','value'=>$mins)),'table'=>$t,'links'=>botLinks('Voir les retards','retards.php'),'suggestions'=>array('Retards aujourd’hui','Retards ce mois','Absences en cours')));
 }
 if(botHas($q,array('presence','présence','presents','présents'))&&botTableExists($pdo,'presence_journaliere')){
  $n=botCount($pdo,"SELECT COUNT(*) FROM presence_journaliere WHERE date_presence BETWEEN ? AND ? AND statut='present'",array($range[0],$range[1]));
  $agents=botCount($pdo,"SELECT COUNT(DISTINCT numero_identification) FROM presence_journaliere WHERE date_presence BETWEEN ? AND ? AND statut='present'",array($range[0],$range[1]));
  botJson(true,"Pour ".$range[2].", ".$n." journée(s)-présence concernent ".$agents." agent(s) distinct(s).",array('metrics'=>array(array('label'=>'Journées-présence','value'=>$n),array('label'=>'Agents distincts','value'=>$agents)),'links'=>botLinks('Voir les présences','presences.php'),'suggestions'=>array('Retards ce mois','Absences en cours')));
 }
 if(botHas($q,array('absence'))&&botTableExists($pdo,'absence')){
  $rows=botRows($pdo,"SELECT ab.numero_identification,a.nom_complet,ab.type,ab.date_debut,ab.date_fin,ab.statut FROM absence ab LEFT JOIN agents a ON a.numero_identification=ab.numero_identification WHERE ab.date_fin>=? AND ab.date_debut<=? ORDER BY ab.date_debut DESC LIMIT 30",array($range[0],$range[1]));
  $t=array('columns'=>array('N°','Agent','Type','Du','Au','Statut'),'rows'=>array());foreach($rows as $r)$t['rows'][]=array($r['numero_identification'],$r['nom_complet']?:'—',$r['type'],$r['date_debut'],$r['date_fin'],$r['statut']);
  botJson(true,count($rows)." absence(s) chevauchent ".$range[2].".",array('table'=>$t,'links'=>botLinks('Voir les absences','absences.php'),'suggestions'=>array('Congés en cours','Retards aujourd’hui')));
 }
 if(botHas($q,array('conge','congé'))&&botTableExists($pdo,'conge')){
  $rows=botRows($pdo,"SELECT c.numero_identification,a.nom_complet,c.type,c.date_debut,c.date_fin,c.statut FROM conge c LEFT JOIN agents a ON a.numero_identification=c.numero_identification WHERE c.date_fin>=? AND c.date_debut<=? ORDER BY c.date_debut DESC LIMIT 30",array($range[0],$range[1]));
  $t=array('columns'=>array('N°','Agent','Type','Du','Au','Statut'),'rows'=>array());foreach($rows as $r)$t['rows'][]=array($r['numero_identification'],$r['nom_complet']?:'—',$r['type'],$r['date_debut'],$r['date_fin'],$r['statut']);
  botJson(true,count($rows)." congé(s) ou mission(s) chevauchent ".$range[2].".",array('table'=>$t,'links'=>botLinks('Voir les congés','conges.php'),'suggestions'=>array('Absences en cours','Retards ce mois')));
 }
}

// Aide contextuelle.
if(botHas($q,array('cette page','page actuelle','ici','que faire ici'))){ foreach($nav as $n){ if($page===basename(parse_url($n[1],PHP_URL_PATH))) botJson(true,$n[2],array('links'=>botLinks('Rester sur '.$n[0],$n[1]))); } }

botJson(true,"Je n’ai pas encore identifié précisément la demande. Essayez une question avec un objet et une période ou un libellé, par exemple : « top 10 des sites », « personnel de la division Informatique », « retards ce mois », « personnel sans grade » ou « chercher ABASI ». Vous pouvez aussi écrire « aide » pour voir mes capacités.",array('suggestions'=>array('Résumé RH','Top 10 des sites','Retards ce mois','Personnel sans division')));
