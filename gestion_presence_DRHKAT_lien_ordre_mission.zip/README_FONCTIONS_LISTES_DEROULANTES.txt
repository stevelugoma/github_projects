MISE À JOUR — LISTES DÉROULANTES DES FONCTIONS

Le champ Fonction du formulaire d'ajout/modification des agents est désormais
une liste déroulante alimentée directement par la table `fonction`.

Déjà couverts et conservés :
- Personnel : CODE_FONCTION + FONCTION_AGENT depuis la table fonction ;
- Signataires : Qualité / fonction depuis la table fonction ;
- Agents : fonction depuis la table fonction (nouvelle mise à jour).

Les anciennes valeurs d'agents qui ne figurent plus dans le référentiel restent
affichées lors de la modification avec la mention « ancienne valeur », afin
d'éviter toute perte de données. Une nouvelle sélection les remplace par une
valeur normalisée du référentiel.
