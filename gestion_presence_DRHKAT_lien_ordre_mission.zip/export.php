<?php
/**
 * export.php — Export CSV des rapports (ouvrable directement dans Excel).
 */
require_once __DIR__ . '/helpers.php';

$type  = $_GET['type'] ?? 'synthese';
$dateD = $_GET['date_debut'] ?? '';
$dateF = $_GET['date_fin'] ?? '';
$pdo = db();

$filename = "rapport_{$type}_" . date('Ymd_His') . ".csv";

// en-têtes HTTP pour téléchargement CSV (UTF-8 avec BOM pour Excel)
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: no-cache, no-store, must-revalidate');

$out = fopen('php://output', 'w');
fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM UTF-8

$whereDate = '';
$params = [];
if ($dateD) { $whereDate .= " AND date_presence>=?"; $params[] = $dateD; }
if ($dateF) { $whereDate .= " AND date_presence<=?"; $params[] = $dateF; }

switch ($type) {
    case 'presences':
        fputcsv($out, ['Date','N° identification','Nom','Entrée','Sortie','Durée (min)','Retard (min)','Tranche','Statut','Horaire appliqué']);
        $stmt = $pdo->prepare("SELECT p.*, a.nom_complet FROM presence_journaliere p
            JOIN agents a ON a.numero_identification=p.numero_identification
            WHERE 1=1 $whereDate ORDER BY p.date_presence DESC");
        $stmt->execute($params);
        foreach ($stmt as $r) {
            fputcsv($out, [
                $r['date_presence'], $r['numero_identification'], $r['nom_complet'],
                $r['premiere_entree'], $r['derniere_sortie'], $r['duree_minutes'],
                $r['retard_minutes'], $r['tranche_retard'], $r['statut'], $r['horaire_applique']
            ]);
        }
        break;

    case 'retards':
        fputcsv($out, ['Date','N° identification','Nom','Service','Arrivée','Retard (min)','Tranche','Justifié','Motif']);
        $stmt = $pdo->prepare("SELECT p.*, a.nom_complet, a.service FROM presence_journaliere p
            JOIN agents a ON a.numero_identification=p.numero_identification
            WHERE p.retard_minutes>0 $whereDate ORDER BY p.retard_minutes DESC");
        $stmt->execute($params);
        foreach ($stmt as $r) {
            fputcsv($out, [
                $r['date_presence'], $r['numero_identification'], $r['nom_complet'], $r['service'],
                $r['premiere_entree'], $r['retard_minutes'], $r['tranche_retard'],
                !empty($r['motif_correction']) ? 'Oui' : 'Non', $r['motif_correction']
            ]);
        }
        break;

    case 'absences':
        fputcsv($out, ['N° identification','Nom','Service','Du','Au','Type','Motif','Statut']);
        $stmt = $pdo->prepare("SELECT ab.*, a.nom_complet, a.service FROM absence ab
            JOIN agents a ON a.numero_identification=ab.numero_identification
            WHERE ab.date_fin>=? AND ab.date_debut<=? ORDER BY ab.date_debut DESC");
        $stmt->execute([$dateD ?: '1900-01-01', $dateF ?: '2999-12-31']);
        foreach ($stmt as $r) {
            fputcsv($out, [
                $r['numero_identification'], $r['nom_complet'], $r['service'],
                $r['date_debut'], $r['date_fin'], $r['type'], $r['motif'], $r['statut']
            ]);
        }
        break;

    case 'agent':
        $numId = $_GET['numero'] ?? '';
        fputcsv($out, ['Date','Entrée','Sortie','Durée (min)','Retard (min)','Statut','Horaire appliqué']);
        $stmt = $pdo->prepare("SELECT * FROM presence_journaliere WHERE numero_identification=? $whereDate ORDER BY date_presence");
        $stmt->execute(array_merge([$numId], $params));
        foreach ($stmt as $r) {
            fputcsv($out, [
                $r['date_presence'], $r['premiere_entree'], $r['derniere_sortie'],
                $r['duree_minutes'], $r['retard_minutes'], $r['statut'], $r['horaire_applique']
            ]);
        }
        break;

    default: // synthese
        fputcsv($out, ['N° identification','Nom','Service','Jours','Retards','Minutes retard']);
        $stmt = $pdo->prepare("SELECT p.numero_identification, a.nom_complet, a.service,
            COUNT(*) AS jours, SUM(p.retard_minutes>0) AS retards, SUM(p.retard_minutes) AS min_retard
            FROM presence_journaliere p JOIN agents a ON a.numero_identification=p.numero_identification
            WHERE 1=1 $whereDate
            GROUP BY p.numero_identification, a.nom_complet, a.service
            ORDER BY min_retard DESC");
        $stmt->execute($params);
        foreach ($stmt as $r) {
            fputcsv($out, [$r['numero_identification'], $r['nom_complet'], $r['service'], $r['jours'], $r['retards'], $r['min_retard']]);
        }
        break;
}
fclose($out);
exit;
