<?php
/**
 * XlsxReader.php — Lecteur de fichiers .xlsx SANS aucune dépendance externe.
 *
 * Lit un fichier Excel (.xlsx = zip de XML) et retourne les lignes sous forme
 * de tableau PHP. Gère les types date Excel (numéro de série) et les fractions
 * de jour (heures), conformément aux exports du terminal XI FACE2000.
 *
 * Usage :
 *   require 'XlsxReader.php';
 *   $rows = XlsxReader::read('fichier.xlsx');
 *   // $rows[0] = première ligne de données (en-têtes exclus)
 */
class XlsxReader
{
    /** Date de référence du calendrier Excel 1900 (30 déc 1899). */
    const EXCEL_EPOCH = '1899-12-30';

    /**
     * Lit un fichier .xlsx et renvoie un tableau indexé de lignes.
     * Chaque ligne est un tableau associatif [en-tête => valeur].
     *
     * @param string $fichier  Chemin absolu du .xlsx
     * @param bool   $firstRowHeader  true si la 1re ligne contient les en-têtes
     * @return array
     */
    public static function read($fichier, $firstRowHeader = true)
    {
        if (!class_exists('ZipArchive')) {
            throw new RuntimeException("L'extension PHP 'zip' est requise pour lire les .xlsx.");
        }
        $zip = new ZipArchive();
        if ($zip->open($fichier) !== true) {
            throw new RuntimeException("Impossible d'ouvrir le fichier .xlsx : " . $fichier);
        }

        // 1) Lecture du sharedStrings.xml (chaînes partagées)
        $shared = [];
        if (($ss = $zip->getFromName('xl/sharedStrings.xml')) !== false) {
            $shared = self::parseSharedStrings($ss);
        }

        // 2) Lecture de la première feuille xl/worksheets/sheet1.xml
        $sheetXml = $zip->getFromName('xl/worksheets/sheet1.xml');
        $zip->close();
        if ($sheetXml === false) {
            throw new RuntimeException("Aucune feuille trouvée dans le fichier .xlsx.");
        }

        // 3) Parse les cellules
        $rows = self::parseSheet($sheetXml, $shared);

        // 4) Conversion des en-têtes
        if ($firstRowHeader && !empty($rows)) {
            $headers = array_shift($rows);
            // normalise les en-têtes (enlève les espaces) et gère les DOUBLONS
            // (le terminal FACE2000 exporte 3 colonnes "DANS" et 3 "DEHORS")
            $normHeaders = [];
            $seen = [];
            $colCount = count($headers);
            for ($i = 0; $i < $colCount; $i++) {
                $h = $headers[$i];
                $key = is_string($h) ? trim($h) : $h;
                if ($key === null || $key === '') {
                    $key = 'col' . $i;
                }
                // si en-tête dupliqué (ex: plusieurs "DANS"), on suffixe _2, _3...
                if ($key !== 'col' . $i && isset($seen[$key])) {
                    $seen[$key]++;
                    $key = $key . '_' . $seen[$key];
                } else {
                    $seen[$key] = 1;
                }
                $normHeaders[$i] = $key;
            }

            $out = [];
            foreach ($rows as $row) {
                $assoc = [];
                for ($i = 0; $i < $colCount; $i++) {
                    $assoc[$normHeaders[$i]] = $row[$i] ?? null;
                }
                $out[] = $assoc;
            }
            return $out;
        }
        return $rows;
    }

    private static function parseSharedStrings($xml)
    {
        $strings = [];
        // extraction des <si>...</si> et de leur texte <t>
        if (preg_match_all('/<si\b[^>]*>(.*?)<\/si>/s', $xml, $siMatches, PREG_SET_ORDER)) {
            foreach ($siMatches as $m) {
                // un <si> peut contenir plusieurs <t> (rich text) — on concatène
                $text = '';
                if (preg_match_all('/<t\b[^>]*>(.*?)<\/t>/s', $m[1], $tMatches)) {
                    $text = implode('', $tMatches[1]);
                }
                $strings[] = self::decodeEntities($text);
            }
        }
        return $strings;
    }

    private static function parseSheet($xml, array $shared)
    {
        $rows = [];
        // on découpe par ligne <row ...>...</row>
        if (!preg_match_all('/<row\b[^>]*>(.*?)<\/row>/s', $xml, $rowMatches, PREG_SET_ORDER)) {
            return $rows;
        }
        foreach ($rowMatches as $rowMatch) {
            $rowXml = $rowMatch[1];
            $cells = [];
            // extraction des cellules <c ...>...</c> ET des cellules auto-fermantes <c .../>
            // La regex capture les attributs ET un éventuel contenu interne.
            // On gère deux formes :
            //   1) <c r="A1" .../>          (cellule vide auto-fermante)
            //   2) <c r="B1" ...>...</c>     (cellule avec contenu)
            if (preg_match_all('/<c\b([^>]*?)(?:\/>|>(.*?)<\/c>)/s', $rowXml, $cellMatches, PREG_SET_ORDER)) {
                foreach ($cellMatches as $cm) {
                    $attrs = $cm[1];
                    $inner = $cm[2] ?? '';

                    // référence de cellule (ex: A1, B3) pour connaître la colonne
                    // On prend toujours la référence réelle (r="A1") pour bien positionner
                    // la colonne, même en cas de cellules vides qui créent des « trous ».
                    $ref = '';
                    if (preg_match('/\br="([A-Za-z]+)\d+"/', $attrs, $rMatch)) {
                        $ref = strtoupper($rMatch[1]);
                    } elseif (preg_match('/\br="([^"]+)"/', $attrs, $rMatch)) {
                        $colLetters = preg_replace('/\d/', '', $rMatch[1]);
                        $ref = strtoupper($colLetters);
                    }

                    // type de cellule : t="s" => shared string, t="str" => string inline
                    $type = '';
                    if (preg_match('/\bt="([^"]+)"/', $attrs, $tMatch)) {
                        $type = $tMatch[1];
                    }

                    // valeur <v>
                    $value = null;
                    if (preg_match('/<v\b[^>]*>(.*?)<\/v>/s', $inner, $vMatch)) {
                        $value = $vMatch[1];
                    } elseif (preg_match('/<is\b[^>]*><t\b[^>]*>(.*?)<\/t><\/is>/s', $inner, $isMatch)) {
                        // inline string
                        $value = self::decodeEntities($isMatch[1]);
                        $type  = 'str';
                    }

                    // conversion selon le type
                    $value = self::castValue($value, $type, $shared);

                    // colonne numérique à partir des lettres
                    $colIndex = self::colLettersToIndex($ref);
                    $cells[$colIndex] = $value;
                }
            }
            // ré-indexation pour combler les trous
            if (!empty($cells)) {
                $maxCol = max(array_keys($cells));
                $row = [];
                for ($i = 0; $i <= $maxCol; $i++) {
                    $row[$i] = $cells[$i] ?? null;
                }
                $rows[] = $row;
            } else {
                $rows[] = [];
            }
        }
        return $rows;
    }

    private static function castValue($value, $type, array $shared)
    {
        if ($value === null) return null;

        if ($type === 's') {
            // shared string
            $idx = (int)$value;
            return $shared[$idx] ?? null;
        }
        if ($type === 'str' || $type === 'inlineStr') {
            return self::decodeEntities((string)$value);
        }
        // numérique => on garde tel quel (peut être date/heure fractionnaire)
        if (is_numeric($value)) {
            // parseFloat pour préserver la précision
            return (float)$value + 0;
        }
        return self::decodeEntities((string)$value);
    }

    /** Convertit des lettres de colonne (A, B, ... AA) en index numérique (0-based). */
    public static function colLettersToIndex($letters)
    {
        $letters = strtoupper((string)$letters);
        $n = 0;
        $len = strlen($letters);
        for ($i = 0; $i < $len; $i++) {
            $n = $n * 26 + (ord($letters[$i]) - ord('A') + 1);
        }
        return $n - 1;
    }

    /** Décode les entités XML. */
    private static function decodeEntities($s)
    {
        return html_entity_decode($s, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }

    // ================================================================
    //  UTILITAIRES DE CONVERSION (dates & heures Excel)
    // ================================================================

    /**
     * Convertit un numéro de série Excel (ou un datetime) en date Y-m-d.
     * Le terminal exporte parfois la date en datetime, parfois en numéro série.
     *
     * @param mixed $valeur  datetime | string | float(int) série Excel
     * @return string|null   Y-m-d ou null si vide
     */
    public static function excelToDate($valeur)
    {
        if ($valeur === null || $valeur === '') return null;

        // Cas 1 : déjà un objet DateTime
        if ($valeur instanceof DateTime) {
            return $valeur->format('Y-m-d');
        }
        // Cas 2 : chaîne. Le lecteur XLSX renvoie souvent les nombres Excel
        // sous forme de texte (ex. "46188"). Il faut donc tester is_numeric
        // avant strtotime(), sinon toutes ces dates sont rejetées.
        if (is_string($valeur)) {
            $valeur = trim($valeur);

            if ($valeur !== '' && is_numeric($valeur)) {
                $epoch = new DateTime(self::EXCEL_EPOCH);
                $days = (int)floor((float)$valeur);
                $epoch->modify('+' . $days . ' days');
                return $epoch->format('Y-m-d');
            }

            if (preg_match('/^\d{4}-\d{2}-\d{2}/', $valeur)) {
                return substr($valeur, 0, 10);
            }
            // format dd/mm/yyyy
            if (preg_match('#^(\d{1,2})/(\d{1,2})/(\d{4})#', $valeur, $m)) {
                return sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]);
            }
            $ts = strtotime($valeur);
            if ($ts !== false) {
                return date('Y-m-d', $ts);
            }
            return null;
        }
        // Cas 3 : numérique (série Excel)
        if (is_int($valeur) || is_float($valeur)) {
            $epoch = new DateTime(self::EXCEL_EPOCH);
            $days = (int)$valeur;
            $epoch->modify("+$days days");
            return $epoch->format('Y-m-d');
        }
        return null;
    }

    /**
     * Convertit une fraction de jour Excel (0.42...) en heure HH:MM:SS.
     *
     * @param mixed $valeur  float fraction | string "HH:MM:SS" | DateTime
     * @return string|null
     */
    public static function excelToTime($valeur)
    {
        if ($valeur === null || $valeur === '') return null;

        // déjà une heure au format texte
        if (is_string($valeur)) {
            $valeur = trim($valeur);
            if (preg_match('/^\d{1,2}:\d{2}(:\d{2})?$/', $valeur)) {
                $parts = explode(':', $valeur);
                return sprintf('%02d:%02d:00', $parts[0], $parts[1]);
            }
            $ts = strtotime($valeur);
            if ($ts !== false) return date('H:i:s', $ts);
            return null;
        }
        // DateTime
        if ($valeur instanceof DateTime) {
            return $valeur->format('H:i:s');
        }
        // numérique fraction de jour
        if (is_numeric($valeur)) {
            $totalSeconds = (int)round(((float)$valeur) * 86400);
            // normalise sur 24h (certains pointages dépassent minuit)
            $totalSeconds = $totalSeconds % 86400;
            if ($totalSeconds < 0) $totalSeconds += 86400;
            $h = intdiv($totalSeconds, 3600);
            $m = intdiv($totalSeconds % 3600, 60);
            $s = $totalSeconds % 60;
            return sprintf('%02d:%02d:%02d', $h, $m, $s);
        }
        return null;
    }

    /**
     * Lit un fichier CSV et renvoie un tableau associatif.
     */
    public static function readCsv($fichier, $delimiter = ',', $firstRowHeader = true)
    {
        $rows = [];
        if (($handle = fopen($fichier, 'r')) !== false) {
            // BOM UTF-8
            $first = fread($handle, 3);
            if ($first !== "\xEF\xBB\xBF") {
                rewind($handle);
            }
            $headers = null;
            while (($data = fgetcsv($handle, 0, $delimiter)) !== false) {
                $data = array_map(function ($v) {
                    return trim($v, "\xEF\xBB\xBF \t\n\r");
                }, $data);
                if ($firstRowHeader && $headers === null) {
                    $headers = $data;
                    continue;
                }
                if ($firstRowHeader && $headers !== null) {
                    $assoc = [];
                    foreach ($headers as $i => $h) {
                        $assoc[$h] = $data[$i] ?? null;
                    }
                    $rows[] = $assoc;
                } else {
                    $rows[] = $data;
                }
            }
            fclose($handle);
        }
        return $rows;
    }
}
