MODULE PERSONNELS — DRHKAT
==========================

Le menu « Personnels » exploite directement les tables existantes :
- personnel (clé primaire CODE_AGENT)
- entite (clé primaire IdEntite)
- appartenance (clé primaire IdAppartenance)

Correspondances appliquées par l'application :
- personnel.CODE_SITE -> entite.IdEntite
- personnel.SITE <- entite.CommentaireEnt (ou entite.Site si le commentaire est vide)
- personnel.CODE_ENTITE -> appartenance.IdAppartenance
- personnel.ENTITE <- appartenance.CommentaireAppart (ou DesignationAppart si le commentaire est vide)

Aucune création de table n'est nécessaire lorsque la base edrhk2581223_21zrkh
contient déjà ces trois tables. Le bouton « Synchroniser les libellés » remet à jour
SITE et ENTITE pour toutes les fiches existantes.

Fonctions : tableau de bord, graphiques, CRUD contrôlé par rôle, journal d'audit,
filtrage dépendant site/appartenance, tri, recherche, réorganisation des colonnes,
affichage/masquage, regroupement dynamique, export CSV et impression.
