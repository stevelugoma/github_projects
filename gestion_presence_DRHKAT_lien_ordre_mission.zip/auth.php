<?php
/**
 * auth.php — Gestion de l'authentification.
 * À inclure en tête de chaque page protégée : require 'auth.php';
 */
require_once __DIR__ . '/helpers.php';

// Pages accessibles sans connexion
$pagesLibres = ['login.php', 'logout.php', 'install.php'];

$script = basename($_SERVER['SCRIPT_NAME']);

if (!in_array($script, $pagesLibres, true)) {
    if (!isset($_SESSION['user'])) {
        flash('warning', 'Veuillez vous connecter pour accéder à l\'application.');
        redirect('login.php');
    }
    $permissionPage = function_exists('permissionPageCourante') ? permissionPageCourante($script) : null;
    if ($permissionPage && !aPermission($permissionPage)) {
        flash('error', 'Accès non autorisé à ce module.');
        redirect('index.php');
    }
    // compte inactif ?
    if (empty($_SESSION['user']['actif'])) {
        session_destroy();
        flash('error', 'Votre compte est désactivé. Contactez l\'administrateur.');
        redirect('login.php');
    }
}
