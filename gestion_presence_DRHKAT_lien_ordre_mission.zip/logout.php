<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/helpers.php';
if (isset($_SESSION['user'])) {
    logAudit('logout', 'utilisateur', $_SESSION['user']['id']);
}
session_destroy();
redirect('login.php');
