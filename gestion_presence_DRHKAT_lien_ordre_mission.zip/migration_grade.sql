DROP TABLE IF EXISTS `grade`;
CREATE TABLE IF NOT EXISTS `grade` (
  `id_gr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `sigle_grade` varchar(10) DEFAULT NULL,
  `Libelle_complete` text,
  `Code` int(10) UNSIGNED DEFAULT NULL,
  `Commentaire` text,
  `ordre_gr` int(2) UNSIGNED DEFAULT NULL,
  `Categorie` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_gr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `grade` (`id_gr`, `sigle_grade`, `Libelle_complete`, `Code`, `Commentaire`, `ordre_gr`, `Categorie`) VALUES
(1, 'DIR', 'Directeur', 120, '', 1, 'Catégorie A, hauts fonctionnaires'),
(2, 'CDII', 'Chef de Division de deuxième niveau', 130, '', 2, 'Catégorie B, cadres supérieurs'),
(3, 'CDI', 'Chef de Division de Deuxième niveau', 130, '', 3, 'Catégorie B, cadres supérieurs'),
(4, 'CBII', 'Chef de Bureau de Deuxième Niveau', 140, '', 4, 'Catégorie B, cadres supérieurs'),
(5, 'CBI', 'Chef de Bureau de Premier Niveau', 140, '', 5, 'Catégorie B, cadres supérieurs'),
(6, 'ATAII-1', 'Attaché d’Administration de 2ème Classe Echellon 1', 210, '', 6, 'Catégorie C, agents de collaboration'),
(7, 'ATAI-1', 'Attaché d’Administration de 1ère Classe Echellon 1', 210, '', 7, 'Catégorie C, agents de collaboration'),
(8, 'AGAI-2', 'Agent d’Administration de 2ème Classe', 320, '', 8, 'Catégorie D, agents d’exécution'),
(9, 'AGAI-1', 'Agent d’Administration de 1ère Classe', 320, '', 9, 'Catégorie D, agents d’exécution'),
(10, 'AAII', 'Agent Auxiliaire de 2ème Classe', 330, '', 10, 'Catégorie D, agents d’exécution'),
(11, 'AAI', 'Agent Auxiliaire de 1ère Classe', 330, '', 11, 'Catégorie D, agents d’exécution'),
(12, 'H', 'Huissier', 350, '', 12, 'Catégorie D, agents d’exécution');
COMMIT;
