-- ============================================================
--  SCHÉMA DE LA BASE DE DONNÉES — Gestion du personnel & présences
--  Application pour terminal biométrique XI FACE2000
--  Clé métier principale : numero_identification (VARCHAR)
-- ============================================================

-- ---- UTILISATEURS DE L'APPLICATION (comptes d'accès) ----
CREATE TABLE IF NOT EXISTS utilisateurs (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    identifiant      VARCHAR(60)  NOT NULL UNIQUE,
    mot_de_passe     VARCHAR(255) NOT NULL,
    nom_complet      VARCHAR(150) NOT NULL,
    role             ENUM('Administrateur','Gestionnaire RH','Gestionnaire présences','Validateur','Consultation','Agent') NOT NULL DEFAULT 'Consultation',
    actif            TINYINT(1)   NOT NULL DEFAULT 1,
    derniere_connexion DATETIME NULL,
    date_creation    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---- AGENTS (référentiel du personnel) ----
-- numero_identification est la CLÉ PRIMAIRE MÉTIER (RG-01)
CREATE TABLE IF NOT EXISTS agents (
    numero_identification VARCHAR(50)  NOT NULL PRIMARY KEY,
    nom_complet           VARCHAR(200) NULL,           -- nettoyé à l'import
    postnom               VARCHAR(100) NULL,
    prenom                VARCHAR(100) NULL,
    sexe                  ENUM('M','F','') NOT NULL DEFAULT '',
    telephone             VARCHAR(30)  NULL,
    fonction              VARCHAR(150) NULL,
    service               VARCHAR(150) NULL,
    site                  VARCHAR(150) NULL,
    date_engagement       DATE NULL,
    -- données techniques issues du terminal FACE2000
    numero_carte          VARCHAR(50)  NULL,
    groupe_device         VARCHAR(50)  NULL,
    privilege_device      VARCHAR(50)  NULL,
    departement_source    VARCHAR(150) NULL,
    option_source         VARCHAR(50)  NULL,
    -- gestion logique (RG-09 : la désactivation n'efface pas l'historique)
    statut                TINYINT(1)   NOT NULL DEFAULT 1,  -- 1=actif, 0=inactif
    date_creation         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    date_modification     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---- LOTS D'IMPORT (historique des imports de présences) ----
CREATE TABLE IF NOT EXISTS import_lot (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    nom_fichier      VARCHAR(255) NOT NULL,
    type_import      VARCHAR(30)  NOT NULL DEFAULT 'presences',  -- 'presences' ou 'agents'
    date_import      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    utilisateur_id   INT NULL,
    empreinte_lot    VARCHAR(64)  NULL,         -- sha1 du contenu pour anti-doublon de lot
    nb_lues          INT NOT NULL DEFAULT 0,
    nb_acceptees     INT NOT NULL DEFAULT 0,
    nb_rejetees      INT NOT NULL DEFAULT 0,
    nb_doublons      INT NOT NULL DEFAULT 0,
    rapport          TEXT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---- PASSAGES BRUTS (chaque DANS / DEHORS du terminal) ----
-- Conserve fidèlement les passages issus du fichier (RG-13)
CREATE TABLE IF NOT EXISTS passage_brut (
    id               BIGINT AUTO_INCREMENT PRIMARY KEY,
    numero_identification VARCHAR(50) NOT NULL,
    date_passage     DATE NOT NULL,
    heure_passage    TIME NOT NULL,
    sens             ENUM('IN','OUT') NOT NULL,
    rang             TINYINT NOT NULL DEFAULT 1,        -- 1, 2 ou 3
    nom_source       VARCHAR(200) NULL,                  -- nom informatif du fichier
    ligne_source     INT NULL,
    import_lot_id    INT NULL,
    empreinte        VARCHAR(64) NOT NULL,               -- anti-doublon (RG-12)
    date_creation    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_passage (empreinte),
    KEY idx_agent_date (numero_identification, date_passage),
    KEY idx_date (date_passage)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---- PRÉSENCE JOURNALIÈRE CALCULÉE ----
-- Synthèse par agent et par jour (RG-14)
CREATE TABLE IF NOT EXISTS presence_journaliere (
    id               BIGINT AUTO_INCREMENT PRIMARY KEY,
    numero_identification VARCHAR(50) NOT NULL,
    date_presence    DATE NOT NULL,
    premiere_entree  TIME NULL,
    derniere_sortie  TIME NULL,
    duree_minutes    INT NULL,            -- durée de présence
    retard_minutes   INT NOT NULL DEFAULT 0,
    tranche_retard   VARCHAR(20) NULL,    -- léger / moyen / grave / aucun
    horaire_applique VARCHAR(100) NULL,
    statut           VARCHAR(40) NOT NULL DEFAULT 'present',  -- present, absent, conge, mission, ...
    anomalies        VARCHAR(255) NULL,    -- ex: "sortie_manquante", "nom_divergent"
    saisie_manuelle  TINYINT(1) NOT NULL DEFAULT 0,
    motif_correction VARCHAR(255) NULL,
    UNIQUE KEY uq_presence (numero_identification, date_presence),
    KEY idx_date (date_presence),
    KEY idx_statut (statut)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---- HORAIRES (général, service, catégorie, individuel) ----
CREATE TABLE IF NOT EXISTS horaire (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    libelle          VARCHAR(150) NOT NULL,
    portee           ENUM('general','service','site','categorie','individuel') NOT NULL DEFAULT 'general',
    cible            VARCHAR(150) NULL,    -- nom du service, site, catégorie ou agent concerné
    heure_entree     TIME NOT NULL,
    heure_sortie     TIME NOT NULL,
    tolerance_min    INT NOT NULL DEFAULT 0,
    jours_ouvrables  VARCHAR(20) NOT NULL DEFAULT '12345',  -- 1=lun ... 7=dim
    date_effet       DATE NULL,
    actif            TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---- AFFECTATION D'HORAIRE À UN AGENT (avec période de validité) ----
-- Sert notamment aux horaires des femmes allaitantes (RG-05, RG-11)
CREATE TABLE IF NOT EXISTS affectation_horaire (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    numero_identification VARCHAR(50) NOT NULL,
    horaire_id       INT NOT NULL,
    type             ENUM('individuel','allaitement','mission','autre') NOT NULL DEFAULT 'individuel',
    date_debut       DATE NOT NULL,
    date_fin         DATE NOT NULL,
    motif            VARCHAR(255) NULL,
    decision_ref     VARCHAR(150) NULL,
    horaire_base_id  INT NULL,
    duree_minutes    INT NULL,
    modalite         VARCHAR(30) NULL,
    observation      TEXT NULL,
    valide           TINYINT(1) NOT NULL DEFAULT 0,
    date_creation    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_agent (numero_identification),
    KEY idx_dates (date_debut, date_fin)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---- ABSENCES ----
CREATE TABLE IF NOT EXISTS absence (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    numero_identification VARCHAR(50) NOT NULL,
    date_debut       DATE NOT NULL,
    date_fin         DATE NOT NULL,
    type             ENUM('justifiee','injustifiee','maladie','autorisation','mission','autre') NOT NULL DEFAULT 'injustifiee',
    motif            VARCHAR(255) NULL,
    justificatif     VARCHAR(255) NULL,
    statut           ENUM('en_attente','validee','rejetee') NOT NULL DEFAULT 'en_attente',
    valide_par       INT NULL,
    date_validation  DATETIME NULL,
    date_creation    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_agent (numero_identification),
    KEY idx_dates (date_debut, date_fin)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---- CONGÉS ----
CREATE TABLE IF NOT EXISTS conge (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    numero_identification VARCHAR(50) NOT NULL,
    type             VARCHAR(60) NOT NULL DEFAULT 'annuel',  -- annuel, maladie, maternité, exceptionnel...
    date_debut       DATE NOT NULL,
    date_fin         DATE NOT NULL,
    reference        VARCHAR(150) NULL,
    piece_jointe     VARCHAR(255) NULL,
    valide_par       INT NULL,
    statut           ENUM('en_attente','validee','rejetee') NOT NULL DEFAULT 'validee',
    date_creation    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_agent (numero_identification),
    KEY idx_dates (date_debut, date_fin)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---- JOURS FÉRIÉS / REPOS ----
CREATE TABLE IF NOT EXISTS jour_ferie (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    date_jour        DATE NOT NULL UNIQUE,
    libelle          VARCHAR(150) NOT NULL,
    type             ENUM('ferie','repos') NOT NULL DEFAULT 'ferie'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---- PARAMÈTRES DE L'APPLICATION ----
CREATE TABLE IF NOT EXISTS parametres (
    cle              VARCHAR(60) PRIMARY KEY,
    valeur           VARCHAR(255) NULL,
    description      VARCHAR(255) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---- JOURNAL D'AUDIT (RG-08) ----
CREATE TABLE IF NOT EXISTS audit_log (
    id               BIGINT AUTO_INCREMENT PRIMARY KEY,
    utilisateur_id   INT NULL,
    utilisateur_nom  VARCHAR(150) NULL,
    action           VARCHAR(60) NOT NULL,   -- create, update, delete, import, login...
    objet            VARCHAR(60) NULL,        -- agent, presence, absence, conge...
    objet_id         VARCHAR(60) NULL,
    ancienne_valeur  TEXT NULL,
    nouvelle_valeur  TEXT NULL,
    date_action      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    adresse_ip       VARCHAR(45) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS entite (
    IdEntite SMALLINT NOT NULL AUTO_INCREMENT,
    Site VARCHAR(45) NOT NULL,
    CommentaireEnt MEDIUMTEXT NULL,
    PRIMARY KEY (IdEntite)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

CREATE TABLE IF NOT EXISTS appartenance (
    IdAppartenance SMALLINT NOT NULL AUTO_INCREMENT,
    DesignationAppart VARCHAR(200) NULL,
    Entite SMALLINT NULL,
    CommentaireAppart MEDIUMTEXT NULL,
    PRIMARY KEY (IdAppartenance),
    KEY idx_appartenance_entite (Entite)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

CREATE TABLE IF NOT EXISTS personnel (
    CODE_AGENT INT(7) UNSIGNED NOT NULL,
    NOMS VARCHAR(150) NULL,
    CODE_SITE INT(5) UNSIGNED NULL,
    SITE VARCHAR(100) NULL,
    CODE_ENTITE INT(7) UNSIGNED NULL,
    ENTITE VARCHAR(150) NULL,
    CODE_DIV INT(5) UNSIGNED NULL,
    DIVISION VARCHAR(150) NULL,
    CODE_GRADE VARCHAR(5) NULL,
    GRADES VARCHAR(20) NULL,
    CODE_FONCTION INT(10) UNSIGNED NULL,
    FONCTION_AGENT VARCHAR(200) NULL,
    MATRICULE VARCHAR(50) NULL,
    PRIMARY KEY (CODE_AGENT),
    KEY idx_personnel_site (CODE_SITE),
    KEY idx_personnel_entite (CODE_ENTITE),
    KEY idx_personnel_fonction (CODE_FONCTION),
    KEY idx_personnel_matricule (MATRICULE)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;


-- Référentiel des divisions
CREATE TABLE IF NOT EXISTS division (
  ID_DIV INT(2) NOT NULL,
  DIVISION VARCHAR(55) DEFAULT NULL,
  CODE_DIV INT(3) DEFAULT NULL,
  PRIMARY KEY (ID_DIV),
  KEY idx_division_code (CODE_DIV)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

INSERT IGNORE INTO division (ID_DIV,DIVISION,CODE_DIV) VALUES
(1,'DIRECTION',1),
(2,'DIVISION DES RESSOURCES HUMAINES ET DE L\'ADMINISTRATION',2),
(3,'DIVISION DES FINANCES',3),
(4,'DIVISION DE L\'INFORMATIQUE',4),
(5,'DIVISION DE L\'INSPECTION ET CONTENTIEUX',5),
(6,'DIVISION SUIVI DES IMPÔTS',6),
(7,'DIVISION DE RECOUVREMENT',7),
(8,'DIVISION DES TERRITOIRES',8),
(9,'DIVISION URBAINE DE LUBUMBASHI',15),
(10,'DIVISION URBAINE DE LIKASI',22),
(11,'DIVISION URBAINE DE KASUMBALESA SAKANIA',25),
(12,'NON AFFECTE',200);

-- Référentiel des fonctions
CREATE TABLE IF NOT EXISTS fonction (
  id_fonction INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  Libelle_Fonction VARCHAR(200) NOT NULL,
  Sigle_Fonction VARCHAR(45) DEFAULT NULL,
  Commentaires_Fonction TEXT,
  Obs_Fonction TEXT,
  Etat_Fonction VARCHAR(10) DEFAULT NULL,
  PRIMARY KEY (id_fonction)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ---- AUTORISATIONS PERSONNALISÉES PAR UTILISATEUR ----
CREATE TABLE IF NOT EXISTS utilisateur_permission (
    utilisateur_id   INT NOT NULL,
    permission_cle   VARCHAR(100) NOT NULL,
    autorise         TINYINT(1) NOT NULL DEFAULT 1,
    date_modification DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (utilisateur_id, permission_cle),
    KEY idx_permission_cle (permission_cle)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
