<?php
$pageTitle = 'Présences & pointages';
$activePage = 'presences.php';
require_once __DIR__ . '/helpers.php';

$pdo = db();

// ============================================================
//  AJOUT, MODIFICATION ET SUPPRESSION MANUELS
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array($_POST['action'] ?? '', ['save_presence','delete_presence'], true)) {
    exigerPermission('presences.manage', 'presences.php');
    $actionCrud = $_POST['action'];

    if ($actionCrud === 'delete_presence') {
        $id = (int)($_POST['id'] ?? 0);
        $oldStmt = $pdo->prepare("SELECT * FROM presence_journaliere WHERE id=?");
        $oldStmt->execute([$id]);
        $old = $oldStmt->fetch();
        if ($old) {
            try {
                $pdo->beginTransaction();
                $pdo->prepare("DELETE FROM passage_brut WHERE numero_identification=? AND date_passage=?")
                    ->execute([$old['numero_identification'], $old['date_presence']]);
                $pdo->prepare("DELETE FROM presence_journaliere WHERE id=?")->execute([$id]);
                $pdo->commit();
                logAudit('delete', 'presence', $id, $old, null);
                flash('success', 'Présence et pointages associés supprimés.');
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                flash('error', 'Suppression impossible : ' . $e->getMessage());
            }
        }
        redirect('presences.php');
    }

    $id = (int)($_POST['id'] ?? 0);
    $numId = trim($_POST['numero_identification'] ?? '');
    $date = $_POST['date_presence'] ?? '';
    $entree = trim($_POST['premiere_entree'] ?? '');
    $sortie = trim($_POST['derniere_sortie'] ?? '');
    $statut = $_POST['statut'] ?? 'present';
    $motif = trim($_POST['motif_correction'] ?? '');

    if ($numId === '' || $date === '') {
        flash('error', 'L’agent et la date sont obligatoires.');
        redirect('presences.php' . ($id ? '?action=edit&id=' . $id : '?action=add'));
    }
    $checkAgent = $pdo->prepare("SELECT 1 FROM agents WHERE numero_identification=?");
    $checkAgent->execute([$numId]);
    if (!$checkAgent->fetchColumn()) {
        flash('error', 'Agent introuvable.');
        redirect('presences.php');
    }

    $entreeSql = $entree !== '' ? $entree . (strlen($entree) === 5 ? ':00' : '') : null;
    $sortieSql = $sortie !== '' ? $sortie . (strlen($sortie) === 5 ? ':00' : '') : null;
    $horaire = horaireApplique($numId, $date);
    $retard = $entreeSql ? calculerRetard($entreeSql, $horaire['heure_entree'], $horaire['tolerance_min']) : 0;
    $tranche = trancheRetard($retard);
    $duree = ($entreeSql && $sortieSql) ? dureeMinutes($entreeSql, $sortieSql) : null;
    $anomalies = [];
    if ($entreeSql && !$sortieSql) $anomalies[] = 'sortie_manquante';
    if (!$entreeSql && $sortieSql) $anomalies[] = 'entree_manquante';

    $old = null;
    if ($id) {
        $st = $pdo->prepare("SELECT * FROM presence_journaliere WHERE id=?");
        $st->execute([$id]);
        $old = $st->fetch();
        if (!$old) {
            flash('error', 'Présence introuvable.');
            redirect('presences.php');
        }
    }

    try {
        $pdo->beginTransaction();
        if ($old && ($old['numero_identification'] !== $numId || $old['date_presence'] !== $date)) {
            $pdo->prepare("DELETE FROM passage_brut WHERE numero_identification=? AND date_passage=?")
                ->execute([$old['numero_identification'], $old['date_presence']]);
        }

        if ($id) {
            $sql = "UPDATE presence_journaliere SET numero_identification=?,date_presence=?,premiere_entree=?,derniere_sortie=?,duree_minutes=?,retard_minutes=?,tranche_retard=?,horaire_applique=?,statut=?,anomalies=?,saisie_manuelle=1,motif_correction=? WHERE id=?";
            $pdo->prepare($sql)->execute([$numId,$date,$entreeSql,$sortieSql,$duree,$retard,$tranche,$horaire['libelle'],$statut,implode('|',$anomalies),$motif ?: null,$id]);
        } else {
            $sql = "INSERT INTO presence_journaliere (numero_identification,date_presence,premiere_entree,derniere_sortie,duree_minutes,retard_minutes,tranche_retard,horaire_applique,statut,anomalies,saisie_manuelle,motif_correction) VALUES (?,?,?,?,?,?,?,?,?,?,1,?)";
            $pdo->prepare($sql)->execute([$numId,$date,$entreeSql,$sortieSql,$duree,$retard,$tranche,$horaire['libelle'],$statut,implode('|',$anomalies),$motif ?: null]);
            $id = (int)$pdo->lastInsertId();
        }

        // Aligne les pointages bruts de rang 1 sur la saisie manuelle.
        $pdo->prepare("DELETE FROM passage_brut WHERE numero_identification=? AND date_passage=? AND rang=1")
            ->execute([$numId,$date]);
        $insPass = $pdo->prepare("INSERT INTO passage_brut (numero_identification,date_passage,heure_passage,sens,rang,nom_source,ligne_source,import_lot_id,empreinte) VALUES (?,?,?,?,1,'saisie_manuelle',NULL,NULL,?)");
        if ($entreeSql) $insPass->execute([$numId,$date,$entreeSql,'IN',sha1('manual|'.$numId.'|'.$date.'|IN|1')]);
        if ($sortieSql) $insPass->execute([$numId,$date,$sortieSql,'OUT',sha1('manual|'.$numId.'|'.$date.'|OUT|1')]);

        $pdo->commit();
        logAudit($old ? 'update' : 'create', 'presence', $id, $old, $_POST);
        flash('success', $old ? 'Présence modifiée avec succès.' : 'Présence ajoutée avec succès.');
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('error', 'Enregistrement impossible : ' . $e->getMessage());
    }
    redirect('presences.php');
}

// ============================================================
//  TRAITEMENT IMPORT
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'import') {
    exigerPermission('presences.import','presences.php');
    if (!empty($_FILES['fichier']['tmp_name'])) {
        importerPresences($_FILES['fichier']);
    }
    redirect('presences.php');
}

// ============================================================
//  FONCTION D'IMPORT DES PRÉSENCES (FACE2000)
//  Gère : date (datetime OU série Excel), heures en fraction de jour,
//  3 couples DANS/DEHORS, détection des doublons (RG-12), numéros inconnus.
// ============================================================
function importerPresences($file) {
    global $pdo;

    $tmp  = $file['tmp_name'];
    $name = $file['name'];
    $ext  = strtolower(pathinfo($name, PATHINFO_EXTENSION));

    try {
        if ($ext === 'xlsx') {
            $rows = XlsxReader::read($tmp);
        } elseif ($ext === 'csv') {
            $rows = XlsxReader::readCsv($tmp, ',');
            if (empty($rows)) {
                $rows = XlsxReader::readCsv($tmp, ';');
            }
        } else {
            flash('error', "Format non supporté. Utilisez .xlsx ou .csv.");
            return;
        }
    } catch (Throwable $e) {
        flash('error', "Lecture du fichier impossible : " . $e->getMessage());
        return;
    }

    if (empty($rows)) {
        flash('error', "Le fichier est vide.");
        return;
    }

    /*
     * Une empreinte identique n'est plus bloquante. Le fichier peut être
     * réimporté : les créneaux absents sont ajoutés, les heures modifiées
     * sont mises à jour et les valeurs inchangées restent intactes.
     */
    $empreinteLot = sha1_file($tmp);
    $checkLot = $pdo->prepare("SELECT COUNT(*) FROM import_lot WHERE empreinte_lot=? AND type_import='presences'");
    $checkLot->execute(array($empreinteLot));
    $estReimport = ((int)$checkLot->fetchColumn() > 0);

    $first = $rows[0];
    $col = detecterColonnesPresences($first);

    $agentsValides = $pdo->query("SELECT numero_identification, nom_complet FROM agents")
                         ->fetchAll(PDO::FETCH_KEY_PAIR);
    $agentsValides = array_change_key_case($agentsValides, CASE_LOWER);

    $lus = 0;
    $ajoutes = 0;
    $modifies = 0;
    $inchanges = 0;
    $inconnus = 0;
    $divergences = 0;
    $rejets = array();
    $datesImportees = array();

    try {
        $pdo->beginTransaction();

        $pdo->prepare("INSERT INTO import_lot
            (nom_fichier, type_import, utilisateur_id, empreinte_lot, rapport)
            VALUES (?, 'presences', ?, ?, 'synchronisation en cours')")
            ->execute(array(
                $name,
                isset($_SESSION['user']['id']) ? $_SESSION['user']['id'] : null,
                $empreinteLot
            ));
        $lotId = (int)$pdo->lastInsertId();

        foreach ($rows as $i => $r) {
            $lus++;
            $numLigne = $i + 2;

            $dateBrut = isset($r[$col['Date']]) ? $r[$col['Date']] : null;
            $numId = nettoyerValPres(isset($r[$col['Numero']]) ? $r[$col['Numero']] : null);
            $nomFic = nettoyerValPres(isset($r[$col['Nom']]) ? $r[$col['Nom']] : null);

            $date = XlsxReader::excelToDate($dateBrut);
            if (!$date) {
                $rejets[] = "Ligne " . $numLigne . " : date invalide";
                continue;
            }
            if ($numId === '') {
                $rejets[] = "Ligne " . $numLigne . " : numéro d'identification manquant";
                continue;
            }

            $numIdLower = strtolower($numId);
            if (!isset($agentsValides[$numIdLower])) {
                $inconnus++;
                $rejets[] = "Ligne " . $numLigne . " : numéro « " . $numId . " » inconnu dans le référentiel agents";
                continue;
            }

            $datesImportees[$date] = true;
            $nomOfficiel = $agentsValides[$numIdLower];
            if ($nomFic !== '' && $nomOfficiel && strcasecmp(trim($nomFic), trim($nomOfficiel)) !== 0) {
                $divergences++;
            }

            $couples = array(
                array(isset($r[$col['DANS1']]) ? $r[$col['DANS1']] : null, isset($r[$col['DEHORS1']]) ? $r[$col['DEHORS1']] : null, 1),
                array(isset($r[$col['DANS2']]) ? $r[$col['DANS2']] : null, isset($r[$col['DEHORS2']]) ? $r[$col['DEHORS2']] : null, 2),
                array(isset($r[$col['DANS3']]) ? $r[$col['DANS3']] : null, isset($r[$col['DEHORS3']]) ? $r[$col['DEHORS3']] : null, 3)
            );

            foreach ($couples as $couple) {
                $dans = $couple[0];
                $dehors = $couple[1];
                $rang = $couple[2];

                /* Une cellule vide ne supprime jamais une donnée existante. */
                if ($dans !== null && trim((string)$dans) !== '') {
                    $heure = XlsxReader::excelToTime($dans);
                    if ($heure) {
                        $etat = synchroniserPassage($numId, $date, $heure, 'IN', $rang, $nomFic, $numLigne, $lotId);
                        if ($etat === 'ajoute') $ajoutes++;
                        elseif ($etat === 'modifie') $modifies++;
                        else $inchanges++;
                    } else {
                        $rejets[] = "Ligne " . $numLigne . " : heure DANS" . $rang . " invalide";
                    }
                }

                if ($dehors !== null && trim((string)$dehors) !== '') {
                    $heure = XlsxReader::excelToTime($dehors);
                    if ($heure) {
                        $etat = synchroniserPassage($numId, $date, $heure, 'OUT', $rang, $nomFic, $numLigne, $lotId);
                        if ($etat === 'ajoute') $ajoutes++;
                        elseif ($etat === 'modifie') $modifies++;
                        else $inchanges++;
                    } else {
                        $rejets[] = "Ligne " . $numLigne . " : heure DEHORS" . $rang . " invalide";
                    }
                }
            }
        }

        $datesList = array_keys($datesImportees);
        sort($datesList);
        $nbCalc = 0;
        if (!empty($datesList)) {
            $nbCalc = recalculerPresences($datesList[0], $datesList[count($datesList) - 1]);
        }

        $rapport = empty($rejets) ? '' : implode("\n", array_slice($rejets, 0, 100));
        $pdo->prepare("UPDATE import_lot
            SET nb_lues=?, nb_acceptees=?, nb_rejetees=?, nb_doublons=?, rapport=?
            WHERE id=?")
            ->execute(array($lus, $ajoutes + $modifies, count($rejets), $inchanges, $rapport, $lotId));

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        flash('error', "Échec de la synchronisation : " . $e->getMessage());
        return;
    }

    logAudit(
        'import',
        'presence',
        null,
        null,
        "Fichier: " . $name . " — " . $ajoutes . " ajoutés, " . $modifies . " modifiés, " . $inchanges . " inchangés"
    );

    $titre = $estReimport ? "Réimportation / synchronisation" : "Import";
    $msg = "✅ <b>" . $titre . " de " . h($name) . " terminé(e)</b> :<br>"
         . "&nbsp;&nbsp;• <b>" . $lus . "</b> lignes lues<br>"
         . "&nbsp;&nbsp;• <b>" . $ajoutes . "</b> passage(s) manquant(s) ajouté(s)<br>"
         . "&nbsp;&nbsp;• <b>" . $modifies . "</b> passage(s) mis à jour<br>"
         . "&nbsp;&nbsp;• <b>" . $inchanges . "</b> passage(s) déjà à jour<br>"
         . "&nbsp;&nbsp;• <b>" . $inconnus . "</b> numéro(s) inconnu(s)<br>"
         . "&nbsp;&nbsp;• <b>" . $divergences . "</b> divergence(s) numéro/nom<br>"
         . "&nbsp;&nbsp;• <b>" . $nbCalc . "</b> présence(s) journalière(s) recalculée(s)";

    if (!empty($rejets)) {
        $msg .= "<br><br>⚠️ <b>" . count($rejets) . "</b> rejet(s) — voir le rapport ci-dessous.";
    }

    $_SESSION['import_result'] = array(
        'message' => $msg,
        'rejets' => $rejets
    );
}

/**
 * Synchronise un créneau logique unique : agent + date + sens + rang.
 * Retourne ajoute, modifie ou inchange.
 */
function synchroniserPassage($numId, $date, $heure, $sens, $rang, $nomFic, $numLigne, $lotId) {
    $pdo = db();

    $select = $pdo->prepare("SELECT id, heure_passage
        FROM passage_brut
        WHERE numero_identification=? AND date_passage=? AND sens=? AND rang=?
        ORDER BY id ASC");
    $select->execute(array($numId, $date, $sens, $rang));
    $existants = $select->fetchAll();

    $empreinte = sha1('slot|' . strtolower($numId) . '|' . $date . '|' . $sens . '|' . $rang);

    if (empty($existants)) {
        $insert = $pdo->prepare("INSERT INTO passage_brut
            (numero_identification, date_passage, heure_passage, sens, rang, nom_source,
             ligne_source, import_lot_id, empreinte)
            VALUES (?,?,?,?,?,?,?,?,?)");
        $insert->execute(array($numId, $date, $heure, $sens, $rang, $nomFic, $numLigne, $lotId, $empreinte));
        return 'ajoute';
    }

    $principal = $existants[0];
    $ancienneHeure = substr((string)$principal['heure_passage'], 0, 8);
    $nouvelleHeure = substr((string)$heure, 0, 8);

    /* Nettoie les anciens doublons éventuels du même créneau. */
    if (count($existants) > 1) {
        $ids = array();
        for ($i = 1; $i < count($existants); $i++) {
            $ids[] = (int)$existants[$i]['id'];
        }
        if (!empty($ids)) {
            $pdo->exec("DELETE FROM passage_brut WHERE id IN (" . implode(',', $ids) . ")");
        }
    }

    if ($ancienneHeure !== $nouvelleHeure) {
        /* Conserver une empreinte temporaire évite un conflit avec un ancien format d'empreinte. */
        $empreinteTemp = sha1($empreinte . '|tmp|' . microtime(true) . '|' . $principal['id']);
        $update = $pdo->prepare("UPDATE passage_brut
            SET heure_passage=?, nom_source=?, ligne_source=?, import_lot_id=?, empreinte=?
            WHERE id=?");
        $update->execute(array($heure, $nomFic, $numLigne, $lotId, $empreinteTemp, $principal['id']));
        return 'modifie';
    }

    $updateSource = $pdo->prepare("UPDATE passage_brut
        SET nom_source=?, ligne_source=?, import_lot_id=?
        WHERE id=?");
    $updateSource->execute(array($nomFic, $numLigne, $lotId, $principal['id']));
    return 'inchange';
}


function detecterColonnesPresences($first) {
    /*
     * XlsxReader::read() renvoie des lignes ASSOCIATIVES :
     *   ['Date' => 46188, "Numéro d'identification" => 1, ...]
     * Il faut donc repérer les colonnes dans les CLÉS du tableau, et non dans
     * les valeurs de la première ligne. L'ancienne version retournait 0,1,2...
     * puis cherchait $r[0], ce qui donnait une date vide pour chaque ligne.
     */
    $keys = array_keys($first);

    // Repli positionnel, mais avec les vrais noms de clés associatives.
    $map = array(
        'Date'    => isset($keys[0]) ? $keys[0] : 'Date',
        'Numero'  => isset($keys[1]) ? $keys[1] : "Numéro d'identification",
        'Nom'     => isset($keys[2]) ? $keys[2] : 'Nom',
        'DANS1'   => isset($keys[3]) ? $keys[3] : 'DANS',
        'DEHORS1' => isset($keys[4]) ? $keys[4] : 'DEHORS',
        'DANS2'   => isset($keys[5]) ? $keys[5] : 'DANS_2',
        'DEHORS2' => isset($keys[6]) ? $keys[6] : 'DEHORS_2',
        'DANS3'   => isset($keys[7]) ? $keys[7] : 'DANS_3',
        'DEHORS3' => isset($keys[8]) ? $keys[8] : 'DEHORS_3'
    );

    foreach ($keys as $key) {
        $raw = trim((string)$key);
        $ascii = strtr($raw, array(
            'À'=>'A','Â'=>'A','Ä'=>'A','Á'=>'A','Ã'=>'A','Å'=>'A',
            'à'=>'a','â'=>'a','ä'=>'a','á'=>'a','ã'=>'a','å'=>'a',
            'Ç'=>'C','ç'=>'c','É'=>'E','È'=>'E','Ê'=>'E','Ë'=>'E',
            'é'=>'e','è'=>'e','ê'=>'e','ë'=>'e','Î'=>'I','Ï'=>'I',
            'î'=>'i','ï'=>'i','Ô'=>'O','Ö'=>'O','ô'=>'o','ö'=>'o',
            'Ù'=>'U','Û'=>'U','Ü'=>'U','ù'=>'u','û'=>'u','ü'=>'u'
        ));
        $norm = strtolower($ascii);
        $norm = preg_replace('/[^a-z0-9]/', '', $norm);

        if ($norm === 'date') {
            $map['Date'] = $key;
        } elseif (in_array($norm, array(
            'numerodidentification', 'numeroidentification', 'identification',
            'numero', 'idnumber', 'id'
        ), true)) {
            $map['Numero'] = $key;
        } elseif (in_array($norm, array('nom', 'name'), true)) {
            $map['Nom'] = $key;
        } elseif ($norm === 'dans') {
            $map['DANS1'] = $key;
        } elseif ($norm === 'dehors') {
            $map['DEHORS1'] = $key;
        } elseif ($norm === 'dans2') {
            $map['DANS2'] = $key;
        } elseif ($norm === 'dehors2') {
            $map['DEHORS2'] = $key;
        } elseif ($norm === 'dans3') {
            $map['DANS3'] = $key;
        } elseif ($norm === 'dehors3') {
            $map['DEHORS3'] = $key;
        }
    }

    return $map;
}
function nettoyerValPres($v) { return $v === null ? '' : trim((string)$v); }

$presenceEdit = null;
if (aPermission('presences.manage') && (($_GET['action'] ?? '') === 'edit') && !empty($_GET['id'])) {
    $st = $pdo->prepare("SELECT * FROM presence_journaliere WHERE id=?");
    $st->execute([(int)$_GET['id']]);
    $presenceEdit = $st->fetch();
}
$agentsPresence = aPermission('presences.manage')
    ? $pdo->query("SELECT numero_identification, nom_complet FROM agents WHERE statut=1 ORDER BY nom_complet")->fetchAll()
    : [];

include __DIR__ . '/partials/layout.php';

// ============================================================
//  VUE
// ============================================================

// ---- résultat d'import à afficher ----
$importResult = $_SESSION['import_result'] ?? null;
unset($_SESSION['import_result']);
?>

<?php if ($importResult): ?>
<div class="card">
    <div class="card-header"><h2>📥 Rapport du dernier import</h2></div>
    <div class="alert alert-<?php echo empty($importResult['rejets']) ? 'success' : 'info'; ?>">
        <?php echo $importResult['message']; ?>
    </div>
    <?php if (!empty($importResult['rejets'])): ?>
        <h3>Détail des rejets (<?php echo count($importResult['rejets']); ?>)</h3>
        <pre class="import-result" style="max-height:280px;overflow:auto;background:#f8fafc;padding:12px;border-radius:6px"><?php
            echo h(implode("\n", $importResult['rejets']));
        ?></pre>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php if (aPermission('presences.manage')): ?>
<div class="card" id="presenceFormCard">
    <div class="card-header">
        <h2><?php echo $presenceEdit ? '✏️ Modifier la présence' : '➕ Ajouter une présence'; ?></h2>
        <?php if ($presenceEdit): ?><a href="presences.php" class="btn btn-sm btn-outline">Annuler</a><?php endif; ?>
    </div>
    <form method="post" action="presences.php">
        <input type="hidden" name="action" value="save_presence">
        <input type="hidden" name="id" value="<?php echo (int)($presenceEdit['id'] ?? 0); ?>">
        <div class="form-grid">
            <div class="form-group">
                <label>Agent *</label>
                <select name="numero_identification" required>
                    <option value="">— Sélectionner —</option>
                    <?php foreach ($agentsPresence as $ag): ?>
                        <option value="<?php echo h($ag['numero_identification']); ?>" <?php echo (($presenceEdit['numero_identification'] ?? '') === $ag['numero_identification']) ? 'selected' : ''; ?>>
                            <?php echo h($ag['numero_identification'] . ' — ' . ($ag['nom_complet'] ?: 'sans nom')); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group"><label>Date *</label><input type="date" name="date_presence" required value="<?php echo h($presenceEdit['date_presence'] ?? date('Y-m-d')); ?>"></div>
            <div class="form-group"><label>Première entrée</label><input type="time" name="premiere_entree" value="<?php echo h(isset($presenceEdit['premiere_entree']) ? substr($presenceEdit['premiere_entree'],0,5) : ''); ?>"></div>
            <div class="form-group"><label>Dernière sortie</label><input type="time" name="derniere_sortie" value="<?php echo h(isset($presenceEdit['derniere_sortie']) ? substr($presenceEdit['derniere_sortie'],0,5) : ''); ?>"></div>
            <div class="form-group">
                <label>Statut</label>
                <select name="statut">
                    <?php foreach (['present'=>'Présent','absent'=>'Absent','present_partiel'=>'Présent partiel','conge'=>'Congé','mission'=>'Mission','ferie'=>'Férié'] as $k=>$v): ?>
                        <option value="<?php echo $k; ?>" <?php echo (($presenceEdit['statut'] ?? 'present') === $k) ? 'selected' : ''; ?>><?php echo $v; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="grid-column:1/-1"><label>Motif / observation</label><textarea name="motif_correction" rows="2"><?php echo h($presenceEdit['motif_correction'] ?? ''); ?></textarea></div>
        </div>
        <div class="form-actions"><button type="submit" class="btn btn-success">💾 <?php echo $presenceEdit ? 'Enregistrer les modifications' : 'Ajouter la présence'; ?></button></div>
    </form>
</div>
<?php endif; ?>

<!-- Bouton import -->
<?php if (aPermission('presences.import')): ?>
<div class="card">
    <div class="card-header">
        <h2>📥 Importer les pointages</h2>
        <button type="button" class="btn btn-sm" onclick="var b=document.getElementById('importPres');b.style.display=b.style.display==='block'?'none':'block'">📂 Ouvrir l'import</button>
    </div>
    <div id="importPres" style="display:none">
        <div class="upload-zone">
            <form method="post" enctype="multipart/form-data" style="display:flex;flex-direction:column;gap:12px;align-items:center">
                <input type="hidden" name="action" value="import">
                <p>📁 Sélectionnez le fichier <b>PRESENCES.xlsx</b> exporté du terminal XI FACE2000</p>
                <input type="file" name="fichier" accept=".xlsx,.csv" required>
                <button type="submit" class="btn">🔄 Importer / synchroniser</button>
                <small class="text-muted">Structure : Date · N° identification · Nom · DANS/DEHORS (×3)</small><br>
                <small class="text-muted">Mode synchronisation : vous pouvez réimporter le même fichier. Les données manquantes sont ajoutées et les heures modifiées sont mises à jour, sans effacer les cellules laissées vides.</small>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<?php
// ---- FILTRES ----
$fDateD = $_GET['date_debut'] ?? '';
$fDateF = $_GET['date_fin']   ?? '';
$fNum   = trim($_GET['numero'] ?? '');
$fNom   = trim($_GET['nom'] ?? '');
$fStatut= $_GET['statut'] ?? '';
$fAnom  = $_GET['anomalie'] ?? '';

// dates par défaut = dernière période importée
if ($fDateD === '' && $fDateF === '') {
    $stmt = $pdo->query("SELECT MIN(date_presence) AS d1, MAX(date_presence) AS d2 FROM presence_journaliere");
    $periode = $stmt->fetch();
    if ($periode['d1']) { $fDateD = $periode['d1']; $fDateF = $periode['d2']; }
}

$where = []; $params = [];
if ($fDateD) { $where[] = "p.date_presence>=?"; $params[] = $fDateD; }
if ($fDateF) { $where[] = "p.date_presence<=?"; $params[] = $fDateF; }
if ($fNum)   { $where[] = "p.numero_identification LIKE ?"; $params[] = "%$fNum%"; }
if ($fNom)   { $where[] = "a.nom_complet LIKE ?"; $params[] = "%$fNom%"; }
if ($fStatut){ $where[] = "p.statut=?"; $params[] = $fStatut; }
if ($fAnom === '1') { $where[] = "p.anomalies<>''"; }
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

// Chargement complet : aucun LIMIT côté serveur.
// DataTables affiche toutes les présences par défaut et conserve la recherche/tri.
$c = $pdo->prepare("SELECT COUNT(*) FROM presence_journaliere p JOIN agents a ON a.numero_identification=p.numero_identification $whereSql");
$c->execute($params);
$total = (int)$c->fetchColumn();

$stmt = $pdo->prepare("SELECT p.*, a.nom_complet, a.service, a.site
    FROM presence_journaliere p
    JOIN agents a ON a.numero_identification = p.numero_identification
    $whereSql
    ORDER BY p.date_presence DESC, a.nom_complet");
$stmt->execute($params);
$presences = $stmt->fetchAll();
?>

<div class="filters">
    <form method="get">
        <div class="form-group"><label>Du</label><input type="date" name="date_debut" value="<?php echo h($fDateD); ?>"></div>
        <div class="form-group"><label>Au</label><input type="date" name="date_fin" value="<?php echo h($fDateF); ?>"></div>
        <div class="form-group"><label>N° identification</label><input type="search" name="numero" value="<?php echo h($fNum); ?>"></div>
        <div class="form-group"><label>Nom agent</label><input type="search" name="nom" value="<?php echo h($fNom); ?>"></div>
        <div class="form-group">
            <label>Statut</label>
            <select name="statut"><option value="">Tous</option>
                <option value="present" <?php echo $fStatut==='present'?'selected':''; ?>>Présent</option>
                <option value="absent" <?php echo $fStatut==='absent'?'selected':''; ?>>Absent</option>
                <option value="conge" <?php echo $fStatut==='conge'?'selected':''; ?>>Congé</option>
                <option value="mission" <?php echo $fStatut==='mission'?'selected':''; ?>>Mission</option>
                <option value="ferie" <?php echo $fStatut==='ferie'?'selected':''; ?>>Férié</option>
            </select>
        </div>
        <div class="form-group">
            <label>Anomalies</label>
            <select name="anomalie"><option value="">Toutes</option>
                <option value="1" <?php echo $fAnom==='1'?'selected':''; ?>>Avec anomalie</option>
            </select>
        </div>
        <div class="form-group" style="flex:0">
            <button type="submit" class="btn">🔎 Filtrer</button>
            <a href="presences.php" class="btn btn-outline btn-sm">Reset</a>
        </div>
    </form>
</div>

<div class="card">
    <div class="card-header">
        <h2>Présences journalières <span class="text-muted">(<?php echo $total; ?>)</span></h2>
        <a href="rapports.php?type=presences&<?php echo http_build_query(array_intersect_key($_GET, array_flip(['date_debut','date_fin','numero','nom','statut']))); ?>" class="btn btn-sm btn-outline">📊 Exporter</a>
    </div>
    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>N°</th>
                    <th>Agent</th>
                    <th>1ère entrée</th>
                    <th>Dernière sortie</th>
                    <th>Durée</th>
                    <th>Retard</th>
                    <th>Horaire appliqué</th>
                    <th>Statut</th>
                    <th>Anomalies</th>
                    <?php if (aPermission('presences.manage')): ?><th class="actions">Actions</th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($presences)): ?>
                <tr class="empty-row"><td colspan="<?php echo aPermission('presences.manage') ? 11 : 10; ?>">Aucune présence. Importez le fichier <b>PRESENCES.xlsx</b> pour commencer.</td></tr>
            <?php else: foreach ($presences as $p):
                $anoms = $p['anomalies'] ? explode('|', $p['anomalies']) : [];
            ?>
                <tr>
                    <td><?php echo formatDateFr($p['date_presence']); ?></td>
                    <td class="num"><?php echo h($p['numero_identification']); ?></td>
                    <td><?php echo h($p['nom_complet'] ?: '—'); ?></td>
                    <td><?php echo formatHeure($p['premiere_entree']); ?></td>
                    <td><?php echo formatHeure($p['derniere_sortie']); ?></td>
                    <td><?php echo $p['duree_minutes'] !== null ? gmdate('H:i', $p['duree_minutes']*60) : '—'; ?></td>
                    <td>
                        <?php if ($p['retard_minutes'] > 0): ?>
                            <span class="text-danger"><b><?php echo (int)$p['retard_minutes']; ?> min</b></span><br>
                            <?php echo badgeTranche($p['tranche_retard']); ?>
                        <?php else: ?> — <?php endif; ?>
                    </td>
                    <td><small><?php echo h($p['horaire_applique']); ?></small></td>
                    <td><?php echo badgeStatut($p['statut']); ?></td>
                    <td>
                        <?php foreach ($anoms as $an): ?>
                            <span class="badge badge-orange"><?php echo h($an); ?></span>
                        <?php endforeach; ?>
                    </td>
                    <?php if (aPermission('presences.manage')): ?>
                    <td class="actions">
                        <a href="presences.php?action=edit&id=<?php echo (int)$p['id']; ?>#presenceFormCard" class="btn btn-sm btn-outline" title="Modifier">✏️ Modifier</a>
                        <form method="post" action="presences.php" style="display:inline" onsubmit="return confirm('Supprimer cette présence et tous ses pointages associés ?');">
                            <input type="hidden" name="action" value="delete_presence">
                            <input type="hidden" name="id" value="<?php echo (int)$p['id']; ?>">
                            <button type="submit" class="btn btn-sm btn-danger" title="Supprimer">🗑️ Supprimer</button>
                        </form>
                    </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/partials/footer.php'; ?>
