MISE À JOUR CODE_FONCTION / FONCTION_AGENT

1. Sauvegardez la base de données et les fichiers actuels.
2. Remplacez les fichiers de l'application par ceux de cette archive.
3. La page Personnels ajoute automatiquement les deux colonnes si elles sont absentes.
4. Vous pouvez aussi exécuter manuellement migration_personnel_fonction.sql.

Fonctionnement :
- CODE_FONCTION contient l'identifiant fonction.id_fonction.
- FONCTION_AGENT contient le libellé fonction.Libelle_Fonction.
- Le formulaire du personnel charge directement la table fonction.
- Toute modification du libellé d'une fonction synchronise les personnels concernés.
- Une fonction utilisée ne peut pas être supprimée.
- Les listes, détails, impressions DataTables et le chatbot affichent et recherchent la fonction.
