MISE À JOUR — RECHERCHE DIRECTEMENT DANS LES LISTES DÉROULANTES

Les champs Fonction utilisent désormais une liste déroulante enrichie.
En ouvrant la liste, le champ de recherche apparaît directement en haut du menu.
La recherche filtre instantanément les fonctions par libellé, sigle ou code.
Navigation clavier : flèches, Entrée et Échap.
Aucune migration SQL n'est nécessaire.
