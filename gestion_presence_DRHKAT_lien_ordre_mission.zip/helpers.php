<?php
/**
 * helpers.php — Fonctions utilitaires transversales de l'application.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/XlsxReader.php';

// ============================================================
//  SÉCURITÉ : échappement HTML
// ============================================================
function h($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function redirect($url) {
    header('Location: ' . $url);
    exit;
}

// ============================================================
//  FLASH MESSAGES (notifications temporaires)
// ============================================================
function flash($type, $message) {
    if (!isset($_SESSION['flash'])) $_SESSION['flash'] = [];
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}
function getFlash() {
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

// ============================================================
//  JOURNAL D'AUDIT (RG-08)
// ============================================================
function logAudit($action, $objet, $objetId = null, $ancienne = null, $nouvelle = null) {
    try {
        $stmt = db()->prepare("INSERT INTO audit_log
            (utilisateur_id, utilisateur_nom, action, objet, objet_id, ancienne_valeur, nouvelle_valeur, adresse_ip)
            VALUES (?,?,?,?,?,?,?,?)");
        $stmt->execute([
            $_SESSION['user']['id'] ?? null,
            $_SESSION['user']['nom_complet'] ?? 'système',
            $action,
            $objet,
            $objetId,
            $ancienne !== null ? (is_array($ancienne) ? json_encode($ancienne, JSON_UNESCAPED_UNICODE) : (string)$ancienne) : null,
            $nouvelle !== null ? (is_array($nouvelle) ? json_encode($nouvelle, JSON_UNESCAPED_UNICODE) : (string)$nouvelle) : null,
            $_SERVER['REMOTE_ADDR'] ?? null,
        ]);
    } catch (Throwable $e) { /* ne pas bloquer l'action */ }
}


// ============================================================
//  COMPATIBILITÉ DU RÉFÉRENTIEL PERSONNEL
// ============================================================
/**
 * Ajoute les colonnes de fonction au référentiel PERSONNEL sur une base existante.
 * La fonction est idempotente et peut être appelée par les modules qui utilisent ces champs.
 */
function ensurePersonnelFunctionColumns($pdo = null) {
    $pdo = $pdo ?: db();
    try {
        $exists = $pdo->query("SHOW TABLES LIKE 'personnel'")->fetchColumn();
        if (!$exists) return false;
        $columns = array();
        foreach ($pdo->query("SHOW COLUMNS FROM personnel")->fetchAll() as $c) $columns[strtoupper($c['Field'])] = true;
        if (!isset($columns['CODE_FONCTION'])) {
            $pdo->exec("ALTER TABLE personnel ADD COLUMN CODE_FONCTION INT(10) UNSIGNED NULL AFTER GRADES");
        }
        if (!isset($columns['FONCTION_AGENT'])) {
            $pdo->exec("ALTER TABLE personnel ADD COLUMN FONCTION_AGENT VARCHAR(200) NULL AFTER CODE_FONCTION");
        }
        try { $pdo->exec("ALTER TABLE personnel ADD INDEX idx_personnel_fonction (CODE_FONCTION)"); } catch (Throwable $e) { }
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

// ============================================================
//  CALCUL DES RETARDS & TRANCHES
// ============================================================

/**
 * Détermine l'horaire applicable à un agent pour une date donnée.
 * Ordre de priorité (RG-04) : individuel temporaire > catégorie (allaitement) >
 * service/site > horaire général.
 *
 * @return array ['heure_entree','heure_sortie','tolerance_min','libelle']
 */
function horaireApplique($numeroId, $date) {
    $pdo = db();
    $dateSql = is_string($date) ? $date : $date->format('Y-m-d');

    // 1) Affectation individuelle / allaitement active sur la période
    $stmt = $pdo->prepare("SELECT a.*, h.libelle, h.heure_entree, h.heure_sortie, h.tolerance_min
        FROM affectation_horaire a
        JOIN horaire h ON h.id = a.horaire_id
        WHERE a.numero_identification = ? AND ? BETWEEN a.date_debut AND a.date_fin
        ORDER BY FIELD(a.type,'individuel','allaitement','mission','autre')
        LIMIT 1");
    $stmt->execute([$numeroId, $dateSql]);
    if ($row = $stmt->fetch()) {
        return [
            'heure_entree'  => $row['heure_entree'],
            'heure_sortie'  => $row['heure_sortie'],
            'tolerance_min' => (int)$row['tolerance_min'],
            'libelle'       => $row['libelle'] . ' (affecté)',
        ];
    }

    // 2) Horaire par service de l'agent
    $agent = $pdo->prepare("SELECT service, site FROM agents WHERE numero_identification=?");
    $agent->execute([$numeroId]);
    $a = $agent->fetch();
    if ($a) {
        if (!empty($a['service'])) {
            $stmt = $pdo->prepare("SELECT * FROM horaire
                WHERE portee='service' AND cible=? AND actif=1
                  AND (date_effet IS NULL OR date_effet<=?)
                ORDER BY date_effet DESC LIMIT 1");
            $stmt->execute([$a['service'], $dateSql]);
            if ($row = $stmt->fetch()) {
                return horaireRowToArray($row);
            }
        }
        if (!empty($a['site'])) {
            $stmt = $pdo->prepare("SELECT * FROM horaire
                WHERE portee='site' AND cible=? AND actif=1
                  AND (date_effet IS NULL OR date_effet<=?)
                ORDER BY date_effet DESC LIMIT 1");
            $stmt->execute([$a['site'], $dateSql]);
            if ($row = $stmt->fetch()) {
                return horaireRowToArray($row);
            }
        }
    }

    // 3) Horaire général
    $stmt = $pdo->prepare("SELECT * FROM horaire
        WHERE portee='general' AND actif=1
          AND (date_effet IS NULL OR date_effet<=?)
        ORDER BY date_effet DESC LIMIT 1");
    $stmt->execute([$dateSql]);
    if ($row = $stmt->fetch()) {
        return horaireRowToArray($row);
    }

    // 4) Fallback : paramètres globaux par défaut
    return [
        'heure_entree'  => parametre('heure_entree_ref', '08:00') . ':00',
        'heure_sortie'  => parametre('heure_sortie_ref', '16:00') . ':00',
        'tolerance_min' => (int)parametre('tolerance_min', 5),
        'libelle'       => 'Horaire par défaut',
    ];
}

function horaireRowToArray($row) {
    return [
        'heure_entree'  => substr($row['heure_entree'], 0, 8),
        'heure_sortie'  => substr($row['heure_sortie'], 0, 8),
        'tolerance_min' => (int)$row['tolerance_min'],
        'libelle'       => $row['libelle'],
    ];
}

/**
 * Calcule le retard en minutes (RG-03).
 * retard = max(0, arrivée − (heure_limite + tolérance))
 */
function calculerRetard($premiereEntree, $heureEntreeRef, $toleranceMin) {
    if (!$premiereEntree || !$heureEntreeRef) return 0;
    $arrivee = strtotime($premiereEntree);
    $limite  = strtotime($heureEntreeRef) + ($toleranceMin * 60);
    $retard  = (int)(($arrivee - $limite) / 60);
    return max(0, $retard);
}

/**
 * Classe le retard dans une tranche configurable (RG-04, F-RT-04).
 */
function trancheRetard($minutes) {
    if ($minutes <= 0) return 'aucun';
    $legere  = (int)parametre('tranche_legere', 15);
    $moyenne = (int)parametre('tranche_moyenne', 30);
    if ($minutes <= $legere) return 'léger';
    if ($minutes <= $moyenne) return 'moyen';
    return 'grave';
}

/**
 * Différence en minutes entre deux heures HH:MM:SS.
 */
function dureeMinutes($debut, $fin) {
    if (!$debut || !$fin) return null;
    $d = strtotime($debut);
    $f = strtotime($fin);
    if ($f < $d) $f += 86400; // franchit minuit
    return (int)(($f - $d) / 60);
}

/**
 * Recalcule toutes les présences journalières à partir des passages bruts.
 * À appeler après chaque import de présences.
 */
function recalculerPresences($dateDebut = null, $dateFin = null) {
    $pdo = db();
    $where = '';
    $params = [];
    if ($dateDebut) { $where .= " AND date_passage>=?"; $params[] = $dateDebut; }
    if ($dateFin)   { $where .= " AND date_passage<=?"; $params[] = $dateFin; }

    // liste des couples (agent, date) présents
    $sql = "SELECT DISTINCT numero_identification, date_passage
            FROM passage_brut WHERE 1=1 $where";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    $count = 0;
    while ($r = $stmt->fetch()) {
        $numId = $r['numero_identification'];
        $date  = $r['date_passage'];

        // première entrée = MIN des IN
        $e = $pdo->prepare("SELECT MIN(heure_passage) AS entree FROM passage_brut
                            WHERE numero_identification=? AND date_passage=? AND sens='IN'");
        $e->execute([$numId, $date]);
        $entree = $e->fetch()['entree'];

        // dernière sortie = MAX des OUT
        $s = $pdo->prepare("SELECT MAX(heure_passage) AS sortie FROM passage_brut
                            WHERE numero_identification=? AND date_passage=? AND sens='OUT'");
        $s->execute([$numId, $date]);
        $sortie = $s->fetch()['sortie'];

        $horaire = horaireApplique($numId, $date);
        $retard  = calculerRetard($entree, $horaire['heure_entree'], $horaire['tolerance_min']);
        $tranche = trancheRetard($retard);
        $duree   = ($entree && $sortie) ? dureeMinutes($entree, $sortie) : null;

        // anomalies
        $anomalies = [];
        if ($entree && !$sortie) $anomalies[] = 'sortie_manquante';
        if (!$entree && $sortie) $anomalies[] = 'entree_manquante';

        // vérifier si l'agent est en congé/mission ce jour
        $statut = 'present';
        $stmtC = $pdo->prepare("SELECT 'conge' AS s FROM conge
            WHERE numero_identification=? AND statut='validee'
              AND ? BETWEEN date_debut AND date_fin
            UNION ALL
            SELECT 'mission' FROM absence
            WHERE numero_identification=? AND type='mission'
              AND statut IN ('validee','en_attente')
              AND ? BETWEEN date_debut AND date_fin
            LIMIT 1");
        $stmtC->execute([$numId, $date, $numId, $date]);
        if ($row = $stmtC->fetch()) {
            $statut = $row['s'];
        }

        // jour férié
        $stmtF = $pdo->prepare("SELECT 1 FROM jour_ferie WHERE date_jour=?");
        $stmtF->execute([$date]);
        if ($stmtF->fetch()) {
            $statut = 'ferie';
        }

        // upsert
        $stmtU = $pdo->prepare("INSERT INTO presence_journaliere
            (numero_identification, date_presence, premiere_entree, derniere_sortie,
             duree_minutes, retard_minutes, tranche_retard, horaire_applique, statut, anomalies)
            VALUES (?,?,?,?,?,?,?,?,?,?)
            ON DUPLICATE KEY UPDATE
              premiere_entree=VALUES(premiere_entree),
              derniere_sortie=VALUES(derniere_sortie),
              duree_minutes=VALUES(duree_minutes),
              retard_minutes=VALUES(retard_minutes),
              tranche_retard=VALUES(tranche_retard),
              horaire_applique=VALUES(horaire_applique),
              statut=VALUES(statut),
              anomalies=VALUES(anomalies)");
        $stmtU->execute([
            $numId, $date, $entree, $sortie,
            $duree, $retard, $tranche, $horaire['libelle'], $statut,
            implode('|', $anomalies)
        ]);
        $count++;
    }
    return $count;
}

// ============================================================
//  FORMATS D'AFFICHAGE
// ============================================================
function formatDateFr($date) {
    if (!$date) return '';
    $ts = strtotime($date);
    if ($ts === false) return $date;
    return date('d/m/Y', $ts);
}
function formatDateFrLong($date) {
    if (!$date) return '';
    setlocale(LC_TIME, 'fr_FR.UTF-8', 'fra');
    $ts = strtotime($date);
    $jours = ['Dimanche','Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'];
    $mois = ['janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre'];
    return $jours[(int)date('w', $ts)] . ' ' . date('j', $ts) . ' ' . $mois[(int)date('n', $ts) - 1] . ' ' . date('Y', $ts);
}
function formatHeure($time) {
    if (!$time) return '—';
    return substr($time, 0, 5);
}
function badgeStatut($statut) {
    $classes = [
        'present'    => 'badge-green',
        'absent'     => 'badge-red',
        'conge'      => 'badge-blue',
        'mission'    => 'badge-purple',
        'ferie'      => 'badge-gray',
        'present_partiel' => 'badge-orange',
    ];
    $cls = $classes[$statut] ?? 'badge-gray';
    $labels = [
        'present' => 'Présent', 'absent' => 'Absent', 'conge' => 'Congé',
        'mission' => 'Mission', 'ferie' => 'Férié', 'present_partiel' => 'Partiel',
    ];
    return '<span class="badge ' . $cls . '">' . ($labels[$statut] ?? $statut) . '</span>';
}
function badgeTranche($tranche) {
    $classes = ['aucun'=>'badge-green','léger'=>'badge-yellow','moyen'=>'badge-orange','grave'=>'badge-red'];
    $cls = $classes[$tranche] ?? 'badge-gray';
    $labels = ['aucun'=>'Aucun','léger'=>'Léger','moyen'=>'Moyen','grave'=>'Grave'];
    return '<span class="badge ' . $cls . '">' . ($labels[$tranche] ?? $tranche) . '</span>';
}


// ============================================================
//  AUTORISATIONS PERSONNALISÉES PAR UTILISATEUR
// ============================================================
function cataloguePermissions() {
    return [
        'dashboard.view'      => 'Tableau de bord — consulter',
        'agents.view'         => 'Agents — consulter',
        'agents.manage'       => 'Agents — ajouter, modifier, supprimer et activer/désactiver',
        'personnels.view'     => 'Personnels — consulter',
        'personnels.manage'   => 'Personnels et référentiels — gérer',
        'presences.view'      => 'Présences — consulter',
        'presences.import'    => 'Présences — importer les pointages',
        'presences.manage'    => 'Présences — ajouter, modifier et supprimer',
        'retards.view'        => 'Retards — consulter',
        'retards.manage'      => 'Retards — justifier',
        'absences.view'       => 'Absences — consulter',
        'absences.manage'     => 'Absences — ajouter, modifier, valider et supprimer',
        'conges.view'         => 'Congés et missions — consulter',
        'conges.manage'       => 'Congés et missions — gérer',
        'horaires.view'       => 'Horaires — consulter',
        'horaires.manage'     => 'Horaires et affectations — gérer',
        'rapports.view'       => 'Rapports — consulter',
        'reports.print'       => 'Impressions — imprimer les listes et rapports',
        'reports.export'      => 'Exports — exporter les données',
        'signataires.manage'  => 'Signataires — ajouter, modifier et supprimer',
        'chatbot.use'         => 'Assistant DRHKAT — utiliser le chatbot',
    ];
}

function ensurePermissionTable() {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        db()->exec("CREATE TABLE IF NOT EXISTS utilisateur_permission (
            utilisateur_id INT NOT NULL,
            permission_cle VARCHAR(100) NOT NULL,
            autorise TINYINT(1) NOT NULL DEFAULT 1,
            date_modification DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (utilisateur_id, permission_cle),
            KEY idx_permission_cle (permission_cle)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) { /* migration manuelle possible */ }
}

function permissionsRoleDefaut($role) {
    $all = array_keys(cataloguePermissions());
    if ($role === 'Administrateur') return array_fill_keys($all, true);
    $map = [
        'Gestionnaire RH' => ['dashboard.view','agents.view','agents.manage','personnels.view','personnels.manage','presences.view','presences.import','presences.manage','retards.view','retards.manage','absences.view','absences.manage','conges.view','conges.manage','horaires.view','horaires.manage','rapports.view','reports.print','reports.export','signataires.manage','chatbot.use'],
        'Gestionnaire présences' => ['dashboard.view','agents.view','presences.view','presences.import','presences.manage','retards.view','retards.manage','absences.view','conges.view','horaires.view','rapports.view','reports.print','reports.export','chatbot.use'],
        'Validateur' => ['dashboard.view','agents.view','personnels.view','presences.view','retards.view','retards.manage','absences.view','absences.manage','conges.view','rapports.view','reports.print','reports.export','chatbot.use'],
        'Consultation' => ['dashboard.view','agents.view','personnels.view','presences.view','retards.view','absences.view','conges.view','horaires.view','rapports.view','reports.print','reports.export','chatbot.use'],
        'Agent' => ['dashboard.view','rapports.view','reports.print','chatbot.use'],
    ];
    return array_fill_keys($map[$role] ?? [], true);
}

function aPermission($permission, $userId = null) {
    if (!isset($_SESSION['user']) && $userId === null) return false;
    $uid = $userId !== null ? (int)$userId : (int)($_SESSION['user']['id'] ?? 0);
    $role = $userId === null ? ($_SESSION['user']['role'] ?? '') : '';
    if ($userId !== null) {
        try {
            $st=db()->prepare('SELECT role FROM utilisateurs WHERE id=?'); $st->execute([$uid]); $role=(string)$st->fetchColumn();
        } catch (Throwable $e) { return false; }
    }
    if ($role === 'Administrateur') return true;
    ensurePermissionTable();
    try {
        $st=db()->prepare('SELECT autorise FROM utilisateur_permission WHERE utilisateur_id=? AND permission_cle=?');
        $st->execute([$uid,$permission]);
        $v=$st->fetchColumn();
        if ($v !== false) return (bool)$v;
    } catch (Throwable $e) { }
    $defaults=permissionsRoleDefaut($role);
    return !empty($defaults[$permission]);
}

function exigerPermission($permission, $redirectUrl='index.php') {
    if (!aPermission($permission)) {
        flash('error','Vous ne disposez pas de l’autorisation nécessaire pour cette opération.');
        redirect($redirectUrl);
    }
}

function permissionPageCourante($script) {
    $map = [
        'index.php'=>'dashboard.view','agents.php'=>'agents.view','personnels.php'=>'personnels.view',
        'presences.php'=>'presences.view','retards.php'=>'retards.view','absences.php'=>'absences.view',
        'conges.php'=>'conges.view','horaires.php'=>'horaires.view','rapports.php'=>'rapports.view',
        'dashboard_export.php'=>'reports.export','export.php'=>'reports.export','chatbot_api.php'=>'chatbot.use'
    ];
    return $map[$script] ?? null;
}

/**
 * Vérifie si un utilisateur a un rôle suffisant.
 * @param array|string $roles
 */
function aRole($roles) {
    if (!isset($_SESSION['user'])) return false;
    $userRole = $_SESSION['user']['role'];
    $roles = (array)$roles;
    return in_array($userRole, $roles, true);
}
