-- ---- AUTORISATIONS PERSONNALISÉES PAR UTILISATEUR ----
CREATE TABLE IF NOT EXISTS utilisateur_permission (
    utilisateur_id   INT NOT NULL,
    permission_cle   VARCHAR(100) NOT NULL,
    autorise         TINYINT(1) NOT NULL DEFAULT 1,
    date_modification DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (utilisateur_id, permission_cle),
    KEY idx_permission_cle (permission_cle)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
