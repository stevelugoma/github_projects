<?php
/**
 * Configuration de l'application de gestion du personnel et suivi des présences
 * Application pour terminal biométrique XI FACE2000
 *
 * Configuration MySQL de production — presence.edrhkat.com
 */

// ============================================================
//  PARAMÈTRES DE CONNEXION À LA BASE DE DONNÉES MYSQL
// ============================================================
define('DB_HOST', '127.0.0.1');
define('DB_HOST_FALLBACK', 'localhost');
define('DB_PORT', 3306);
define('DB_NAME', 'edrhk2581223_21zrkh');
define('DB_USER', 'edrhk2581223');
define('DB_PASS', 'Lumiere@2004');
define('DB_CHARSET', 'utf8mb4');

// ============================================================
//  INFORMATIONS DE L'APPLICATION
// ============================================================
define('APP_NAME', 'DRHKAT — Gestion des présences');
define('APP_SHORT', 'DRHKAT');
define('APP_VERSION', '3.5');
define('APP_DEVICE', 'XI FACE2000 — JYM6254300619');
define('ORG_NAME', 'Direction des Recettes du Haut-Katanga');
define('ORG_DIVISION', 'Division des Ressources Humaines et de l’Administration');
define('ORG_EMAIL', 'drhkat.d@edrhkat.com');
define('ORG_WEBSITE', 'https://www.edrhkat.com');
define('ORG_WEBMAIL', 'https://mail.edrhkat.com');
define('ORG_LOGO', 'assets/img/logo-drhkat.png');

// Fuseau horaire (RDC, Katanga = Africa/Lubumbashi)
date_default_timezone_set('Africa/Lubumbashi');

// Démarrage de session global
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ============================================================
//  PARAMÈTRES PAR DÉFAUT DE PONCTUALITÉ
//  (modifiables ensuite dans Administration > Paramètres)
// ============================================================
$GLOBALS['DEFAULTS'] = [
    'heure_entree_ref'   => '08:00',   // heure normale d'entrée
    'heure_sortie_ref'   => '16:00',   // heure normale de sortie
    'tolerance_min'      => 5,         // tolérance en minutes
    'tranche_legere'     => 15,        // retard léger  : 1..15 min
    'tranche_moyenne'    => 30,        // retard moyen  : 16..30 min
    // retard grave : > 30 min
];

// ============================================================
//  FONCTION DE CONNEXION À LA BASE DE DONNÉES (PDO)
// ============================================================
function db() {
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    // Sur certains hébergements mutualisés, "localhost" tente un socket Unix
    // absent. On essaie d'abord TCP via 127.0.0.1, puis localhost en secours.
    $hosts = array(DB_HOST);
    if (defined('DB_HOST_FALLBACK') && DB_HOST_FALLBACK !== DB_HOST) {
        $hosts[] = DB_HOST_FALLBACK;
    }

    $options = array(
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::ATTR_TIMEOUT            => 8
    );

    $lastMessage = '';
    foreach ($hosts as $host) {
        $dsn = 'mysql:host=' . $host . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
            return $pdo;
        } catch (PDOException $e) {
            $lastMessage = $e->getMessage();
        }
    }

    die('<div style="font-family:Segoe UI,Arial;padding:30px;color:#b00">'
      . '<h2>Impossible de se connecter à MySQL</h2>'
      . '<p>La connexion a été testée en TCP sur <code>127.0.0.1</code> puis avec <code>localhost</code>.</p>'
      . '<p>Si l\'erreur persiste, utilisez dans <code>config.php</code> le nom exact du serveur MySQL indiqué par votre hébergeur (ex. <code>mysql123.hebergeur.com</code>).</p>'
      . '<p style="color:#555">Détail : ' . htmlspecialchars($lastMessage, ENT_QUOTES, 'UTF-8') . '</p>'
      . '</div>');
}

/**
 * Lit un paramètre stocké en base (avec fallback sur les valeurs par défaut).
 */
function parametre($cle, $defaut = null) {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            $stmt = db()->query('SELECT cle, valeur FROM parametres');
            foreach ($stmt->fetchAll() as $r) {
                $cache[$r['cle']] = $r['valeur'];
            }
        } catch (Throwable $e) { /* table absente pendant install */ }
    }
    if (array_key_exists($cle, $cache)) return $cache[$cle];
    if (isset($GLOBALS['DEFAULTS'][$cle])) return $GLOBALS['DEFAULTS'][$cle];
    return $defaut;
}
