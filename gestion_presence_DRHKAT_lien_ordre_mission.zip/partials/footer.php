</section>
<footer class="footer institution-footer">
    <div class="footer-brand">
        <img src="<?php echo h(ORG_LOGO); ?>" alt="Logo DRHKAT">
        <div><strong><?php echo h(ORG_NAME); ?></strong><span><?php echo h(ORG_DIVISION); ?></span></div>
    </div>
    <div class="footer-links">
        <a href="<?php echo h(ORG_WEBSITE); ?>" target="_blank" rel="noopener noreferrer"><i class="bi bi-globe2"></i> www.edrhkat.com</a>
        <a href="<?php echo h(ORG_WEBMAIL); ?>" target="_blank" rel="noopener noreferrer"><i class="bi bi-envelope-at"></i> Messagerie interne</a>
        <a href="mailto:<?php echo h(ORG_EMAIL); ?>"><i class="bi bi-send"></i> <?php echo h(ORG_EMAIL); ?></a>
    </div>
    <div class="footer-meta"><span>© <?php echo date('Y'); ?> DRHKAT</span><span>Version <?php echo h(APP_VERSION); ?></span></div>
</footer>
</main>
</div>

<?php if (aPermission('chatbot.use')): ?>
<div class="drhkat-chatbot no-print" id="drhkatChatbot" data-logo="<?php echo h(ORG_LOGO); ?>" aria-live="polite">
  <button type="button" class="drhkat-chatbot-toggle" id="drhkatChatbotToggle" aria-expanded="false" aria-controls="drhkatChatbotPanel" title="Assistant DRHKAT">
    <img class="drhkat-chatbot-toggle-logo" src="<?php echo h(ORG_LOGO); ?>" alt="Logo DRHKAT"><span>Assistant</span>
  </button>
  <section class="drhkat-chatbot-panel" id="drhkatChatbotPanel" hidden>
    <header class="drhkat-chatbot-header">
      <div class="drhkat-chatbot-brand"><img src="<?php echo h(ORG_LOGO); ?>" alt="Logo DRHKAT"><div><strong>Assistant DRHKAT</strong><small>Assistant RH approfondi et contextuel</small></div></div>
      <div class="drhkat-chatbot-header-actions"><button type="button" id="drhkatChatbotReset" aria-label="Nouvelle conversation" title="Nouvelle conversation"><i class="bi bi-arrow-counterclockwise"></i></button><button type="button" id="drhkatChatbotClose" aria-label="Fermer"><i class="bi bi-x-lg"></i></button></div>
    </header>
    <div class="drhkat-chatbot-messages" id="drhkatChatbotMessages">
      <div class="chat-message bot"><img class="chatbot-message-logo" src="<?php echo h(ORG_LOGO); ?>" alt=""><div>Bonjour. Je peux analyser les données RH, comprendre vos questions de suivi et vous guider dans tous les modules du site.</div></div>
    </div>
    <div class="drhkat-chatbot-suggestions" id="drhkatChatbotSuggestions">
      <button type="button">Résumé RH</button><button type="button">Top 10 des sites</button><button type="button">Retards ce mois</button>
    </div>
    <form class="drhkat-chatbot-form" id="drhkatChatbotForm">
      <label class="visually-hidden" for="drhkatChatbotInput">Votre demande</label>
      <textarea id="drhkatChatbotInput" rows="1" maxlength="800" placeholder="Écrivez votre demande…" required></textarea>
      <button type="submit" aria-label="Envoyer"><i class="bi bi-send-fill"></i></button>
    </form>
    <small class="drhkat-chatbot-note">Consultation en lecture seule selon vos droits d’accès.</small>
  </section>
</div>
<?php endif; ?>

<?php if (!empty($globalPrintCanPrint)): ?>
<div class="global-print-signature" aria-hidden="true" style="display:none;text-align:center;width:320px;margin:55px 0 0 auto;page-break-inside:avoid">
  <div style="height:65px"></div><strong id="globalPrintSignatureName"></strong><div id="globalPrintSignatureTitle" style="font-weight:700;margin-top:12px"></div>
</div>
<div class="modal fade no-print" id="globalPrintSignerModal" tabindex="-1" aria-hidden="true">
 <div class="modal-dialog modal-lg modal-dialog-scrollable"><div class="modal-content">
  <div class="modal-header"><div><h5 class="modal-title"><i class="bi bi-pen"></i> Choisir le signataire</h5><div class="text-muted small">Le nom et la qualité seront placés au bas du document imprimé.</div></div><button class="btn-close" data-bs-dismiss="modal"></button></div>
  <div class="modal-body">
   <?php if (!empty($globalPrintCanWrite)): ?>
   <div class="mb-3"><button type="button" class="btn btn-success btn-sm" data-bs-toggle="collapse" data-bs-target="#globalQuickSigner"><i class="bi bi-plus-lg"></i> Ajouter un signataire</button></div>
   <div class="collapse mb-3" id="globalQuickSigner"><form id="globalSignerCreateForm" class="border rounded-3 p-3">
    <div class="row g-3"><div class="col-md-6"><label class="form-label">Nom complet *</label><input class="form-control" name="nom_complet" required></div>
    <div class="col-md-6"><label class="form-label">Qualité / fonction *</label><select class="form-select js-searchable-function" name="qualite" required data-search-placeholder="Rechercher une fonction…"><option value="">— Sélectionner —</option><?php foreach($globalPrintFonctions as $gf): $gl=trim((string)$gf['Libelle_Fonction']); ?><option value="<?php echo h($gl); ?>"><?php echo h($gl); ?><?php echo !empty($gf['Sigle_Fonction'])?' — '.h($gf['Sigle_Fonction']):''; ?></option><?php endforeach; ?></select></div>
    <div class="col-md-4"><label class="form-label">Ordre</label><input type="number" class="form-control" name="ordre_affichage" value="0"></div><div class="col-md-4 d-flex align-items-end"><label class="form-check mb-2"><input class="form-check-input" type="checkbox" name="actif" id="globalSignerActive" value="1" checked> Actif</label></div><div class="col-md-4 d-flex align-items-end"><button class="btn btn-success w-100">Enregistrer</button></div></div><div id="globalSignerFormMessage" class="small mt-2 text-muted"></div>
   </form></div>
   <?php endif; ?>
   <div class="table-responsive"><table class="table table-hover align-middle"><thead><tr><th style="width:48px"></th><th>Nom complet</th><th>Qualité / fonction</th></tr></thead><tbody id="globalPrintSignerRows">
   <?php foreach($globalPrintSignataires as $gs): ?><tr class="global-signer-choice" tabindex="0" role="button" data-id="<?php echo (int)$gs['id']; ?>" data-nom="<?php echo h($gs['nom_complet']); ?>" data-qualite="<?php echo h($gs['qualite']); ?>"><td><input class="form-check-input" type="radio" name="global_print_signer" value="<?php echo (int)$gs['id']; ?>"></td><td><strong><?php echo h($gs['nom_complet']); ?></strong></td><td><?php echo h($gs['qualite']); ?></td></tr><?php endforeach; ?>
   <?php if(empty($globalPrintSignataires)): ?><tr class="global-empty-signers"><td colspan="3" class="text-center text-muted">Aucun signataire actif.<?php echo !empty($globalPrintCanWrite)?' Utilisez « Ajouter un signataire ».':''; ?></td></tr><?php endif; ?>
   </tbody></table></div>
  </div><div class="modal-footer"><button class="btn btn-light" data-bs-dismiss="modal">Annuler</button><button type="button" class="btn btn-primary" id="globalConfirmPrint"><i class="bi bi-printer"></i> Imprimer</button></div>
 </div></div>
</div>
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/2.1.8/js/dataTables.min.js"></script>
<script src="https://cdn.datatables.net/2.1.8/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/3.1.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/3.1.2/js/buttons.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/3.1.2/js/buttons.colVis.min.js"></script>
<script src="https://cdn.datatables.net/colreorder/2.0.4/js/dataTables.colReorder.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"></script>
<script src="assets/app.js?v=<?php echo rawurlencode(APP_VERSION); ?>"></script>
<?php if (!empty($extraScripts)) echo $extraScripts; ?>
</body>
</html>
