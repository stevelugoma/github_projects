<?php
require_once __DIR__ . '/../auth.php';
$flashes = getFlash();
$user = isset($_SESSION['user']) ? $_SESSION['user'] : null;

// Référentiels partagés par la fenêtre universelle de signature d'impression.
$globalPrintSignataires = array();
$globalPrintFonctions = array();
try {
    $globalPrintSignataires = db()->query("SELECT id, nom_complet, qualite FROM signataire_impression WHERE actif=1 ORDER BY ordre_affichage, nom_complet")->fetchAll();
} catch (Throwable $e) { $globalPrintSignataires = array(); }
try {
    $globalPrintFonctions = db()->query("SELECT id_fonction, Libelle_Fonction, Sigle_Fonction, Etat_Fonction FROM fonction WHERE Libelle_Fonction IS NOT NULL AND TRIM(Libelle_Fonction)<>'' ORDER BY Libelle_Fonction")->fetchAll();
} catch (Throwable $e) { $globalPrintFonctions = array(); }
$globalPrintCanWrite = aPermission('signataires.manage');
$globalPrintCanPrint = aPermission('reports.print');
$menu = array(
    'index.php' => array('bi-speedometer2','Tableau de bord'),
    'agents.php' => array('bi-people','Agents pointeurs'),
    'personnels.php' => array('bi-person-vcard','Personnels'),
    'presences.php' => array('bi-fingerprint','Présences'),
    'retards.php' => array('bi-alarm','Retards'),
    'absences.php' => array('bi-calendar-x','Absences'),
    'conges.php' => array('bi-airplane','Congés & missions'),
    'horaires.php' => array('bi-clock-history','Horaires'),
    'rapports.php' => array('bi-bar-chart-line','Rapports')
);
$menuPermissions = array(
    'index.php'=>'dashboard.view','agents.php'=>'agents.view','personnels.php'=>'personnels.view',
    'presences.php'=>'presences.view','retards.php'=>'retards.view','absences.php'=>'absences.view',
    'conges.php'=>'conges.view','horaires.php'=>'horaires.view','rapports.php'=>'rapports.view'
);
foreach (array_keys($menu) as $menuUrl) {
    if (isset($menuPermissions[$menuUrl]) && !aPermission($menuPermissions[$menuUrl])) unset($menu[$menuUrl]);
}
if (aRole('Administrateur')) $menu['administration.php'] = array('bi-shield-lock','Administration');
?>
<!DOCTYPE html>
<html lang="fr" data-bs-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light dark">
<title><?php echo h(isset($pageTitle) ? $pageTitle : APP_NAME); ?> — <?php echo h(APP_SHORT); ?></title>
<link rel="icon" type="image/png" href="assets/img/favicon-drhkat.png">
<link rel="apple-touch-icon" href="assets/img/favicon-drhkat.png">
<link rel="preconnect" href="https://cdn.jsdelivr.net">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/2.1.8/css/dataTables.bootstrap5.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/buttons/3.1.2/css/buttons.bootstrap5.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/colreorder/2.0.4/css/colReorder.bootstrap5.min.css" rel="stylesheet">
<?php if (!empty($extraHead)) echo $extraHead; ?>
<link rel="stylesheet" href="assets/style.css?v=<?php echo rawurlencode(APP_VERSION); ?>">
<style>
/* Règles critiques anti-cache : empêchent le logo et l'en-tête d'impression de déformer l'interface. */
.print-letterhead{display:none!important}
.brand-logo-wrap{width:48px!important;height:48px!important;min-width:48px!important;max-width:48px!important;overflow:hidden!important;border-radius:14px!important;background:#fff!important;padding:4px!important;display:grid!important;place-items:center!important}
.brand-logo{display:block!important;width:100%!important;height:100%!important;max-width:40px!important;max-height:40px!important;object-fit:contain!important}
.footer-brand img{width:58px!important;height:44px!important;max-width:58px!important;max-height:44px!important;object-fit:contain!important}
.main-content{min-width:0!important}.content{min-width:0!important}.card,.chart-card{max-width:100%!important}
@media(max-width:860px){.main-content{margin-left:0!important}.sidebar{width:274px!important}}
@media print{.print-letterhead{display:flex!important}.global-print-signature{display:block!important}.no-print,.modal,.modal-backdrop{display:none!important}}
</style>
<script>
(function(){
  var saved = localStorage.getItem('presence-theme') || 'light';
  document.documentElement.setAttribute('data-bs-theme', saved);
})();
</script>
</head>
<body>
<div class="app-shell">
<aside class="sidebar" id="sidebar">
    <a class="brand" href="index.php" aria-label="Accueil DRHKAT">
        <span class="brand-logo-wrap"><img src="<?php echo h(ORG_LOGO); ?>" alt="Logo DRHKAT" class="brand-logo"></span>
        <div><strong>DRHKAT</strong><small>Ressources humaines</small></div>
    </a>
    <nav class="sidebar-nav">
    <?php foreach ($menu as $url => $item): $icon=$item[0]; $label=$item[1]; ?>
        <a href="<?php echo $url; ?>" class="<?php echo (isset($activePage) && $activePage === $url) ? 'active' : ''; ?>">
            <i class="bi <?php echo h($icon); ?>"></i><span><?php echo h($label); ?></span>
        </a>
    <?php endforeach; ?>
    </nav>
    <div class="institution-links sidebar-institution-links">
        <a href="<?php echo h(ORG_WEBSITE); ?>" target="_blank" rel="noopener noreferrer" title="Site officiel DRHKAT"><i class="bi bi-globe2"></i><span>Site officiel</span></a>
        <a href="<?php echo h(ORG_WEBMAIL); ?>" target="_blank" rel="noopener noreferrer" title="Messagerie interne"><i class="bi bi-envelope-at"></i><span>Messagerie</span></a>
        <a href="mailto:<?php echo h(ORG_EMAIL); ?>" title="Écrire à la DRHKAT"><i class="bi bi-send"></i><span>Contact</span></a>
    </div>
    <div class="sidebar-user">
        <div class="user-avatar"><i class="bi bi-person"></i></div>
        <div class="user-meta"><strong><?php echo h(isset($user['nom_complet']) ? $user['nom_complet'] : 'Utilisateur'); ?></strong><small><?php echo h(isset($user['role']) ? $user['role'] : ''); ?></small></div>
        <a class="logout-link" href="logout.php" title="Se déconnecter"><i class="bi bi-box-arrow-right"></i></a>
    </div>
</aside>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<main class="main-content">
<header class="topbar">
    <div class="d-flex align-items-center gap-3">
        <button class="icon-btn menu-toggle" id="menuToggle" type="button" aria-label="Ouvrir le menu"><i class="bi bi-list"></i></button>
        <div><h1><?php echo h(isset($pageTitle) ? $pageTitle : APP_NAME); ?></h1><p><?php echo formatDateFrLong(date('Y-m-d')); ?></p></div>
    </div>
    <div class="topbar-actions">
        <div class="topbar-links" aria-label="Liens institutionnels">
            <a href="<?php echo h(ORG_WEBSITE); ?>" target="_blank" rel="noopener noreferrer" title="Site officiel"><i class="bi bi-globe2"></i><span>Site</span></a>
            <a href="<?php echo h(ORG_WEBMAIL); ?>" target="_blank" rel="noopener noreferrer" title="Messagerie interne"><i class="bi bi-envelope-at"></i><span>Mail</span></a>
        </div>
        <button class="icon-btn" id="themeToggle" type="button" title="Changer de thème"><i class="bi bi-moon-stars"></i></button>
        <span class="status-pill"><span></span> Système opérationnel</span>
    </div>
</header>
<div class="print-letterhead">
    <img src="<?php echo h(ORG_LOGO); ?>" alt="Logo DRHKAT">
    <div><strong><?php echo h(ORG_NAME); ?></strong><span><?php echo h(ORG_DIVISION); ?></span><small><?php echo h(ORG_WEBSITE); ?> · <?php echo h(ORG_EMAIL); ?></small></div>
</div>
<section class="content">
<?php foreach ($flashes as $f): ?>
<div class="alert alert-<?php echo h($f['type'] === 'error' ? 'danger' : $f['type']); ?> alert-dismissible fade show shadow-sm" role="alert">
    <?php echo $f['message']; ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endforeach; ?>
