MISE À JOUR — GESTION COMPLÈTE DES AGENTS

- Ajout, modification, suppression définitive et activation/désactivation des agents.
- Fonction chargée depuis la table fonction, avec recherche intégrée.
- Service chargé depuis la table appartenance, avec recherche intégrée.
- Site chargé depuis la table entite, avec recherche intégrée.
- Les anciennes valeurs restent visibles si elles ne sont plus présentes dans le référentiel.
- La suppression définitive retire aussi les présences, passages, absences, congés et affectations horaires liés à l’agent.
- Toutes les opérations sont contrôlées par la permission agents.manage et journalisées.
