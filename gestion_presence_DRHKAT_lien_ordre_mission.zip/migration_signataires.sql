CREATE TABLE IF NOT EXISTS `signataire_impression` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nom_complet` varchar(200) NOT NULL,
  `qualite` varchar(150) NOT NULL,
  `actif` tinyint(1) NOT NULL DEFAULT 1,
  `ordre_affichage` int(11) NOT NULL DEFAULT 0,
  `date_creation` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Exemple facultatif : adaptez le nom avant import si nécessaire.
-- INSERT INTO `signataire_impression` (`nom_complet`,`qualite`,`actif`,`ordre_affichage`)
-- VALUES ('Bruno KWESELE CHOMA CHOMA','Directeur',1,1);
