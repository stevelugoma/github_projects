MISE À JOUR — RÉFÉRENTIEL DES DIVISIONS

1. Importer migration_division.sql dans la base edrhk2581223_21zrkh si la table division n’existe pas encore.
2. Remplacer les fichiers de l’application par ceux de cette archive.
3. Dans Personnels > Nouveau/Modifier, le champ Division est maintenant une liste alimentée par la table division.
4. L’application enregistre automatiquement CODE_DIV et DIVISION dans la table personnel à partir de la sélection.
5. Les anciennes fiches sont rapprochées de la table division via CODE_DIV pour l’affichage et la modification.
