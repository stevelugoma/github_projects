<?php
/**
 * Export CSV complet du tableau de bord pour la période sélectionnée.
 * Le fichier est compatible avec Excel et conserve les principales sections.
 */
require_once __DIR__ . '/helpers.php';

$pdo = db();
$dateDebut = trim($_GET['date_debut'] ?? '');
$dateFin = trim($_GET['date_fin'] ?? '');
if ($dateDebut === '' && $dateFin === '') {
    $dateDebut = date('Y-m-01', strtotime('first day of previous month'));
    $dateFin = date('Y-m-t', strtotime('last day of previous month'));
} elseif ($dateDebut === '') {
    $dateDebut = date('Y-m-01', strtotime($dateFin));
} elseif ($dateFin === '') {
    $dateFin = date('Y-m-t', strtotime($dateDebut));
}
if ($dateDebut > $dateFin) {
    [$dateDebut, $dateFin] = [$dateFin, $dateDebut];
}

$filename = 'tableau_de_bord_' . str_replace('-', '', $dateDebut) . '_' . str_replace('-', '', $dateFin) . '.csv';
header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: no-cache, no-store, must-revalidate');

$out = fopen('php://output', 'w');
fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));

function csvSection($out, string $title): void {
    fputcsv($out, []);
    fputcsv($out, [$title], ';');
}
function csvRow($out, array $row): void {
    fputcsv($out, $row, ';');
}

$effectifTotal = (int)$pdo->query("SELECT COUNT(*) FROM agents")->fetchColumn();
$effectifActif = (int)$pdo->query("SELECT COUNT(*) FROM agents WHERE statut=1")->fetchColumn();

$stmt = $pdo->prepare("SELECT
    SUM(statut='present') AS presents,
    SUM(statut='absent') AS absents,
    SUM(statut='conge') AS conges,
    SUM(statut='mission') AS missions,
    SUM(statut='ferie') AS feries,
    SUM(retard_minutes>0) AS en_retard,
    COUNT(*) AS total_pointages
    FROM presence_journaliere WHERE date_presence BETWEEN ? AND ?");
$stmt->execute([$dateDebut, $dateFin]);
$stats = $stmt->fetch() ?: [];

$stmt = $pdo->prepare("SELECT COUNT(DISTINCT numero_identification) FROM passage_brut WHERE date_passage BETWEEN ? AND ?");
$stmt->execute([$dateDebut, $dateFin]);
$agentsPointes = (int)$stmt->fetchColumn();
$agentsNonPointes = max(0, $effectifActif - $agentsPointes);

csvRow($out, ['DIRECTION DES RECETTES DU HAUT-KATANGA — DRHKAT']);
csvRow($out, ['TABLEAU DE BORD DES PRÉSENCES']);
csvRow($out, ['Période', $dateDebut, $dateFin]);
csvRow($out, ['Exporté le', date('d/m/Y H:i')]);

csvSection($out, 'INDICATEURS GÉNÉRAUX');
csvRow($out, ['Indicateur', 'Valeur']);
csvRow($out, ['Effectif total', $effectifTotal]);
csvRow($out, ['Agents actifs', $effectifActif]);
csvRow($out, ['Agents ayant pointé', $agentsPointes]);
csvRow($out, ['Agents non pointés', $agentsNonPointes]);
csvRow($out, ['Présences', (int)($stats['presents'] ?? 0)]);
csvRow($out, ['Absences', (int)($stats['absents'] ?? 0)]);
csvRow($out, ['Congés', (int)($stats['conges'] ?? 0)]);
csvRow($out, ['Missions', (int)($stats['missions'] ?? 0)]);
csvRow($out, ['Jours fériés', (int)($stats['feries'] ?? 0)]);
csvRow($out, ['Retards', (int)($stats['en_retard'] ?? 0)]);
csvRow($out, ['Total pointages', (int)($stats['total_pointages'] ?? 0)]);

csvSection($out, 'ÉVOLUTION JOURNALIÈRE');
csvRow($out, ['N°', 'Date', 'Présents', 'Absents', 'Retards']);
$stmt = $pdo->prepare("SELECT date_presence,
    SUM(statut='present') AS presents,
    SUM(statut='absent') AS absents,
    SUM(retard_minutes>0) AS retards
    FROM presence_journaliere
    WHERE date_presence BETWEEN ? AND ?
    GROUP BY date_presence ORDER BY date_presence");
$stmt->execute([$dateDebut, $dateFin]);
$i = 1;
foreach ($stmt as $r) {
    csvRow($out, [$i++, $r['date_presence'], (int)$r['presents'], (int)$r['absents'], (int)$r['retards']]);
}

csvSection($out, 'TOP RETARDATAIRES');
csvRow($out, ['N°', 'Numéro identification', 'Agent', 'Jours de retard', 'Minutes cumulées', 'Tranche']);
$stmt = $pdo->prepare("SELECT p.numero_identification, a.nom_complet,
    COUNT(*) AS jours_retard, SUM(p.retard_minutes) AS retard_minutes,
    MAX(p.tranche_retard) AS tranche_retard
    FROM presence_journaliere p
    JOIN agents a ON a.numero_identification=p.numero_identification
    WHERE p.date_presence BETWEEN ? AND ? AND p.retard_minutes>0
    GROUP BY p.numero_identification, a.nom_complet
    ORDER BY retard_minutes DESC LIMIT 50");
$stmt->execute([$dateDebut, $dateFin]);
$i = 1;
foreach ($stmt as $r) {
    csvRow($out, [$i++, $r['numero_identification'], $r['nom_complet'], (int)$r['jours_retard'], (int)$r['retard_minutes'], $r['tranche_retard']]);
}

csvSection($out, 'SORTIES MANQUANTES');
csvRow($out, ['N°', 'Date', 'Numéro identification', 'Agent', 'Première entrée', 'Anomalies']);
$stmt = $pdo->prepare("SELECT p.date_presence, p.numero_identification, a.nom_complet,
    p.premiere_entree, p.anomalies
    FROM presence_journaliere p
    JOIN agents a ON a.numero_identification=p.numero_identification
    WHERE p.date_presence BETWEEN ? AND ? AND p.anomalies LIKE '%sortie_manquante%'
    ORDER BY p.date_presence DESC, a.nom_complet");
$stmt->execute([$dateDebut, $dateFin]);
$i = 1;
foreach ($stmt as $r) {
    csvRow($out, [$i++, $r['date_presence'], $r['numero_identification'], $r['nom_complet'], $r['premiere_entree'], $r['anomalies']]);
}

csvSection($out, 'CONGÉS EN COURS AU MOMENT DE L’EXPORT');
csvRow($out, ['N°', 'Numéro identification', 'Agent', 'Type', 'Du', 'Au', 'Référence']);
$stmt = $pdo->query("SELECT c.numero_identification, a.nom_complet, c.type, c.date_debut, c.date_fin, c.reference
    FROM conge c JOIN agents a ON a.numero_identification=c.numero_identification
    WHERE c.statut='validee' AND CURDATE() BETWEEN c.date_debut AND c.date_fin
    ORDER BY c.date_fin");
$i = 1;
foreach ($stmt as $r) {
    csvRow($out, [$i++, $r['numero_identification'], $r['nom_complet'], $r['type'], $r['date_debut'], $r['date_fin'], $r['reference']]);
}

fclose($out);
exit;
