<?php
/**
 * Installation initiale sécurisée.
 * Après la création d'un compte administrateur, cette page n'est plus accessible publiquement.
 * Les opérations de maintenance sont disponibles dans Administration > Sécurité & maintenance.
 */
require __DIR__ . '/config.php';

$messages = array();
$erreurs = array();
$alreadyInstalled = false;

try {
    $pdo = db();
    try {
        $alreadyInstalled = (bool)$pdo->query("SELECT COUNT(*) FROM utilisateurs")->fetchColumn();
    } catch (Exception $ignore) {
        $alreadyInstalled = false;
    }
} catch (Exception $e) {
    die('<div style="font-family:Segoe UI;padding:30px;color:#b00"><h2>Connexion MySQL impossible</h2><p>Vérifiez les paramètres de <code>config.php</code>.</p><p>' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</p></div>');
}

$isAdmin = isset($_SESSION['user']) && isset($_SESSION['user']['role']) && $_SESSION['user']['role'] === 'Administrateur';
if ($alreadyInstalled && !$isAdmin) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'installer') {
    try {
        $sql = file_get_contents(__DIR__ . '/schema.sql');
        foreach (array_filter(array_map('trim', preg_split('/;\s*(?:\r?\n|$)/', $sql))) as $req) {
            if ($req === '' || strpos(ltrim($req), '--') === 0) continue;
            $pdo->exec($req);
        }
        $messages[] = 'Toutes les tables ont été créées ou vérifiées.';

        foreach ($GLOBALS['DEFAULTS'] as $cle => $val) {
            $stmt = $pdo->prepare("INSERT INTO parametres(cle,valeur) VALUES(?,?) ON DUPLICATE KEY UPDATE valeur=VALUES(valeur)");
            $stmt->execute(array($cle, (string)$val));
        }

        if (!$alreadyInstalled) {
            $hash = password_hash('admin123', PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO utilisateurs(identifiant, mot_de_passe, nom_complet, role, actif) VALUES('admin', ?, 'Administrateur principal', 'Administrateur', 1)");
            $stmt->execute(array($hash));
            $messages[] = 'Le compte administrateur initial a été créé.';
        }
        $alreadyInstalled = true;
    } catch (Exception $e) {
        $erreurs[] = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="fr"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Installation — <?php echo htmlspecialchars(APP_NAME, ENT_QUOTES, 'UTF-8'); ?></title>
<link rel="stylesheet" href="assets/style.css"></head>
<body style="background:linear-gradient(135deg,#0f172a,#1e3a5f)">
<div style="max-width:760px;margin:40px auto;background:#fff;padding:36px 40px;border-radius:12px;box-shadow:0 10px 40px rgba(0,0,0,.3)">
<h1 style="color:#1e3a5f;margin-top:0">DRHKAT — Installation</h1>
<p>Division des Ressources Humaines et de l’Administration</p><hr>
<?php foreach ($messages as $m): ?><p style="color:#0a7d28">✅ <?php echo htmlspecialchars($m, ENT_QUOTES, 'UTF-8'); ?></p><?php endforeach; ?>
<?php foreach ($erreurs as $e): ?><p style="color:#b00">❌ <?php echo htmlspecialchars($e, ENT_QUOTES, 'UTF-8'); ?></p><?php endforeach; ?>
<?php if ($alreadyInstalled): ?>
<p>L’application est installée. Les outils de réinitialisation et de maintenance sont désormais disponibles uniquement dans <strong>Administration → Sécurité & maintenance</strong>.</p>
<p style="text-align:center"><a href="<?php echo $isAdmin ? 'administration.php?tab=maintenance' : 'login.php'; ?>" class="btn">Continuer</a></p>
<?php else: ?>
<p>Cette opération crée les tables et le premier compte administrateur dans la base existante.</p>
<form method="post" style="text-align:center;margin-top:24px"><input type="hidden" name="action" value="installer"><button type="submit" class="btn">Installer l’application</button></form>
<?php endif; ?>
</div></body></html>
