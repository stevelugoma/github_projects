<?php
$pageTitle = 'Administration';
$activePage = 'administration.php';
require_once __DIR__ . '/helpers.php';

// Accès réservé à l'administrateur
if (!aRole('Administrateur')) {
    flash('error', 'Accès réservé aux administrateurs.');
    redirect('index.php');
}

$pdo = db();
$tab = $_GET['tab'] ?? 'parametres';

// ============================================================
//  TRAITEMENT
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ---- AUTORISATIONS PERSONNALISÉES ----
    if ($action === 'save_permissions') {
        ensurePermissionTable();
        $userId = (int)($_POST['permission_user_id'] ?? 0);
        $catalogue = cataloguePermissions();
        if ($userId <= 0) {
            flash('error','Sélectionnez un utilisateur.');
        } else {
            $pdo->beginTransaction();
            try {
                $pdo->prepare('DELETE FROM utilisateur_permission WHERE utilisateur_id=?')->execute([$userId]);
                $stmtPerm=$pdo->prepare('INSERT INTO utilisateur_permission(utilisateur_id,permission_cle,autorise) VALUES(?,?,?)');
                foreach ($catalogue as $cle=>$libelle) {
                    $autorise = isset($_POST['permissions'][$cle]) ? 1 : 0;
                    $stmtPerm->execute([$userId,$cle,$autorise]);
                }
                $pdo->commit();
                logAudit('update','autorisations_utilisateur',(string)$userId,null,array_keys($_POST['permissions'] ?? []));
                flash('success','Autorisations personnalisées enregistrées.');
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                flash('error','Enregistrement impossible : '.$e->getMessage());
            }
        }
        redirect('administration.php?tab=permissions&user_id='.$userId);
    }

    // ---- PARAMÈTRES ----
    if ($action === 'save_params') {
        foreach (['heure_entree_ref','heure_sortie_ref','tolerance_min','tranche_legere','tranche_moyenne'] as $cle) {
            if (isset($_POST[$cle])) {
                $stmt = $pdo->prepare("INSERT INTO parametres(cle,valeur) VALUES(?,?)
                                       ON DUPLICATE KEY UPDATE valeur=VALUES(valeur)");
                $stmt->execute([$cle, $_POST[$cle]]);
            }
        }
        logAudit('update', 'parametres', null, null, $_POST);
        flash('success', 'Paramètres enregistrés.');
        redirect('administration.php?tab=parametres');
    }

    // ---- UTILISATEURS ----
    if ($action === 'save_user') {
        $id = (int)($_POST['id'] ?? 0);
        $identifiant = trim($_POST['identifiant'] ?? '');
        $nomComplet = trim($_POST['nom_complet'] ?? '');
        $role = $_POST['role'] ?? 'Consultation';
        $actif = isset($_POST['actif']) ? 1 : 0;
        $mdp = $_POST['mot_de_passe'] ?? '';

        if (!$identifiant || !$nomComplet) {
            flash('error', 'Identifiant et nom complet sont obligatoires.');
        } else {
            if ($id) {
                if ($mdp !== '') {
                    $hash = password_hash($mdp, PASSWORD_DEFAULT);
                    $pdo->prepare("UPDATE utilisateurs SET identifiant=?, nom_complet=?, role=?, actif=?, mot_de_passe=? WHERE id=?")
                        ->execute([$identifiant,$nomComplet,$role,$actif,$hash,$id]);
                } else {
                    $pdo->prepare("UPDATE utilisateurs SET identifiant=?, nom_complet=?, role=?, actif=? WHERE id=?")
                        ->execute([$identifiant,$nomComplet,$role,$actif,$id]);
                }
                logAudit('update','utilisateur',$id);
                flash('success','Utilisateur modifié.');
            } else {
                $hash = password_hash(($mdp ?: 'changeme'), PASSWORD_DEFAULT);
                $pdo->prepare("INSERT INTO utilisateurs (identifiant,mot_de_passe,nom_complet,role,actif) VALUES (?,?,?,?,?)")
                    ->execute([$identifiant,$hash,$nomComplet,$role,$actif]);
                logAudit('create','utilisateur',$pdo->lastInsertId());
                flash('success','Utilisateur créé.');
            }
        }
        redirect('administration.php?tab=utilisateurs');
    }
    if ($action === 'del_user') {
        $id = (int)$_POST['id'];
        if ($id === (int)($_SESSION['user']['id'] ?? 0)) {
            flash('error','Vous ne pouvez pas supprimer votre propre compte.');
        } else {
            $pdo->prepare("DELETE FROM utilisateurs WHERE id=?")->execute([$id]);
            logAudit('delete','utilisateur',$id);
            flash('success','Utilisateur supprimé.');
        }
        redirect('administration.php?tab=utilisateurs');
    }

    // ---- JOURS FERIES ----
    if ($action === 'save_ferie') {
        $d = $_POST['date_jour'] ?? ''; $lib = trim($_POST['libelle'] ?? ''); $type = $_POST['type'] ?? 'ferie';
        if ($d && $lib) {
            $pdo->prepare("INSERT INTO jour_ferie (date_jour,libelle,type) VALUES (?,?,?)
                           ON DUPLICATE KEY UPDATE libelle=VALUES(libelle), type=VALUES(type)")
                ->execute([$d,$lib,$type]);
            logAudit('create','jour_ferie',$d);
            flash('success','Jour férié enregistré.');
        }
        redirect('administration.php?tab=feries');
    }
    if ($action === 'del_ferie') {
        $pdo->prepare("DELETE FROM jour_ferie WHERE id=?")->execute([(int)$_POST['id']]);
        flash('success','Jour férié supprimé.');
        redirect('administration.php?tab=feries');
    }

    // ---- SECURITE ET MAINTENANCE ----
    if ($action === 'reset_user_password') {
        $userId = (int)($_POST['user_id'] ?? 0);
        $newPassword = (string)($_POST['new_password'] ?? '');
        $confirmPassword = (string)($_POST['confirm_password'] ?? '');
        $adminPassword = (string)($_POST['admin_password'] ?? '');

        $stmt = $pdo->prepare("SELECT mot_de_passe FROM utilisateurs WHERE id=?");
        $stmt->execute([$_SESSION['user']['id']]);
        $adminHash = $stmt->fetchColumn();

        if (!$adminHash || !password_verify($adminPassword, $adminHash)) {
            flash('error', 'Mot de passe administrateur incorrect.');
        } elseif ($userId <= 0) {
            flash('error', 'Sélectionnez un utilisateur.');
        } elseif (strlen($newPassword) < 8) {
            flash('error', 'Le nouveau mot de passe doit contenir au moins 8 caractères.');
        } elseif ($newPassword !== $confirmPassword) {
            flash('error', 'La confirmation du nouveau mot de passe ne correspond pas.');
        } else {
            $stmt = $pdo->prepare("UPDATE utilisateurs SET mot_de_passe=? WHERE id=?");
            $stmt->execute([password_hash($newPassword, PASSWORD_DEFAULT), $userId]);
            logAudit('reset_password', 'utilisateur', $userId);
            flash('success', 'Mot de passe réinitialisé avec succès.');
        }
        redirect('administration.php?tab=maintenance');
    }

    if ($action === 'upgrade_schema') {
        $adminPassword = (string)($_POST['admin_password'] ?? '');
        $stmt = $pdo->prepare("SELECT mot_de_passe FROM utilisateurs WHERE id=?");
        $stmt->execute([$_SESSION['user']['id']]);
        $adminHash = $stmt->fetchColumn();

        if (!$adminHash || !password_verify($adminPassword, $adminHash)) {
            flash('error', 'Mot de passe administrateur incorrect.');
        } else {
            try {
                $sql = file_get_contents(__DIR__ . '/schema.sql');
                $requests = array_filter(array_map('trim', preg_split('/;\s*(?:\r?\n|$)/', $sql)));
                foreach ($requests as $request) {
                    if ($request === '' || strpos(ltrim($request), '--') === 0) continue;
                    $pdo->exec($request);
                }
                logAudit('upgrade_schema', 'base_de_donnees');
                flash('success', 'Structure de la base vérifiée et mise à niveau.');
            } catch (Throwable $e) {
                flash('error', 'Échec de la mise à niveau : ' . h($e->getMessage()));
            }
        }
        redirect('administration.php?tab=maintenance');
    }

    if ($action === 'clear_import_history') {
        $adminPassword = (string)($_POST['admin_password'] ?? '');
        $confirmation = trim((string)($_POST['confirmation'] ?? ''));
        $stmt = $pdo->prepare("SELECT mot_de_passe FROM utilisateurs WHERE id=?");
        $stmt->execute([$_SESSION['user']['id']]);
        $adminHash = $stmt->fetchColumn();

        if (!$adminHash || !password_verify($adminPassword, $adminHash)) {
            flash('error', 'Mot de passe administrateur incorrect.');
        } elseif ($confirmation !== 'VIDER IMPORTS') {
            flash('error', 'Saisissez exactement VIDER IMPORTS pour confirmer.');
        } else {
            $pdo->exec("DELETE FROM import_lot");
            logAudit('clear', 'import_lot');
            flash('success', 'Historique des imports vidé. Les fichiers peuvent être réimportés.');
        }
        redirect('administration.php?tab=maintenance');
    }

    // ---- MON COMPTE : changement de mot de passe ----
    if ($action === 'change_password') {
        $old = $_POST['old_password'] ?? ''; $new = $_POST['new_password'] ?? ''; $confirm = $_POST['confirm_password'] ?? '';
        $stmt = $pdo->prepare("SELECT mot_de_passe FROM utilisateurs WHERE id=?");
        $stmt->execute([$_SESSION['user']['id']]);
        $hash = $stmt->fetchColumn();
        if (!password_verify($old, $hash)) {
            flash('error','Ancien mot de passe incorrect.');
        } elseif (strlen($new) < 6) {
            flash('error','Le nouveau mot de passe doit faire au moins 6 caractères.');
        } elseif ($new !== $confirm) {
            flash('error','La confirmation ne correspond pas.');
        } else {
            $pdo->prepare("UPDATE utilisateurs SET mot_de_passe=? WHERE id=?")
                ->execute([password_hash($new, PASSWORD_DEFAULT), $_SESSION['user']['id']]);
            logAudit('update_password','utilisateur',$_SESSION['user']['id']);
            flash('success','Mot de passe modifié avec succès.');
        }
        redirect('administration.php?tab=compte');
    }
}

include __DIR__ . '/partials/layout.php';

$tabs = [
    'parametres'   => '⚙️ Paramètres',
    'utilisateurs' => '👥 Utilisateurs',
    'permissions'  => '🔑 Autorisations',
    'feries'       => '📅 Jours fériés',
    'audit'        => '📜 Journal d\'audit',
    'maintenance'  => '🛡️ Sécurité & maintenance',
    'compte'       => '🔐 Mon compte',
];
?>
<div class="card">
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:16px">
        <?php foreach ($tabs as $k => $v): ?>
            <a href="administration.php?tab=<?php echo $k; ?>" class="btn btn-sm <?php echo $tab===$k?'':'btn-outline'; ?>"><?php echo $v; ?></a>
        <?php endforeach; ?>
    </div>

    <?php if ($tab === 'parametres'): ?>
        <h2 style="margin-bottom:16px">Paramètres de ponctualité</h2>
        <p class="text-muted mb-2">Ces valeurs définissent l'horaire de référence et les tranches de retard appliquées par défaut.</p>
        <form method="post" action="administration.php?tab=parametres">
            <input type="hidden" name="action" value="save_params">
            <div class="form-grid">
                <div class="form-group">
                    <label>Heure normale d'entrée</label>
                    <input type="time" name="heure_entree_ref" value="<?php echo h(substr(parametre('heure_entree_ref','08:00'),0,5)); ?>">
                </div>
                <div class="form-group">
                    <label>Heure normale de sortie</label>
                    <input type="time" name="heure_sortie_ref" value="<?php echo h(substr(parametre('heure_sortie_ref','16:00'),0,5)); ?>">
                </div>
                <div class="form-group">
                    <label>Tolérance (minutes)</label>
                    <input type="number" name="tolerance_min" value="<?php echo (int)parametre('tolerance_min',5); ?>" min="0">
                </div>
                <div class="form-group">
                    <label>Tranche « léger » (minutes max)</label>
                    <input type="number" name="tranche_legere" value="<?php echo (int)parametre('tranche_legere',15); ?>" min="1">
                </div>
                <div class="form-group">
                    <label>Tranche « moyen » (minutes max)</label>
                    <input type="number" name="tranche_moyenne" value="<?php echo (int)parametre('tranche_moyenne',30); ?>" min="1">
                    <small>Au-delà, le retard est classé « grave ».</small>
                </div>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn btn-success">💾 Enregistrer</button>
            </div>
        </form>

    <?php elseif ($tab === 'utilisateurs'):
        $users = $pdo->query("SELECT * FROM utilisateurs ORDER BY nom_complet")->fetchAll();
        $editU = null;
        if ($_GET['action'] ?? '' === 'edit') {
            $s = $pdo->prepare("SELECT * FROM utilisateurs WHERE id=?"); $s->execute([(int)$_GET['id']]);
            $editU = $s->fetch();
        }
        $roles = ['Administrateur','Gestionnaire RH','Gestionnaire présences','Validateur','Consultation','Agent'];
    ?>
        <h2 style="margin-bottom:16px"><?php echo $editU ? 'Modifier' : 'Créer'; ?> un utilisateur</h2>
        <form method="post" action="administration.php?tab=utilisateurs" class="mb-2">
            <input type="hidden" name="action" value="save_user">
            <input type="hidden" name="id" value="<?php echo (int)($editU['id'] ?? 0); ?>">
            <div class="form-grid">
                <div class="form-group"><label>Identifiant *</label><input type="text" name="identifiant" required value="<?php echo h($editU['identifiant'] ?? ''); ?>"></div>
                <div class="form-group"><label>Nom complet *</label><input type="text" name="nom_complet" required value="<?php echo h($editU['nom_complet'] ?? ''); ?>"></div>
                <div class="form-group">
                    <label>Rôle</label>
                    <select name="role">
                        <?php foreach ($roles as $r): ?>
                            <option value="<?php echo $r; ?>" <?php echo ($editU['role'] ?? '')===$r?'selected':''; ?>><?php echo $r; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group"><label>Mot de passe <?php echo $editU ? '<small>(laisser vide pour conserver)</small>' : ''; ?></label><input type="text" name="mot_de_passe" value=""></div>
                <div class="form-group">
                    <label>Statut</label>
                    <label style="font-weight:normal;display:flex;align-items:center;gap:8px;margin-top:6px">
                        <input type="checkbox" name="actif" value="1" <?php echo (!isset($editU) || $editU['actif'])?'checked':''; ?>> Compte actif
                    </label>
                </div>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn btn-success">💾 Enregistrer</button>
                <?php if ($editU): ?><a href="administration.php?tab=utilisateurs" class="btn btn-secondary">Annuler</a><?php endif; ?>
            </div>
        </form>

        <div class="table-wrap">
            <table class="data-table">
                <thead><tr><th>Identifiant</th><th>Nom complet</th><th>Rôle</th><th>Statut</th><th>Dernière connexion</th><th class="actions">Actions</th></tr></thead>
                <tbody>
                <?php foreach ($users as $u): ?>
                    <tr>
                        <td><b><?php echo h($u['identifiant']); ?></b></td>
                        <td><?php echo h($u['nom_complet']); ?></td>
                        <td><span class="badge badge-blue"><?php echo h($u['role']); ?></span></td>
                        <td><?php echo $u['actif']?'<span class="badge badge-green">Actif</span>':'<span class="badge badge-red">Inactif</span>'; ?></td>
                        <td><small><?php echo $u['derniere_connexion'] ? formatDateFr(substr($u['derniere_connexion'],0,10)).' '.substr($u['derniere_connexion'],11,5) : '—'; ?></small></td>
                        <td class="actions">
                            <a href="administration.php?tab=utilisateurs&action=edit&id=<?php echo (int)$u['id']; ?>">✏️</a>
                            <form method="post" style="display:inline">
                                <input type="hidden" name="action" value="del_user">
                                <input type="hidden" name="id" value="<?php echo (int)$u['id']; ?>">
                                <button type="submit" title="Supprimer" onclick="return confirm('Supprimer cet utilisateur ?')" style="background:none;border:none;cursor:pointer">🗑️</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    <?php elseif ($tab === 'permissions'):
        ensurePermissionTable();
        $permissionUsers=$pdo->query("SELECT id,identifiant,nom_complet,role,actif FROM utilisateurs ORDER BY nom_complet")->fetchAll();
        $permissionUserId=(int)($_GET['user_id'] ?? 0);
        $permissionUser=null; $permissionValues=[];
        if ($permissionUserId) {
            $st=$pdo->prepare('SELECT id,identifiant,nom_complet,role,actif FROM utilisateurs WHERE id=?'); $st->execute([$permissionUserId]); $permissionUser=$st->fetch();
            $st=$pdo->prepare('SELECT permission_cle,autorise FROM utilisateur_permission WHERE utilisateur_id=?'); $st->execute([$permissionUserId]);
            foreach($st->fetchAll() as $pr) $permissionValues[$pr['permission_cle']]=(bool)$pr['autorise'];
        }
        $permissionCatalogue=cataloguePermissions();
        $permissionDefaults=$permissionUser ? permissionsRoleDefaut($permissionUser['role']) : [];
    ?>
        <h2 style="margin-bottom:8px">Autorisations personnalisées</h2>
        <p class="text-muted mb-3">Sélectionnez un utilisateur puis accordez ou retirez précisément ses droits. Les cases enregistrées remplacent les droits par défaut de son rôle.</p>
        <form method="get" class="filters mb-3">
            <input type="hidden" name="tab" value="permissions">
            <div class="form-group" style="min-width:320px"><label>Utilisateur</label><select name="user_id" required onchange="this.form.submit()"><option value="">— Sélectionner —</option><?php foreach($permissionUsers as $u): ?><option value="<?php echo (int)$u['id']; ?>" <?php echo $permissionUserId===(int)$u['id']?'selected':''; ?>><?php echo h($u['nom_complet'].' — '.$u['identifiant'].' ('.$u['role'].')'); ?></option><?php endforeach; ?></select></div>
            <div class="form-group" style="flex:0"><button class="btn">Charger</button></div>
        </form>
        <?php if($permissionUser): ?>
        <form method="post" action="administration.php?tab=permissions&user_id=<?php echo $permissionUserId; ?>">
            <input type="hidden" name="action" value="save_permissions"><input type="hidden" name="permission_user_id" value="<?php echo $permissionUserId; ?>">
            <div class="alert alert-info"><strong><?php echo h($permissionUser['nom_complet']); ?></strong> — rôle : <?php echo h($permissionUser['role']); ?>. <?php echo $permissionUser['role']==='Administrateur'?'Les administrateurs conservent toujours tous les droits.':'Vous pouvez personnaliser chaque autorisation ci-dessous.'; ?></div>
            <div class="row g-3">
            <?php foreach($permissionCatalogue as $cle=>$libelle): $checked=array_key_exists($cle,$permissionValues)?$permissionValues[$cle]:!empty($permissionDefaults[$cle]); ?>
                <div class="col-md-6"><label class="border rounded-3 p-3 d-flex gap-3 align-items-start h-100" style="cursor:pointer"><input class="form-check-input mt-1" type="checkbox" name="permissions[<?php echo h($cle); ?>]" value="1" <?php echo $checked?'checked':''; ?> <?php echo $permissionUser['role']==='Administrateur'?'disabled':''; ?>><span><strong><?php echo h($libelle); ?></strong><br><small class="text-muted"><code><?php echo h($cle); ?></code></small></span></label></div>
            <?php endforeach; ?>
            </div>
            <?php if($permissionUser['role']!=='Administrateur'): ?><div class="form-actions mt-3"><button class="btn btn-success">💾 Enregistrer les autorisations</button></div><?php endif; ?>
        </form>
        <?php endif; ?>

    <?php elseif ($tab === 'feries'):
        $feries = $pdo->query("SELECT * FROM jour_ferie ORDER BY date_jour")->fetchAll();
    ?>
        <h2 style="margin-bottom:16px">Jours fériés & jours de repos</h2>
        <form method="post" action="administration.php?tab=feries" class="mb-2">
            <input type="hidden" name="action" value="save_ferie">
            <div class="form-grid">
                <div class="form-group"><label>Date *</label><input type="date" name="date_jour" required></div>
                <div class="form-group"><label>Libellé *</label><input type="text" name="libelle" required placeholder="ex: Fête nationale"></div>
                <div class="form-group">
                    <label>Type</label>
                    <select name="type"><option value="ferie">Férié</option><option value="repos">Repos</option></select>
                </div>
            </div>
            <button type="submit" class="btn btn-success">➕ Ajouter</button>
        </form>
        <div class="table-wrap">
            <table class="data-table">
                <thead><tr><th>Date</th><th>Libellé</th><th>Type</th><th class="actions">Action</th></tr></thead>
                <tbody>
                <?php foreach ($feries as $f): ?>
                    <tr>
                        <td><?php echo formatDateFr($f['date_jour']); ?></td>
                        <td><?php echo h($f['libelle']); ?></td>
                        <td><span class="badge <?php echo $f['type']==='ferie'?'badge-red':'badge-gray'; ?>"><?php echo h($f['type']); ?></span></td>
                        <td class="actions">
                            <form method="post" style="display:inline">
                                <input type="hidden" name="action" value="del_ferie">
                                <input type="hidden" name="id" value="<?php echo (int)$f['id']; ?>">
                                <button type="submit" onclick="return confirm('Supprimer ?')" style="background:none;border:none;cursor:pointer">🗑️</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    <?php elseif ($tab === 'audit'):
        $logs = $pdo->query("SELECT * FROM audit_log ORDER BY date_action DESC LIMIT 200")->fetchAll();
    ?>
        <h2 style="margin-bottom:16px">Journal d'audit (RG-08)</h2>
        <p class="text-muted mb-2">Toutes les actions sensibles sont tracées ici.</p>
        <div class="table-wrap">
            <table class="data-table">
                <thead><tr><th>Date/Heure</th><th>Utilisateur</th><th>Action</th><th>Objet</th><th>IP</th></tr></thead>
                <tbody>
                <?php foreach ($logs as $l): ?>
                    <tr>
                        <td><small><?php echo formatDateFr(substr($l['date_action'],0,10)).' '.substr($l['date_action'],11); ?></small></td>
                        <td><?php echo h($l['utilisateur_nom']); ?></td>
                        <td><span class="badge badge-blue"><?php echo h($l['action']); ?></span></td>
                        <td><?php echo h($l['objet'] ?: '—'); ?> <?php if ($l['objet_id']) echo '<small>#'.h($l['objet_id']).'</small>'; ?></td>
                        <td><small><?php echo h($l['adresse_ip'] ?: '—'); ?></small></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    <?php elseif ($tab === 'maintenance'):
        $maintenanceUsers = $pdo->query("SELECT id, identifiant, nom_complet, role, actif FROM utilisateurs ORDER BY nom_complet")->fetchAll();
        $dbVersion = $pdo->query("SELECT VERSION()")->fetchColumn();
        $tableCount = $pdo->query("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE()")->fetchColumn();
    ?>
        <h2 style="margin-bottom:8px">Sécurité et maintenance</h2>
        <p class="text-muted mb-3">Ces outils sont réservés aux administrateurs. Les actions sensibles exigent votre mot de passe.</p>

        <div class="row g-3 mb-4">
            <div class="col-md-6">
                <div class="border rounded-3 p-3 h-100">
                    <h3 class="h5">Réinitialiser le mot de passe d’un utilisateur</h3>
                    <form method="post" action="administration.php?tab=maintenance" autocomplete="off">
                        <input type="hidden" name="action" value="reset_user_password">
                        <div class="form-group">
                            <label>Utilisateur</label>
                            <select name="user_id" required>
                                <option value="">Sélectionner…</option>
                                <?php foreach ($maintenanceUsers as $u): ?>
                                    <option value="<?php echo (int)$u['id']; ?>"><?php echo h($u['nom_complet'] . ' — ' . $u['identifiant'] . ' (' . $u['role'] . ')'); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group"><label>Nouveau mot de passe</label><input type="password" name="new_password" minlength="8" required></div>
                        <div class="form-group"><label>Confirmer le nouveau mot de passe</label><input type="password" name="confirm_password" minlength="8" required></div>
                        <div class="form-group"><label>Votre mot de passe administrateur</label><input type="password" name="admin_password" required></div>
                        <button type="submit" class="btn btn-warning">Réinitialiser le mot de passe</button>
                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="border rounded-3 p-3 h-100">
                    <h3 class="h5">Base de données</h3>
                    <p><strong>Base :</strong> <?php echo h(DB_NAME); ?><br><strong>Serveur :</strong> <?php echo h(DB_HOST); ?><br><strong>Version MySQL :</strong> <?php echo h($dbVersion); ?><br><strong>Tables :</strong> <?php echo (int)$tableCount; ?></p>
                    <form method="post" action="administration.php?tab=maintenance">
                        <input type="hidden" name="action" value="upgrade_schema">
                        <div class="form-group"><label>Votre mot de passe administrateur</label><input type="password" name="admin_password" required></div>
                        <button type="submit" class="btn btn-primary">Vérifier / mettre à niveau les tables</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="border border-warning rounded-3 p-3">
            <h3 class="h5 text-warning">Réautoriser les réimportations</h3>
            <p class="text-muted">Vide uniquement l’historique des lots importés. Les agents, pointages et présences déjà enregistrés ne sont pas supprimés.</p>
            <form method="post" action="administration.php?tab=maintenance" class="row g-3 align-items-end">
                <input type="hidden" name="action" value="clear_import_history">
                <div class="col-md-4 form-group"><label>Confirmation</label><input type="text" name="confirmation" placeholder="VIDER IMPORTS" required></div>
                <div class="col-md-4 form-group"><label>Votre mot de passe administrateur</label><input type="password" name="admin_password" required></div>
                <div class="col-md-4"><button type="submit" class="btn btn-outline-warning" onclick="return confirm('Vider l’historique des imports ?')">Vider l’historique des imports</button></div>
            </form>
        </div>

    <?php elseif ($tab === 'compte'): ?>
        <h2 style="margin-bottom:16px">Changer mon mot de passe</h2>
        <form method="post" action="administration.php?tab=compte" style="max-width:420px">
            <input type="hidden" name="action" value="change_password">
            <div class="form-group"><label>Ancien mot de passe</label><input type="password" name="old_password" required></div>
            <div class="form-group"><label>Nouveau mot de passe</label><input type="password" name="new_password" required></div>
            <div class="form-group"><label>Confirmer</label><input type="password" name="confirm_password" required></div>
            <button type="submit" class="btn btn-success">🔐 Modifier</button>
        </form>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/partials/footer.php'; ?>
