<?php
require_once __DIR__ . '/helpers.php';

// déjà connecté ?
if (isset($_SESSION['user'])) {
    redirect('index.php');
}

$erreur = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifiant = trim($_POST['identifiant'] ?? '');
    $motdepasse  = $_POST['mot_de_passe'] ?? '';

    if ($identifiant === '' || $motdepasse === '') {
        $erreur = 'Veuillez saisir votre identifiant et votre mot de passe.';
    } else {
        try {
            $stmt = db()->prepare("SELECT * FROM utilisateurs WHERE identifiant = ? AND actif = 1");
            $stmt->execute([$identifiant]);
            $user = $stmt->fetch();

            if ($user && password_verify($motdepasse, $user['mot_de_passe'])) {
                // connexion OK
                $_SESSION['user'] = [
                    'id'          => $user['id'],
                    'identifiant' => $user['identifiant'],
                    'nom_complet' => $user['nom_complet'],
                    'role'        => $user['role'],
                    'actif'       => (int)$user['actif'],
                ];
                $upd = db()->prepare("UPDATE utilisateurs SET derniere_connexion=NOW() WHERE id=?");
                $upd->execute([$user['id']]);
                require_once __DIR__ . '/helpers.php';
                logAudit('login', 'utilisateur', $user['id']);
                redirect('index.php');
            } else {
                $erreur = 'Identifiant ou mot de passe incorrect.';
            }
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'Unknown database') !== false || strpos($e->getMessage(), 'exist') !== false) {
                redirect('install.php');
            }
            $erreur = 'Base de données indisponible : ' . htmlspecialchars($e->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Connexion — <?php echo APP_NAME; ?></title>
<link rel="icon" type="image/png" href="assets/img/favicon-drhkat.png">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css?v=<?php echo rawurlencode(APP_VERSION); ?>">
<style>
.login-official-logo{display:block!important;width:min(420px,80%)!important;height:auto!important;max-height:290px!important;object-fit:contain!important;margin:0 auto!important}
.login-card-logo{display:block!important;width:130px!important;height:92px!important;max-width:130px!important;max-height:92px!important;object-fit:contain!important;margin:0 auto 14px!important}
</style>
</head>
<body class="login-body">
<div class="login-shell">
    <section class="login-showcase">
        <div class="login-showcase-overlay"></div>
        <div class="login-showcase-content">
            <img src="<?php echo h(ORG_LOGO); ?>" alt="Logo officiel DRHKAT" class="login-official-logo">
            <p class="login-eyebrow">République Démocratique du Congo</p>
            <h2><?php echo h(ORG_NAME); ?></h2>
            <p class="login-division"><?php echo h(ORG_DIVISION); ?></p>
            <div class="login-contact-grid">
                <a href="<?php echo h(ORG_WEBSITE); ?>" target="_blank" rel="noopener noreferrer"><i class="bi bi-globe2"></i><span><small>Site officiel</small>www.edrhkat.com</span></a>
                <a href="<?php echo h(ORG_WEBMAIL); ?>" target="_blank" rel="noopener noreferrer"><i class="bi bi-envelope-at"></i><span><small>Messagerie interne</small>mail.edrhkat.com</span></a>
                <a href="mailto:<?php echo h(ORG_EMAIL); ?>"><i class="bi bi-send"></i><span><small>Contact</small><?php echo h(ORG_EMAIL); ?></span></a>
            </div>
        </div>
    </section>
    <section class="login-panel">
        <div class="login-card">
            <div class="login-header">
                <img src="<?php echo h(ORG_LOGO); ?>" alt="Logo DRHKAT" class="login-card-logo">
                <span class="login-badge">Portail sécurisé</span>
                <h1>Gestion des présences</h1>
                <p class="login-device">Accès réservé au personnel autorisé</p>
            </div>

            <?php if ($erreur): ?>
                <div class="alert alert-error"><?php echo $erreur; ?></div>
            <?php endif; ?>

            <form method="post" class="login-form">
                <label>
                    <span><i class="bi bi-person"></i> Identifiant</span>
                    <input type="text" name="identifiant" autofocus required autocomplete="username"
                           value="<?php echo h(isset($_POST['identifiant']) ? $_POST['identifiant'] : ''); ?>">
                </label>
                <label>
                    <span><i class="bi bi-shield-lock"></i> Mot de passe</span>
                    <input type="password" name="mot_de_passe" required autocomplete="current-password">
                </label>
                <button type="submit" class="btn btn-block login-submit"><i class="bi bi-box-arrow-in-right"></i> Se connecter</button>
            </form>
            <div class="login-card-links">
                <a href="<?php echo h(ORG_WEBSITE); ?>" target="_blank" rel="noopener noreferrer">Site officiel</a>
                <span>•</span>
                <a href="<?php echo h(ORG_WEBMAIL); ?>" target="_blank" rel="noopener noreferrer">Messagerie</a>
                <span>•</span>
                <a href="mailto:<?php echo h(ORG_EMAIL); ?>">Assistance</a>
            </div>
        </div>
    </section>
</div>
</body>
</html>
