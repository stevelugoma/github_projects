MISE À JOUR — NUMÉROTATION AUTOMATIQUE DYNAMIQUE DES LISTES

Toutes les listes principales affichent désormais une première colonne « N° ».

Fonctionnement :
- numérotation automatique à partir de 1 ;
- recalcul après recherche générale ou personnalisée ;
- recalcul après tri des colonnes ;
- recalcul après filtrage ;
- continuité entre les pages (ex. 1–25, puis 26–50) ;
- mise à jour des listes chargées dynamiquement ;
- colonne non triable et non recherchable ;
- aucune donnée de numérotation n’est enregistrée dans MySQL.

La fonctionnalité couvre notamment : personnel, agents, présences, retards,
absences, congés, horaires, rapports, administration, référentiels et détails
d’effectifs ouverts depuis les graphiques.
