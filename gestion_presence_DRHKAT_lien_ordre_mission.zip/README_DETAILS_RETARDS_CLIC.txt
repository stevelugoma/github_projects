MISE À JOUR — DÉTAIL DES RETARDS AU CLIC
========================================

Dans Suivi des retards > Classement des agents :
- cliquez sur une ligne pour ouvrir le détail de l'agent ;
- la fenêtre affiche le nombre de retards, les minutes cumulées et la moyenne ;
- le tableau détaille la date, l'arrivée, l'horaire, le retard, la tranche et la justification ;
- une recherche instantanée est disponible dans la fenêtre ;
- les filtres de période, tranche et justification déjà appliqués sont respectés ;
- la fenêtre peut être fermée par le bouton, un clic en dehors ou la touche Échap ;
- la navigation au clavier fonctionne avec Entrée ou Espace sur une ligne.

Aucune migration SQL n'est nécessaire.
