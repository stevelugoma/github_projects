MISE À JOUR — IMPRESSION ET EXPORT DU TABLEAU DE BORD

1. Deux boutons ont été ajoutés en haut du tableau de bord :
   - Exporter le tableau de bord
   - Imprimer le tableau de bord

2. L'impression utilise le formulaire global de sélection du signataire déjà présent dans l'application.

3. L'export CSV compatible Excel contient :
   - les indicateurs généraux ;
   - l'évolution journalière ;
   - le classement des retardataires ;
   - les sorties manquantes ;
   - les congés en cours.

4. La période exportée correspond exactement aux dates choisies sur le tableau de bord.
