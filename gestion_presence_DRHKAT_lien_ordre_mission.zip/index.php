<?php
$pageTitle = 'Tableau de bord';
$activePage = 'index.php';
require_once __DIR__ . '/helpers.php';
include __DIR__ . '/partials/layout.php';

$pdo = db();

// Période de référence : par défaut, le mois civil précédent complet.
// Exemple : en juillet, la période proposée est du 1er au 30 juin.
$dateFin = isset($_GET['date_fin']) ? trim($_GET['date_fin']) : '';
$dateDebut = isset($_GET['date_debut']) ? trim($_GET['date_debut']) : '';
if ($dateDebut === '' && $dateFin === '') {
    $dateDebut = date('Y-m-01', strtotime('first day of previous month'));
    $dateFin = date('Y-m-t', strtotime('last day of previous month'));
} elseif ($dateDebut === '') {
    $dateDebut = date('Y-m-01', strtotime($dateFin));
} elseif ($dateFin === '') {
    $dateFin = date('Y-m-t', strtotime($dateDebut));
}
if ($dateDebut > $dateFin) {
    $tmpDate = $dateDebut;
    $dateDebut = $dateFin;
    $dateFin = $tmpDate;
}
$dateJour = $dateFin;
$libellePeriode = ($dateDebut === $dateFin)
    ? formatDateFr($dateDebut)
    : formatDateFr($dateDebut) . ' au ' . formatDateFr($dateFin);

// ====== STATISTIQUES ======
$effectifTotal = (int)$pdo->query("SELECT COUNT(*) FROM agents")->fetchColumn();
$effectifActif = (int)$pdo->query("SELECT COUNT(*) FROM agents WHERE statut=1")->fetchColumn();

$stmt = $pdo->prepare("SELECT
    SUM(statut='present')  AS presents,
    SUM(statut='absent')   AS absents,
    SUM(statut='conge')    AS conges,
    SUM(statut='mission')  AS missions,
    SUM(statut='ferie')    AS feries,
    SUM(retard_minutes>0)  AS en_retard,
    COUNT(*)               AS total_pointages
    FROM presence_journaliere WHERE date_presence BETWEEN ? AND ?");
$stmt->execute([$dateDebut, $dateFin]);
$stats = $stmt->fetch();

$stmtAgentsPointes = $pdo->prepare("SELECT COUNT(DISTINCT numero_identification) FROM passage_brut WHERE date_passage BETWEEN ? AND ?");
$stmtAgentsPointes->execute([$dateDebut, $dateFin]);
$agentsPointes = (int)$stmtAgentsPointes->fetchColumn();
$agentsNonPointes = max(0, $effectifActif - $agentsPointes);

// retardataires du jour (top 10)
$stmt = $pdo->prepare("SELECT p.numero_identification, a.nom_complet,
        MAX(p.premiere_entree) AS premiere_entree,
        SUM(p.retard_minutes) AS retard_minutes,
        MAX(p.tranche_retard) AS tranche_retard,
        COUNT(*) AS jours_retard
    FROM presence_journaliere p
    JOIN agents a ON a.numero_identification = p.numero_identification
    WHERE p.date_presence BETWEEN ? AND ? AND p.retard_minutes > 0
    GROUP BY p.numero_identification, a.nom_complet
    ORDER BY retard_minutes DESC LIMIT 10");
$stmt->execute([$dateDebut, $dateFin]);
$retardataires = $stmt->fetchAll();

// derniers imports
$imports = $pdo->query("SELECT * FROM import_lot ORDER BY date_import DESC LIMIT 5")->fetchAll();

// alertes : agents avec anomalie sortie manquante
$stmt = $pdo->prepare("SELECT p.*, a.nom_complet FROM presence_journaliere p
    JOIN agents a ON a.numero_identification = p.numero_identification
    WHERE p.date_presence BETWEEN ? AND ? AND p.anomalies LIKE '%sortie_manquante%'
    ORDER BY p.date_presence DESC, a.nom_complet LIMIT 10");
$stmt->execute([$dateDebut, $dateFin]);
$sortiesManquantes = $stmt->fetchAll();

// conges en cours
$congesEnCours = $pdo->query("SELECT c.*, a.nom_complet FROM conge c
    JOIN agents a ON a.numero_identification = c.numero_identification
    WHERE c.statut='validee' AND CURDATE() BETWEEN c.date_debut AND c.date_fin
    ORDER BY c.date_fin")->fetchAll();

// Évolution des Période sélectionnée disponibles
$stmtEvolution = $pdo->prepare("SELECT date_presence,
    SUM(statut='present') AS presents, SUM(statut='absent') AS absents,
    SUM(retard_minutes>0) AS retards
    FROM presence_journaliere
    WHERE date_presence BETWEEN ? AND ?
    GROUP BY date_presence ORDER BY date_presence DESC");
$stmtEvolution->execute([$dateDebut, $dateFin]);
$evolution = $stmtEvolution->fetchAll();
$evolution = array_reverse($evolution);

// Données des graphiques préparées côté PHP pour rester compatible avec les anciennes versions.
$chartLabels = array();
$chartPresents = array();
$chartRetards = array();
$chartAbsents = array();
foreach ($evolution as $ligneEvolution) {
    $chartLabels[] = formatDateFr($ligneEvolution['date_presence']);
    $chartPresents[] = (int) $ligneEvolution['presents'];
    $chartRetards[] = (int) $ligneEvolution['retards'];
    $chartAbsents[] = (int) $ligneEvolution['absents'];
}
?>

<!-- Intervalle de référence -->
<div class="card no-print-control" style="margin-bottom:14px;border-color:rgba(59,130,246,.45)">
    <div class="card-header" style="gap:14px;align-items:center;flex-wrap:wrap">
        <div>
            <h2 style="margin:0"><i class="bi bi-briefcase-fill me-2"></i>Ordres de mission</h2>
            <p class="text-muted" style="margin:5px 0 0">Accédez directement à l’application de gestion des ordres de mission de la DRHKAT.</p>
        </div>
        <a class="btn btn-sm" href="https://ordremission.edrhkat.com" target="_blank" rel="noopener noreferrer">
            <i class="bi bi-box-arrow-up-right me-1"></i> Ouvrir Ordre Mission
        </a>
    </div>
</div>

<div class="dashboard-actions no-print-control" style="display:flex;justify-content:flex-end;gap:8px;flex-wrap:wrap;margin-bottom:12px">
    <a class="btn btn-sm btn-success" href="dashboard_export.php?<?php echo h(http_build_query(['date_debut'=>$dateDebut,'date_fin'=>$dateFin])); ?>">
        <i class="bi bi-file-earmark-spreadsheet me-1"></i> Exporter le tableau de bord
    </a>
    <button type="button" class="btn btn-sm btn-outline" onclick="window.print()">
        <i class="bi bi-printer me-1"></i> Imprimer le tableau de bord
    </button>
</div>

<div class="filters">
    <form method="get">
        <div class="form-group">
            <label for="date_debut">📅 Date de début</label>
            <input type="date" name="date_debut" id="date_debut" value="<?php echo h($dateDebut); ?>" required>
        </div>
        <div class="form-group">
            <label for="date_fin">📅 Date de fin</label>
            <input type="date" name="date_fin" id="date_fin" value="<?php echo h($dateFin); ?>" required>
        </div>
        <div class="form-group" style="flex:0">
            <button type="submit" class="btn">Actualiser</button>
        </div>
    </form>
</div>

<!-- Cartes statistiques -->
<div class="stat-grid">
    <div class="stat-card blue">
        <div class="stat-icon">👥</div>
        <div><div class="stat-value"><?php echo $effectifActif; ?></div><div class="stat-label">Agents actifs (<?php echo $effectifTotal; ?> total)</div></div>
    </div>
    <div class="stat-card green">
        <div class="stat-icon">✅</div>
        <div><div class="stat-value"><?php echo (int)$stats['presents']; ?></div><div class="stat-label">Présences sur <?php echo h($libellePeriode); ?></div></div>
    </div>
    <div class="stat-card yellow">
        <div class="stat-icon">⏰</div>
        <div><div class="stat-value"><?php echo (int)$stats['en_retard']; ?></div><div class="stat-label">En retard</div></div>
    </div>
    <div class="stat-card red">
        <div class="stat-icon">❌</div>
        <div><div class="stat-value"><?php echo (int)$stats['absents']; ?></div><div class="stat-label">Absents</div></div>
    </div>
    <div class="stat-card purple">
        <div class="stat-icon">🏖️</div>
        <div><div class="stat-value"><?php echo (int)$stats['conges']; ?></div><div class="stat-label">En congé</div></div>
    </div>
    <div class="stat-card gray">
        <div class="stat-icon">📭</div>
        <div><div class="stat-value"><?php echo $agentsNonPointes; ?></div><div class="stat-label">Agents non pointés</div></div>
    </div>
</div>

<div class="dashboard-grid">
    <div class="card chart-card">
        <div class="card-header"><h2><i class="bi bi-graph-up-arrow me-2"></i>Évolution des présences</h2><span class="badge badge-blue">Période sélectionnée</span></div>
        <div class="chart-wrap"><canvas id="attendanceTrend"></canvas></div>
    </div>
    <div class="card chart-card">
        <div class="card-header"><h2><i class="bi bi-pie-chart me-2"></i>Répartition de la période</h2></div>
        <div class="chart-wrap"><canvas id="attendanceSplit"></canvas></div>
    </div>
</div>

<script>
window.addEventListener('DOMContentLoaded', function () {
  const css = getComputedStyle(document.documentElement);
  const textColor = css.getPropertyValue('--muted').trim() || '#64748b';
  const gridColor = css.getPropertyValue('--border').trim() || '#e2e8f0';
  const trend = document.getElementById('attendanceTrend');
  if (trend && window.Chart) {
    new Chart(trend, {type:'line', data:{
      labels: <?php echo json_encode($chartLabels); ?>,
      datasets:[
        {label:'Présents',data:<?php echo json_encode($chartPresents); ?>,borderColor:'#22c55e',backgroundColor:'rgba(34,197,94,.12)',fill:true,tension:.35},
        {label:'Retards',data:<?php echo json_encode($chartRetards); ?>,borderColor:'#f59e0b',backgroundColor:'rgba(245,158,11,.08)',tension:.35},
        {label:'Absents',data:<?php echo json_encode($chartAbsents); ?>,borderColor:'#ef4444',backgroundColor:'rgba(239,68,68,.08)',tension:.35}
      ]}, options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{labels:{color:textColor,usePointStyle:true}}},scales:{x:{ticks:{color:textColor},grid:{display:false}},y:{beginAtZero:true,ticks:{color:textColor,precision:0},grid:{color:gridColor}}}}});
  }
  const split = document.getElementById('attendanceSplit');
  if (split && window.Chart) {
    new Chart(split,{type:'doughnut',data:{labels:['Présents','Absents','Congés','Missions'],datasets:[{
      data:[<?php echo (int)$stats['presents']; ?>,<?php echo (int)$stats['absents']; ?>,<?php echo (int)$stats['conges']; ?>,<?php echo (int)$stats['missions']; ?>],
      backgroundColor:['#22c55e','#ef4444','#8b5cf6','#3b82f6'],borderWidth:0,hoverOffset:5
    }]},options:{responsive:true,maintainAspectRatio:false,cutout:'68%',plugins:{legend:{position:'bottom',labels:{color:textColor,usePointStyle:true,padding:18}}}}});
  }
});
</script>

<div class="flex flex-wrap" style="align-items:flex-start">
    <!-- Retardataires du jour -->
    <div class="card" style="flex:2;min-width:320px">
        <div class="card-header">
            <h2>⏰ Top retardataires — <?php echo h($libellePeriode); ?></h2>
            <a href="retards.php" class="btn btn-sm btn-outline">Voir tout</a>
        </div>
        <?php if (empty($retardataires)): ?>
            <p class="text-muted text-center" style="padding:20px">Aucun retard enregistré pour cette date. 🎉</p>
        <?php else: ?>
            <div class="table-wrap">
                <table class="data-table">
                    <thead><tr><th>Agent</th><th>N°</th><th>Dernière arrivée</th><th>Retard cumulé</th><th>Tranche</th></tr></thead>
                    <tbody>
                    <?php foreach ($retardataires as $r): ?>
                        <tr>
                            <td><?php echo h($r['nom_complet'] ?: '—'); ?></td>
                            <td class="num"><?php echo h($r['numero_identification']); ?></td>
                            <td><?php echo formatHeure($r['premiere_entree']); ?></td>
                            <td class="text-danger"><b><?php echo (int)$r['retard_minutes']; ?> min</b><br><small><?php echo (int)$r['jours_retard']; ?> jour(s)</small></td>
                            <td><?php echo badgeTranche($r['tranche_retard']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <!-- Congés en cours -->
    <div class="card" style="flex:1;min-width:280px">
        <div class="card-header"><h2>🏖️ Congés en cours</h2></div>
        <?php if (empty($congesEnCours)): ?>
            <p class="text-muted text-center" style="padding:14px">Aucun congé en cours.</p>
        <?php else: ?>
            <table class="data-table" data-no-datatable="true">
                <tbody>
                <?php foreach ($congesEnCours as $c): ?>
                    <tr>
                        <td>
                            <div><b><?php echo h($c['nom_complet'] ?: '—'); ?></b></div>
                            <small class="text-muted"><?php echo h($c['type']); ?> · jusqu'au <?php echo formatDateFr($c['date_fin']); ?></small>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<div class="flex flex-wrap" style="align-items:flex-start;margin-top:20px">
    <!-- Anomalies -->
    <div class="card" style="flex:1;min-width:320px">
        <div class="card-header"><h2>⚠️ Sorties manquantes</h2></div>
        <?php if (empty($sortiesManquantes)): ?>
            <p class="text-muted text-center" style="padding:14px">Aucune anomalie de sortie.</p>
        <?php else: ?>
            <div class="table-wrap">
                <table class="data-table">
                    <thead><tr><th>Agent</th><th>N°</th><th>Arrivée</th></tr></thead>
                    <tbody>
                    <?php foreach ($sortiesManquantes as $s): ?>
                        <tr>
                            <td><?php echo h($s['nom_complet'] ?: '—'); ?></td>
                            <td class="num"><?php echo h($s['numero_identification']); ?></td>
                            <td><?php echo formatHeure($s['premiere_entree']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <!-- Derniers imports -->
    <div class="card" style="flex:1;min-width:280px">
        <div class="card-header">
            <h2>📥 Derniers imports</h2>
            <a href="presences.php" class="btn btn-sm btn-outline">Nouvel import</a>
        </div>
        <?php if (empty($imports)): ?>
            <p class="text-muted text-center" style="padding:14px">Aucun import effectué.</p>
        <?php else: ?>
            <table class="data-table" data-no-datatable="true">
                <tbody>
                <?php foreach ($imports as $imp): ?>
                    <tr>
                        <td>
                            <div><b><?php echo h($imp['nom_fichier']); ?></b></div>
                            <small class="text-muted">
                                <?php echo $imp['nb_acceptees']; ?> acceptées · <?php echo $imp['nb_doublons']; ?> doublons ·
                                <?php echo formatDateFr(substr($imp['date_import'],0,10)); ?>
                            </small>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/partials/footer.php'; ?>
