<?php
$pageTitle = 'Suivi des retards';
$activePage = 'retards.php';
require_once __DIR__ . '/helpers.php';

$pdo = db();

// ============================================================
//  DÉTAILS DES RETARDS D'UN AGENT (chargement AJAX)
// ============================================================
if (($_GET['ajax'] ?? '') === 'details_agent') {
    header('Content-Type: application/json; charset=UTF-8');
    if (!isset($_SESSION['user'])) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'message' => 'Session expirée. Veuillez vous reconnecter.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $numero = trim($_GET['numero'] ?? '');
    if ($numero === '') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'message' => 'Numéro d’agent manquant.'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $detailWhere = ['p.retard_minutes > 0', 'p.numero_identification = ?'];
    $detailParams = [$numero];
    $dateD = $_GET['date_debut'] ?? '';
    $dateF = $_GET['date_fin'] ?? '';
    $tranche = $_GET['tranche'] ?? '';
    $justifie = $_GET['justifie'] ?? '';

    if ($dateD !== '') { $detailWhere[] = 'p.date_presence >= ?'; $detailParams[] = $dateD; }
    if ($dateF !== '') { $detailWhere[] = 'p.date_presence <= ?'; $detailParams[] = $dateF; }
    if ($tranche !== '') { $detailWhere[] = 'p.tranche_retard = ?'; $detailParams[] = $tranche; }
    if ($justifie === '1') $detailWhere[] = "p.motif_correction IS NOT NULL AND p.motif_correction <> ''";
    if ($justifie === '0') $detailWhere[] = "(p.motif_correction IS NULL OR p.motif_correction = '')";

    $sqlDetail = "SELECT p.id, p.date_presence, p.premiere_entree, p.horaire_applique,
                         p.retard_minutes, p.tranche_retard, p.motif_correction,
                         a.nom_complet, a.service, a.site
                  FROM presence_journaliere p
                  JOIN agents a ON a.numero_identification = p.numero_identification
                  WHERE " . implode(' AND ', $detailWhere) . "
                  ORDER BY p.date_presence DESC, p.retard_minutes DESC";
    $stmtDetail = $pdo->prepare($sqlDetail);
    $stmtDetail->execute($detailParams);
    $details = $stmtDetail->fetchAll();

    $totalMinutes = 0;
    foreach ($details as &$detail) {
        $detail['retard_minutes'] = (int)$detail['retard_minutes'];
        $totalMinutes += $detail['retard_minutes'];
        $detail['date_fr'] = formatDateFr($detail['date_presence']);
        $detail['heure_fr'] = formatHeure($detail['premiere_entree']);
    }
    unset($detail);

    echo json_encode([
        'ok' => true,
        'agent' => [
            'numero' => $numero,
            'nom' => $details[0]['nom_complet'] ?? $numero,
            'service' => $details[0]['service'] ?? '',
            'site' => $details[0]['site'] ?? '',
        ],
        'resume' => [
            'nombre' => count($details),
            'total_minutes' => $totalMinutes,
            'moyenne_minutes' => count($details) ? (int)round($totalMinutes / count($details)) : 0,
        ],
        'details' => $details,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// ============================================================
//  TRAITEMENT : justification d'un retard
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'justifier') {
    exigerPermission('retards.manage','retards.php');
    $id = (int)$_POST['id'];
    $motif = trim($_POST['motif'] ?? '');
    if ($motif === '') {
        flash('error', 'Le motif est obligatoire (RG-08).');
        redirect('retards.php');
    }
    $old = $pdo->prepare("SELECT * FROM presence_journaliere WHERE id=?");
    $old->execute([$id]);
    $oldRow = $old->fetch();
    if ($oldRow) {
        $pdo->prepare("UPDATE presence_journaliere SET motif_correction=?, saisie_manuelle=1 WHERE id=?")
            ->execute([$motif, $id]);
        logAudit('justify', 'retard', $id, $oldRow, ['motif' => $motif]);
        flash('success', 'Retard justifié enregistré.');
    }
    redirect('retards.php');
}

// ============================================================
//  FILTRES
// ============================================================
$fDateD = $_GET['date_debut'] ?? '';
$fDateF = $_GET['date_fin']   ?? '';
$fNum   = trim($_GET['numero'] ?? '');
$fNom   = trim($_GET['nom'] ?? '');
$fServ  = trim($_GET['service'] ?? '');
$fTranche = $_GET['tranche'] ?? '';
$fJustif  = $_GET['justifie'] ?? '';

if ($fDateD === '' && $fDateF === '') {
    $periode = $pdo->query("SELECT MIN(date_presence) d1, MAX(date_presence) d2 FROM presence_journaliere")->fetch();
    if ($periode['d1']) { $fDateD = $periode['d1']; $fDateF = $periode['d2']; }
}

$where = ["p.retard_minutes > 0"]; $params = [];
if ($fDateD) { $where[] = "p.date_presence>=?"; $params[] = $fDateD; }
if ($fDateF) { $where[] = "p.date_presence<=?"; $params[] = $fDateF; }
if ($fNum)   { $where[] = "p.numero_identification LIKE ?"; $params[] = "%$fNum%"; }
if ($fNom)   { $where[] = "a.nom_complet LIKE ?"; $params[] = "%$fNom%"; }
if ($fServ)  { $where[] = "a.service LIKE ?"; $params[] = "%$fServ%"; }
if ($fTranche) { $where[] = "p.tranche_retard=?"; $params[] = $fTranche; }
if ($fJustif === '1')   { $where[] = "p.motif_correction IS NOT NULL AND p.motif_correction<>''"; }
if ($fJustif === '0')   { $where[] = "(p.motif_correction IS NULL OR p.motif_correction='')"; }
$whereSql = 'WHERE ' . implode(' AND ', $where);

include __DIR__ . '/partials/layout.php';

// ===== STATS GLOBALES (sur la période filtrée) =====
$statStmt = $pdo->prepare("SELECT
    COUNT(*) AS nb_retards,
    SUM(p.retard_minutes) AS total_minutes,
    COUNT(DISTINCT p.numero_identification) AS nb_agents
    FROM presence_journaliere p JOIN agents a ON a.numero_identification=p.numero_identification
    $whereSql");
$statStmt->execute($params);
$gStats = $statStmt->fetch();

$tranchesStats = $pdo->prepare("SELECT p.tranche_retard, COUNT(*) AS nb
    FROM presence_journaliere p JOIN agents a ON a.numero_identification=p.numero_identification
    $whereSql GROUP BY p.tranche_retard");
$tranchesStats->execute($params);
$trCounts = [];
foreach ($tranchesStats as $t) $trCounts[$t['tranche_retard']] = (int)$t['nb'];
?>

<div class="stat-grid">
    <div class="stat-card red"><div class="stat-icon">⏰</div><div><div class="stat-value"><?php echo (int)$gStats['nb_retards']; ?></div><div class="stat-label">Retards (période)</div></div></div>
    <div class="stat-card orange"><div class="stat-icon">⏱️</div><div><div class="stat-value"><?php echo (int)$gStats['total_minutes']; ?> min</div><div class="stat-label">Cumul minutes</div></div></div>
    <div class="stat-card yellow"><div class="stat-icon">👤</div><div><div class="stat-value"><?php echo (int)$gStats['nb_agents']; ?></div><div class="stat-label">Agents concernés</div></div></div>
    <div class="stat-card purple"><div class="stat-icon">📊</div><div>
        <div class="stat-value" style="font-size:18px"><?php echo badgeTranche('léger'); ?> <?php echo $trCounts['léger']??0; ?> · <?php echo badgeTranche('moyen'); ?> <?php echo $trCounts['moyen']??0; ?> · <?php echo badgeTranche('grave'); ?> <?php echo $trCounts['grave']??0; ?></div>
        <div class="stat-label">Répartition par tranche</div>
    </div></div>
</div>

<div class="filters">
    <form method="get">
        <div class="form-group"><label>Du</label><input type="date" name="date_debut" value="<?php echo h($fDateD); ?>"></div>
        <div class="form-group"><label>Au</label><input type="date" name="date_fin" value="<?php echo h($fDateF); ?>"></div>
        <div class="form-group"><label>N° / Matricule</label><input type="search" name="numero" value="<?php echo h($fNum); ?>"></div>
        <div class="form-group"><label>Nom</label><input type="search" name="nom" value="<?php echo h($fNom); ?>"></div>
        <div class="form-group"><label>Service</label><input type="search" name="service" value="<?php echo h($fServ); ?>"></div>
        <div class="form-group">
            <label>Tranche</label>
            <select name="tranche"><option value="">Toutes</option>
                <option value="léger" <?php echo $fTranche==='léger'?'selected':''; ?>>Léger</option>
                <option value="moyen" <?php echo $fTranche==='moyen'?'selected':''; ?>>Moyen</option>
                <option value="grave" <?php echo $fTranche==='grave'?'selected':''; ?>>Grave</option>
            </select>
        </div>
        <div class="form-group">
            <label>Justification</label>
            <select name="justifie"><option value="">Tous</option>
                <option value="0" <?php echo $fJustif==='0'?'selected':''; ?>>Non justifiés</option>
                <option value="1" <?php echo $fJustif==='1'?'selected':''; ?>>Justifiés</option>
            </select>
        </div>
        <div class="form-group" style="flex:0">
            <button type="submit" class="btn">🔎 Filtrer</button>
            <a href="retards.php" class="btn btn-outline btn-sm">Reset</a>
        </div>
    </form>
</div>

<!-- Classement des agents par minutes de retard cumulées -->
<div class="card">
    <div class="card-header"><h2>🏆 Classement des agents (minutes cumulées)</h2></div>
    <div class="table-wrap">
        <table class="data-table">
            <thead><tr><th>#</th><th>N°</th><th>Agent</th><th>Service</th><th>Nb retards</th><th>Minutes cumulées</th><th>Retard moyen</th></tr></thead>
            <tbody>
            <?php
            $classement = $pdo->prepare("SELECT p.numero_identification, a.nom_complet, a.service,
                COUNT(*) AS nb, SUM(p.retard_minutes) AS total
                FROM presence_journaliere p JOIN agents a ON a.numero_identification=p.numero_identification
                $whereSql
                GROUP BY p.numero_identification, a.nom_complet, a.service
                ORDER BY total DESC LIMIT 15");
            $classement->execute($params);
            $rows = $classement->fetchAll();
            if (empty($rows)) echo '<tr class="empty-row"><td colspan="7">Aucun retard sur cette période.</td></tr>';
            foreach ($rows as $i => $r):
            ?>
                <tr class="retard-ranking-row" data-agent-numero="<?php echo h($r['numero_identification']); ?>" tabindex="0" role="button" aria-label="Afficher le détail des retards de <?php echo h($r['nom_complet'] ?: $r['numero_identification']); ?>" title="Cliquer pour afficher le détail des retards">
                    <td><b><?php echo $i + 1; ?></b></td>
                    <td class="num"><?php echo h($r['numero_identification']); ?></td>
                    <td><?php echo h($r['nom_complet'] ?: '—'); ?></td>
                    <td><?php echo h($r['service'] ?: '—'); ?></td>
                    <td><?php echo (int)$r['nb']; ?></td>
                    <td class="text-danger"><b><?php echo (int)$r['total']; ?> min</b></td>
                    <td><?php echo round($r['total'] / $r['nb']); ?> min</td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<p class="text-muted" style="margin:-8px 0 18px 4px">💡 Cliquez sur une ligne du classement pour consulter toutes les dates et le détail des retards de l’agent.</p>

<!-- Détail des retards -->
<?php
$parPage = 30;
$page = max(1, (int)($_GET['page'] ?? 1));
$c = $pdo->prepare("SELECT COUNT(*) FROM presence_journaliere p JOIN agents a ON a.numero_identification=p.numero_identification $whereSql");
$c->execute($params);
$total = (int)$c->fetchColumn();
$nbPages = max(1, ceil($total / $parPage));
$offset = ($page - 1) * $parPage;

$stmt = $pdo->prepare("SELECT p.*, a.nom_complet, a.service
    FROM presence_journaliere p JOIN agents a ON a.numero_identification=p.numero_identification
    $whereSql
    ORDER BY p.date_presence DESC, p.retard_minutes DESC
    LIMIT $parPage OFFSET $offset");
$stmt->execute($params);
$retards = $stmt->fetchAll();
?>
<div class="card">
    <div class="card-header">
        <h2>Détail des retards <span class="text-muted">(<?php echo $total; ?>)</span></h2>
        <a href="rapports.php?type=retards&<?php echo http_build_query(array_intersect_key($_GET, array_flip(['date_debut','date_fin','numero','nom','service','tranche','justifie']))); ?>" class="btn btn-sm btn-outline">📊 Exporter</a>
    </div>
    <div class="table-wrap">
        <table class="data-table">
            <thead><tr><th>Date</th><th>N°</th><th>Agent</th><th>Service</th><th>Arrivée</th><th>Horaire</th><th>Retard</th><th>Tranche</th><th>Justification</th><th class="actions">Action</th></tr></thead>
            <tbody>
            <?php if (empty($retards)): ?>
                <tr class="empty-row"><td colspan="10">Aucun retard sur cette période.</td></tr>
            <?php else: foreach ($retards as $r): ?>
                <tr>
                    <td><?php echo formatDateFr($r['date_presence']); ?></td>
                    <td class="num"><?php echo h($r['numero_identification']); ?></td>
                    <td><?php echo h($r['nom_complet'] ?: '—'); ?></td>
                    <td><?php echo h($r['service'] ?: '—'); ?></td>
                    <td><?php echo formatHeure($r['premiere_entree']); ?></td>
                    <td><small><?php echo h($r['horaire_applique']); ?></small></td>
                    <td class="text-danger"><b><?php echo (int)$r['retard_minutes']; ?> min</b></td>
                    <td><?php echo badgeTranche($r['tranche_retard']); ?></td>
                    <td>
                        <?php if (!empty($r['motif_correction'])): ?>
                            <span class="badge badge-blue">Justifié</span>
                            <small><?php echo h($r['motif_correction']); ?></small>
                        <?php else: ?>
                            <span class="badge badge-gray">—</span>
                        <?php endif; ?>
                    </td>
                    <td class="actions">
                        <?php if (aPermission('retards.manage')): ?>
                            <a href="#" onclick="justifierRetard(<?php echo (int)$r['id']; ?>, '<?php echo h(addslashes($r['nom_complet'] ?: $r['numero_identification'])); ?>', <?php echo (int)$r['retard_minutes']; ?>);return false" title="Justifier">📝</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
    <?php if ($nbPages > 1): ?>
        <div class="pagination">
            <?php if ($page > 1): ?><a href="?<?php echo http_build_query(array_merge($_GET,['page'=>$page-1])); ?>">« Préc.</a><?php endif; ?>
            <?php for ($i = max(1,$page-4); $i <= min($nbPages,$page+4); $i++): ?>
                <?php if ($i == $page): ?><span class="current"><?php echo $i; ?></span>
                <?php else: ?><a href="?<?php echo http_build_query(array_merge($_GET,['page'=>$i])); ?>"><?php echo $i; ?></a><?php endif; ?>
            <?php endfor; ?>
            <?php if ($page < $nbPages): ?><a href="?<?php echo http_build_query(array_merge($_GET,['page'=>$page+1])); ?>">Suiv. »</a><?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<!-- Modal de détail d'un agent -->
<div id="retardDetailModal" class="retard-detail-backdrop" style="display:none" aria-hidden="true">
    <div class="retard-detail-dialog" role="dialog" aria-modal="true" aria-labelledby="retardDetailTitle">
        <div class="retard-detail-header">
            <div>
                <h2 id="retardDetailTitle">⏰ Détail des retards</h2>
                <p id="retardDetailSubtitle" class="text-muted" style="margin:4px 0 0"></p>
            </div>
            <button type="button" class="retard-detail-close" id="retardDetailClose" aria-label="Fermer">×</button>
        </div>
        <div id="retardDetailLoading" class="retard-detail-loading">Chargement des retards…</div>
        <div id="retardDetailContent" style="display:none">
            <div class="retard-detail-stats">
                <div><strong id="detailNbRetards">0</strong><span>Nombre de retards</span></div>
                <div><strong id="detailTotalMinutes">0 min</strong><span>Minutes cumulées</span></div>
                <div><strong id="detailMoyenneMinutes">0 min</strong><span>Retard moyen</span></div>
            </div>
            <div class="retard-detail-search">
                <input type="search" id="retardDetailSearch" placeholder="Rechercher dans les détails…" aria-label="Rechercher dans les détails des retards">
            </div>
            <div class="table-wrap retard-detail-table-wrap">
                <table class="data-table" id="retardDetailTable">
                    <thead>
                        <tr><th>N°</th><th>Date</th><th>Arrivée</th><th>Horaire</th><th>Retard</th><th>Tranche</th><th>Justification</th></tr>
                    </thead>
                    <tbody id="retardDetailBody"></tbody>
                </table>
            </div>
        </div>
        <div id="retardDetailError" class="alert alert-error" style="display:none"></div>
        <div class="retard-detail-footer">
            <button type="button" class="btn btn-secondary" id="retardDetailCloseBottom">Fermer</button>
        </div>
    </div>
</div>

<style>
.retard-ranking-row{cursor:pointer;transition:background-color .15s ease,transform .15s ease}
.retard-ranking-row:hover,.retard-ranking-row:focus{background:rgba(40,120,255,.10)!important;outline:2px solid rgba(40,120,255,.35);outline-offset:-2px}
.retard-detail-backdrop{position:fixed;inset:0;z-index:10000;background:rgba(2,8,23,.76);align-items:center;justify-content:center;padding:18px}
.retard-detail-dialog{width:min(1180px,96vw);max-height:92vh;overflow:hidden;background:var(--c-card,#101827);border:1px solid rgba(148,163,184,.28);border-radius:18px;box-shadow:0 24px 80px rgba(0,0,0,.5);display:flex;flex-direction:column}
.retard-detail-header,.retard-detail-footer{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:18px 22px;border-bottom:1px solid rgba(148,163,184,.24)}
.retard-detail-footer{border-top:1px solid rgba(148,163,184,.24);border-bottom:0;justify-content:flex-end}
.retard-detail-header h2{margin:0}.retard-detail-close{border:0;background:transparent;color:inherit;font-size:34px;line-height:1;cursor:pointer;padding:0 6px}
.retard-detail-loading{padding:42px;text-align:center}.retard-detail-stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;padding:18px 22px 8px}
.retard-detail-stats>div{padding:14px;border:1px solid rgba(148,163,184,.22);border-radius:12px;background:rgba(30,64,175,.08)}
.retard-detail-stats strong{display:block;font-size:24px;color:#3b82f6}.retard-detail-stats span{display:block;margin-top:4px;font-size:13px;color:var(--c-muted,#94a3b8)}
.retard-detail-search{padding:10px 22px}.retard-detail-search input{width:100%}.retard-detail-table-wrap{margin:0 22px 18px;max-height:48vh;overflow:auto}
#retardDetailError{margin:20px 22px}
@media(max-width:700px){.retard-detail-stats{grid-template-columns:1fr}.retard-detail-dialog{max-height:96vh}.retard-detail-header{padding:14px}.retard-detail-table-wrap{margin:0 12px 12px}.retard-detail-search{padding:8px 12px}}
@media print{#retardDetailModal{display:none!important}}
</style>

<!-- Modal de justification -->
<div id="justifModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:200;align-items:center;justify-content:center">
    <div class="card" style="max-width:480px;margin:20px">
        <div class="card-header"><h2>📝 Justifier un retard</h2></div>
        <p><b>Agent :</b> <span id="jAgent"></span></p>
        <p><b>Retard :</b> <span id="jRetard"></span> minutes</p>
        <form method="post" action="retards.php">
            <input type="hidden" name="action" value="justifier">
            <input type="hidden" name="id" id="jId">
            <div class="form-group">
                <label>Motif de justification *</label>
                <textarea name="motif" rows="3" required placeholder="Ex : panne de véhicule, mission autorisée..."></textarea>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn btn-success">Valider</button>
                <button type="button" class="btn btn-secondary" onclick="document.getElementById('justifModal').style.display='none'">Annuler</button>
            </div>
        </form>
    </div>
</div>
<script>
function escapeRetardHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>'"]/g, function (char) {
        return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[char];
    });
}

(function () {
    var modal = document.getElementById('retardDetailModal');
    var content = document.getElementById('retardDetailContent');
    var loading = document.getElementById('retardDetailLoading');
    var errorBox = document.getElementById('retardDetailError');
    var body = document.getElementById('retardDetailBody');
    var search = document.getElementById('retardDetailSearch');
    var currentRows = [];

    function closeModal() {
        modal.style.display = 'none';
        modal.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
    }

    function renderRows(rows) {
        var term = (search.value || '').toLocaleLowerCase('fr');
        var filtered = rows.filter(function (row) {
            return !term || [row.date_fr, row.heure_fr, row.horaire_applique, row.retard_minutes, row.tranche_retard, row.motif_correction]
                .join(' ').toLocaleLowerCase('fr').indexOf(term) !== -1;
        });
        if (!filtered.length) {
            body.innerHTML = '<tr class="empty-row"><td colspan="7">Aucun retard ne correspond à la recherche.</td></tr>';
            return;
        }
        body.innerHTML = filtered.map(function (row, index) {
            var justification = row.motif_correction
                ? '<span class="badge badge-blue">Justifié</span><br><small>' + escapeRetardHtml(row.motif_correction) + '</small>'
                : '<span class="badge badge-gray">Non justifié</span>';
            return '<tr>' +
                '<td><b>' + (index + 1) + '</b></td>' +
                '<td>' + escapeRetardHtml(row.date_fr) + '</td>' +
                '<td>' + escapeRetardHtml(row.heure_fr || '—') + '</td>' +
                '<td><small>' + escapeRetardHtml(row.horaire_applique || '—') + '</small></td>' +
                '<td class="text-danger"><b>' + Number(row.retard_minutes || 0) + ' min</b></td>' +
                '<td><span class="badge badge-' + (row.tranche_retard === 'grave' ? 'red' : (row.tranche_retard === 'moyen' ? 'orange' : 'yellow')) + '">' + escapeRetardHtml(row.tranche_retard || '—') + '</span></td>' +
                '<td>' + justification + '</td>' +
                '</tr>';
        }).join('');
    }

    function openDetails(numero) {
        modal.style.display = 'flex';
        modal.setAttribute('aria-hidden', 'false');
        document.body.style.overflow = 'hidden';
        loading.style.display = 'block';
        content.style.display = 'none';
        errorBox.style.display = 'none';
        search.value = '';

        var query = new URLSearchParams({
            ajax: 'details_agent',
            numero: numero,
            date_debut: <?php echo json_encode($fDateD, JSON_UNESCAPED_UNICODE); ?>,
            date_fin: <?php echo json_encode($fDateF, JSON_UNESCAPED_UNICODE); ?>,
            tranche: <?php echo json_encode($fTranche, JSON_UNESCAPED_UNICODE); ?>,
            justifie: <?php echo json_encode($fJustif, JSON_UNESCAPED_UNICODE); ?>
        });

        fetch('retards.php?' + query.toString(), {headers: {'X-Requested-With': 'XMLHttpRequest'}})
            .then(function (response) {
                if (!response.ok) throw new Error('Impossible de charger le détail.');
                return response.json();
            })
            .then(function (data) {
                if (!data.ok) throw new Error(data.message || 'Impossible de charger le détail.');
                currentRows = data.details || [];
                document.getElementById('retardDetailTitle').textContent = '⏰ Détail des retards — ' + (data.agent.nom || data.agent.numero);
                document.getElementById('retardDetailSubtitle').textContent = [data.agent.numero, data.agent.service, data.agent.site].filter(Boolean).join(' · ');
                document.getElementById('detailNbRetards').textContent = data.resume.nombre;
                document.getElementById('detailTotalMinutes').textContent = data.resume.total_minutes + ' min';
                document.getElementById('detailMoyenneMinutes').textContent = data.resume.moyenne_minutes + ' min';
                renderRows(currentRows);
                loading.style.display = 'none';
                content.style.display = 'block';
                search.focus();
            })
            .catch(function (error) {
                loading.style.display = 'none';
                errorBox.textContent = error.message;
                errorBox.style.display = 'block';
            });
    }

    document.addEventListener('click', function (event) {
        var row = event.target.closest('.retard-ranking-row');
        if (row && !event.target.closest('a,button,input,select,textarea,label')) {
            openDetails(row.getAttribute('data-agent-numero'));
        }
    });
    document.addEventListener('keydown', function (event) {
        var row = event.target.closest && event.target.closest('.retard-ranking-row');
        if (row && (event.key === 'Enter' || event.key === ' ')) {
            event.preventDefault();
            openDetails(row.getAttribute('data-agent-numero'));
        } else if (event.key === 'Escape' && modal.style.display !== 'none') {
            closeModal();
        }
    });
    search.addEventListener('input', function () { renderRows(currentRows); });
    document.getElementById('retardDetailClose').addEventListener('click', closeModal);
    document.getElementById('retardDetailCloseBottom').addEventListener('click', closeModal);
    modal.addEventListener('click', function (event) { if (event.target === modal) closeModal(); });
})();

function justifierRetard(id, agent, retard) {
    document.getElementById('jId').value = id;
    document.getElementById('jAgent').textContent = agent;
    document.getElementById('jRetard').textContent = retard;
    var m = document.getElementById('justifModal');
    m.style.display = 'flex';
}
</script>

<?php include __DIR__ . '/partials/footer.php'; ?>
