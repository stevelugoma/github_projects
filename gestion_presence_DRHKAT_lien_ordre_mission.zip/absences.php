<?php
$pageTitle = 'Absences';
$activePage = 'absences.php';
require_once __DIR__ . '/helpers.php';

$pdo = db();

// ============================================================
//  TRAITEMENT
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    exigerPermission('absences.manage','absences.php');
    $action = $_POST['action'] ?? '';

    if ($action === 'save') {
        $numId = trim($_POST['numero_identification'] ?? '');
        $data = [
            'numero_identification' => $numId,
            'date_debut' => $_POST['date_debut'] ?? null,
            'date_fin'   => $_POST['date_fin'] ?? null,
            'type'       => $_POST['type'] ?? 'injustifiee',
            'motif'      => trim($_POST['motif'] ?? ''),
            'statut'     => $_POST['statut'] ?? 'en_attente',
        ];
        if (!$numId || !$data['date_debut'] || !$data['date_fin']) {
            flash('error', 'Agent, date de début et date de fin sont obligatoires.');
        } else {
            $id = (int)($_POST['id'] ?? 0);
            if ($id) {
                $old = $pdo->prepare("SELECT * FROM absence WHERE id=?"); $old->execute([$id]); $oldRow=$old->fetch();
                $stmt = $pdo->prepare("UPDATE absence SET numero_identification=?,date_debut=?,date_fin=?,type=?,motif=?,statut=? WHERE id=?");
                $data['id'] = $id;
                $stmt->execute([$data['numero_identification'],$data['date_debut'],$data['date_fin'],$data['type'],$data['motif'],$data['statut'],$id]);
                logAudit('update','absence',$id,$oldRow,$data);
                flash('success','Absence modifiée.');
            } else {
                $stmt = $pdo->prepare("INSERT INTO absence (numero_identification,date_debut,date_fin,type,motif,statut) VALUES (?,?,?,?,?,?)");
                $stmt->execute([$data['numero_identification'],$data['date_debut'],$data['date_fin'],$data['type'],$data['motif'],$data['statut']]);
                $newId = (int)$pdo->lastInsertId();
                logAudit('create','absence',$newId,null,$data);
                flash('success','Absence enregistrée.');
            }
        }
        redirect('absences.php');
    }
    if ($action === 'valider') {
        $id = (int)$_POST['id'];
        $statut = $_POST['statut'];
        $pdo->prepare("UPDATE absence SET statut=?, valide_par=?, date_validation=NOW() WHERE id=?")
            ->execute([$statut, $_SESSION['user']['id'] ?? null, $id]);
        logAudit('validate','absence',$id,null,$statut);
        flash('success', $statut === 'validee' ? 'Absence validée.' : 'Absence rejetée.');
        redirect('absences.php');
    }
    if ($action === 'delete') {
        $id = (int)$_POST['id'];
        $pdo->prepare("DELETE FROM absence WHERE id=?")->execute([$id]);
        logAudit('delete','absence',$id);
        flash('success','Absence supprimée.');
        redirect('absences.php');
    }
}
if (($_GET['action'] ?? '') === 'delete') {
    exigerPermission('absences.manage','absences.php');
    $pdo->prepare("DELETE FROM absence WHERE id=?")->execute([(int)$_GET['id']]);
    logAudit('delete','absence',(int)$_GET['id']);
    flash('success','Absence supprimée.');
    redirect('absences.php');
}

$editId = ($_GET['action'] ?? '') === 'edit' ? (int)($_GET['id'] ?? 0) : 0;
$editAbs = null;
if ($editId) {
    $editAbs = $pdo->prepare("SELECT * FROM absence WHERE id=?");
    $editAbs->execute([$editId]);
    $editAbs = $editAbs->fetch();
}

// liste agents pour le select
$agents = $pdo->query("SELECT numero_identification, nom_complet FROM agents WHERE statut=1 ORDER BY nom_complet")->fetchAll();

// ---- FILTRES ----
$fDateD = $_GET['date_debut'] ?? '';
$fDateF = $_GET['date_fin'] ?? '';
$fNum   = trim($_GET['numero'] ?? '');
$fServ  = trim($_GET['service'] ?? '');
$fType  = $_GET['type'] ?? '';
$fStatut= $_GET['statut'] ?? '';

$where = []; $params = [];
if ($fDateD) { $where[] = "ab.date_fin>=?"; $params[] = $fDateD; }
if ($fDateF) { $where[] = "ab.date_debut<=?"; $params[] = $fDateF; }
if ($fNum)   { $where[] = "ab.numero_identification LIKE ?"; $params[] = "%$fNum%"; }
if ($fServ)  { $where[] = "a.service LIKE ?"; $params[] = "%$fServ%"; }
if ($fType)  { $where[] = "ab.type=?"; $params[] = $fType; }
if ($fStatut){ $where[] = "ab.statut=?"; $params[] = $fStatut; }
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

include __DIR__ . '/partials/layout.php';
?>

<!-- Formulaire ajout/édition -->
<div class="card">
    <div class="card-header"><h2><?php echo $editAbs ? '✏️ Modifier l\'absence' : '➕ Enregistrer une absence'; ?></h2></div>
    <form method="post" action="absences.php">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?php echo (int)($editAbs['id'] ?? 0); ?>">
        <div class="form-grid">
            <div class="form-group">
                <label>Agent *</label>
                <select name="numero_identification" required>
                    <option value="">— Sélectionner —</option>
                    <?php foreach ($agents as $ag): ?>
                        <option value="<?php echo h($ag['numero_identification']); ?>" <?php echo ($editAbs['numero_identification']??'')===$ag['numero_identification']?'selected':''; ?>>
                            <?php echo h($ag['numero_identification'] . ' — ' . ($ag['nom_complet'] ?: 'sans nom')); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Date début *</label>
                <input type="date" name="date_debut" required value="<?php echo h($editAbs['date_debut'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>Date fin *</label>
                <input type="date" name="date_fin" required value="<?php echo h($editAbs['date_fin'] ?? ''); ?>">
            </div>
            <div class="form-group">
                <label>Type</label>
                <select name="type">
                    <?php foreach (['injustifiee'=>'Injustifiée','justifiee'=>'Justifiée','maladie'=>'Maladie','autorisation'=>'Autorisation','mission'=>'Mission','autre'=>'Autre'] as $k=>$v): ?>
                        <option value="<?php echo $k; ?>" <?php echo ($editAbs['type']??'')===$k?'selected':''; ?>><?php echo $v; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Statut</label>
                <select name="statut">
                    <?php foreach (['en_attente'=>'En attente','validee'=>'Validée','rejetee'=>'Rejetée'] as $k=>$v): ?>
                        <option value="<?php echo $k; ?>" <?php echo ($editAbs['statut']??'en_attent')===$k?'selected':''; ?>><?php echo $v; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group" style="grid-column:1/-1">
                <label>Motif</label>
                <textarea name="motif" rows="2" placeholder="Motif de l'absence..."><?php echo h($editAbs['motif'] ?? ''); ?></textarea>
            </div>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-success">💾 Enregistrer</button>
            <?php if ($editAbs): ?><a href="absences.php" class="btn btn-secondary">Annuler</a><?php endif; ?>
        </div>
    </form>
</div>

<div class="filters">
    <form method="get">
        <div class="form-group"><label>Du</label><input type="date" name="date_debut" value="<?php echo h($fDateD); ?>"></div>
        <div class="form-group"><label>Au</label><input type="date" name="date_fin" value="<?php echo h($fDateF); ?>"></div>
        <div class="form-group"><label>N° / Matricule</label><input type="search" name="numero" value="<?php echo h($fNum); ?>"></div>
        <div class="form-group"><label>Service</label><input type="search" name="service" value="<?php echo h($fServ); ?>"></div>
        <div class="form-group">
            <label>Type</label>
            <select name="type"><option value="">Tous</option>
                <?php foreach (['injustifiee'=>'Injustifiée','justifiee'=>'Justifiée','maladie'=>'Maladie','autorisation'=>'Autorisation','mission'=>'Mission'] as $k=>$v): ?>
                    <option value="<?php echo $k; ?>" <?php echo $fType===$k?'selected':''; ?>><?php echo $v; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Statut</label>
            <select name="statut"><option value="">Tous</option>
                <?php foreach (['en_attente'=>'En attente','validee'=>'Validée','rejetee'=>'Rejetée'] as $k=>$v): ?>
                    <option value="<?php echo $k; ?>" <?php echo $fStatut===$k?'selected':''; ?>><?php echo $v; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group" style="flex:0"><button type="submit" class="btn">🔎 Filtrer</button><a href="absences.php" class="btn btn-outline btn-sm">Reset</a></div>
    </form>
</div>

<?php
$stmt = $pdo->prepare("SELECT ab.*, a.nom_complet, a.service
    FROM absence ab JOIN agents a ON a.numero_identification=ab.numero_identification
    $whereSql ORDER BY ab.date_debut DESC, a.nom_complet");
$stmt->execute($params);
$absences = $stmt->fetchAll();
?>
<div class="card">
    <div class="card-header">
        <h2>Liste des absences <span class="text-muted">(<?php echo count($absences); ?>)</span></h2>
        <a href="rapports.php?type=absences&<?php echo http_build_query(array_intersect_key($_GET, array_flip(['date_debut','date_fin','numero','service','type','statut']))); ?>" class="btn btn-sm btn-outline">📊 Exporter</a>
    </div>
    <div class="table-wrap">
        <table class="data-table">
            <thead><tr><th>N°</th><th>Agent</th><th>Service</th><th>Du</th><th>Au</th><th>Type</th><th>Motif</th><th>Statut</th><th class="actions">Actions</th></tr></thead>
            <tbody>
            <?php if (empty($absences)): ?>
                <tr class="empty-row"><td colspan="9">Aucune absence enregistrée.</td></tr>
            <?php else: foreach ($absences as $ab):
                $typeLabels = ['injustifiee'=>'badge-red','justifiee'=>'badge-yellow','maladie'=>'badge-purple','autorisation'=>'badge-blue','mission'=>'badge-purple','autre'=>'badge-gray'];
                $typeText = ['injustifiee'=>'Injustifiée','justifiee'=>'Justifiée','maladie'=>'Maladie','autorisation'=>'Autorisation','mission'=>'Mission','autre'=>'Autre'];
                $statutBadge = ['en_attente'=>'badge-yellow','validee'=>'badge-green','rejetee'=>'badge-red'];
                $statutText = ['en_attente'=>'En attente','validee'=>'Validée','rejetee'=>'Rejetée'];
            ?>
                <tr>
                    <td class="num"><?php echo h($ab['numero_identification']); ?></td>
                    <td><?php echo h($ab['nom_complet'] ?: '—'); ?></td>
                    <td><?php echo h($ab['service'] ?: '—'); ?></td>
                    <td><?php echo formatDateFr($ab['date_debut']); ?></td>
                    <td><?php echo formatDateFr($ab['date_fin']); ?></td>
                    <td><span class="badge <?php echo $typeBadge ?? $typeLabels[$ab['type']] ?? 'badge-gray'; ?>"><?php echo $typeText[$ab['type']] ?? $ab['type']; ?></span></td>
                    <td><small><?php echo h($ab['motif'] ?: '—'); ?></small></td>
                    <td><span class="badge <?php echo $statutBadge[$ab['statut']] ?? 'badge-gray'; ?>"><?php echo $statutText[$ab['statut']] ?? $ab['statut']; ?></span></td>
                    <td class="actions">
                        <?php if (aPermission('absences.manage')): ?>
                            <?php if ($ab['statut']==='en_attente'): ?>
                                <form method="post" style="display:inline">
                                    <input type="hidden" name="action" value="valider">
                                    <input type="hidden" name="id" value="<?php echo (int)$ab['id']; ?>">
                                    <input type="hidden" name="statut" value="validee">
                                    <button type="submit" title="Valider" class="btn-link">✅</button>
                                </form>
                                <form method="post" style="display:inline">
                                    <input type="hidden" name="action" value="valider">
                                    <input type="hidden" name="id" value="<?php echo (int)$ab['id']; ?>">
                                    <input type="hidden" name="statut" value="rejetee">
                                    <button type="submit" title="Rejeter" class="btn-link">❌</button>
                                </form>
                            <?php endif; ?>
                            <a href="absences.php?action=edit&id=<?php echo (int)$ab['id']; ?>" title="Modifier">✏️</a>
                            <a href="absences.php?action=delete&id=<?php echo (int)$ab['id']; ?>" title="Supprimer" onclick="return confirm('Supprimer cette absence ?')">🗑️</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/partials/footer.php'; ?>
