GESTION PROFESSIONNELLE DES PRÉSENCES — WAMPSERVER

INSTALLATION
1. Copier le dossier dans C:\wamp64\www\gestion_presence_entreprise
2. Vérifier les accès MySQL dans config.php
3. Ouvrir http://localhost/gestion_presence_entreprise/install.php
4. Se connecter avec admin / admin123 puis changer le mot de passe.

MISES À JOUR PRINCIPALES
- Interface Bootstrap 5, thème sombre, icônes, graphiques et tableaux interactifs.
- Listes Agents et Présences chargées entièrement avec « Tous » par défaut.
- Import et réimport Excel en mode synchronisation : ajout des données manquantes et mise à jour des données modifiées.
- Tableau de bord avec intervalle Date de début / Date de fin.
- Heures d’allaitement : création, modification, période, durée, modalité et recalcul automatique des présences.

Pour une base déjà installée, la page horaires.php ajoute automatiquement les colonnes nécessaires aux heures d’allaitement.
