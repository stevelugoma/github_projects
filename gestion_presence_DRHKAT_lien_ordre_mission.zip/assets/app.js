(function () {
  'use strict';

  var root = document.documentElement;
  var sidebar = document.getElementById('sidebar');
  var overlay = document.getElementById('sidebarOverlay');
  var menuToggle = document.getElementById('menuToggle');
  var themeToggle = document.getElementById('themeToggle');

  function syncThemeIcon() {
    if (!themeToggle) return;
    var dark = root.getAttribute('data-bs-theme') === 'dark';
    themeToggle.innerHTML = '<i class="bi ' + (dark ? 'bi-sun' : 'bi-moon-stars') + '"></i>';
  }

  syncThemeIcon();

  if (themeToggle) {
    themeToggle.addEventListener('click', function () {
      var next = root.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark';
      root.setAttribute('data-bs-theme', next);
      try { localStorage.setItem('presence-theme', next); } catch (e) {}
      syncThemeIcon();
    });
  }

  function closeSidebar() {
    if (sidebar) sidebar.classList.remove('open');
    if (overlay) overlay.classList.remove('show');
  }

  if (menuToggle) {
    menuToggle.addEventListener('click', function () {
      if (sidebar) sidebar.classList.toggle('open');
      if (overlay) overlay.classList.toggle('show');
    });
  }
  if (overlay) overlay.addEventListener('click', closeSidebar);

  /*
   * DataTables exige exactement le même nombre de colonnes dans THEAD et TBODY.
   * Les lignes PHP du type <td colspan="5">Aucune donnée</td> provoquent sinon
   * l'alerte "Requested unknown parameter". On retire uniquement ces lignes
   * d'état vide ; DataTables affichera ensuite son propre message emptyTable.
   */
  function prepareTable(table) {
    var head = table.tHead;
    if (!head || !head.rows.length) return false;

    var headerRow = head.rows[head.rows.length - 1];
    var expectedColumns = 0;
    var h;
    for (h = 0; h < headerRow.cells.length; h++) {
      expectedColumns += headerRow.cells[h].colSpan || 1;
    }
    if (!expectedColumns) return false;

    var body = table.tBodies.length ? table.tBodies[0] : null;
    if (!body) return true;

    var rows = Array.prototype.slice.call(body.rows);
    var i;
    for (i = rows.length - 1; i >= 0; i--) {
      var row = rows[i];
      var actualColumns = 0;
      var hasColspan = false;
      var c;
      for (c = 0; c < row.cells.length; c++) {
        var span = row.cells[c].colSpan || 1;
        actualColumns += span;
        if (span > 1) hasColspan = true;
      }

      if (row.cells.length === 1 && (hasColspan || actualColumns !== expectedColumns)) {
        body.removeChild(row);
        continue;
      }

      if (actualColumns !== expectedColumns || row.cells.length !== expectedColumns) {
        return false;
      }
    }
    return true;
  }



  /**
   * Ajoute une recherche personnalisée, colonne par colonne, à une DataTable.
   * Cette fonction est publique afin d'être réutilisée par les tableaux chargés
   * dynamiquement (registre du personnel et détail des effectifs).
   */
  window.DRHKATAddColumnFilters = function (dt, table, config) {
    if (!dt || !table) return;
    config = config || {};
    var wrapper = table.closest('.dt-container');
    if (!wrapper || wrapper.querySelector('.drhkat-column-search-panel')) return;

    var panel = document.createElement('div');
    panel.className = 'drhkat-column-search-panel card border-0 shadow-sm';
    panel.hidden = true;

    var title = document.createElement('div');
    title.className = 'drhkat-column-search-title';
    title.innerHTML = '<div><i class="bi bi-funnel"></i><strong> Recherche personnalisée</strong><small>Filtrez une ou plusieurs colonnes simultanément.</small></div>';
    panel.appendChild(title);

    var grid = document.createElement('div');
    grid.className = 'drhkat-column-search-grid';
    panel.appendChild(grid);

    var headers = table.querySelectorAll('thead tr:first-child th');
    var actionIndexes = config.exclude || [];
    var inputs = [];

    Array.prototype.forEach.call(headers, function (th, index) {
      if (actionIndexes.indexOf(index) !== -1 || th.classList.contains('actions')) return;
      var label = (th.textContent || '').trim() || ('Colonne ' + (index + 1));
      var field = document.createElement('label');
      field.className = 'drhkat-column-search-field';
      var caption = document.createElement('span');
      caption.textContent = label;
      var input = document.createElement('input');
      input.type = 'search';
      input.className = 'form-control form-control-sm';
      input.placeholder = 'Rechercher : ' + label;
      input.setAttribute('aria-label', 'Rechercher dans la colonne ' + label);
      try { input.value = dt.column(index).search() || ''; } catch (e) {}
      input.addEventListener('input', function () {
        window.clearTimeout(input._drhkatTimer);
        input._drhkatTimer = window.setTimeout(function () {
          dt.column(index).search(input.value).draw();
        }, 180);
      });
      field.appendChild(caption);
      field.appendChild(input);
      grid.appendChild(field);
      inputs.push(input);
    });

    var actions = document.createElement('div');
    actions.className = 'drhkat-column-search-actions';
    var reset = document.createElement('button');
    reset.type = 'button';
    reset.className = 'btn btn-outline-secondary btn-sm';
    reset.innerHTML = '<i class="bi bi-eraser"></i> Effacer les filtres';
    reset.addEventListener('click', function () {
      inputs.forEach(function (input) { input.value = ''; });
      dt.columns().search('');
      dt.search('');
      var globalSearch = wrapper.querySelector('.dt-search input');
      if (globalSearch) globalSearch.value = '';
      dt.draw();
    });
    actions.appendChild(reset);
    panel.appendChild(actions);

    var firstLayoutRow = wrapper.querySelector('.dt-layout-row');
    if (firstLayoutRow && firstLayoutRow.parentNode) {
      firstLayoutRow.parentNode.insertBefore(panel, firstLayoutRow.nextSibling);
    } else {
      wrapper.insertBefore(panel, wrapper.firstChild);
    }

    var toggle = document.createElement('button');
    toggle.type = 'button';
    toggle.className = 'btn btn-outline-primary btn-sm drhkat-column-search-toggle';
    toggle.innerHTML = '<i class="bi bi-funnel"></i> Recherche personnalisée';
    toggle.setAttribute('aria-expanded', 'false');
    toggle.addEventListener('click', function () {
      panel.hidden = !panel.hidden;
      toggle.setAttribute('aria-expanded', panel.hidden ? 'false' : 'true');
      toggle.classList.toggle('active', !panel.hidden);
      if (!panel.hidden && inputs.length) inputs[0].focus();
    });

    var start = wrapper.querySelector('.dt-layout-start');
    if (start) start.appendChild(toggle);
    else wrapper.insertBefore(toggle, wrapper.firstChild);
  };


  /**
   * Ajoute une première colonne de numérotation à une liste.
   * Les valeurs sont recalculées par DataTables après tri, recherche,
   * filtrage et pagination. Pour une table simple, une numérotation statique
   * est appliquée immédiatement.
   */
  window.DRHKATPrepareRowNumbers = function (table) {
    if (!table || table.getAttribute('data-row-numbering') === 'false') return false;
    if (table.getAttribute('data-row-numbering-ready') === 'true') return true;
    var head = table.tHead;
    if (!head || !head.rows.length) return false;

    Array.prototype.forEach.call(head.rows, function (row, rowIndex) {
      var th = document.createElement('th');
      th.className = 'drhkat-row-number no-print-control';
      th.setAttribute('data-orderable', 'false');
      th.setAttribute('data-searchable', 'false');
      th.setAttribute('aria-label', 'Numéro de ligne');
      th.textContent = rowIndex === head.rows.length - 1 ? 'N°' : '';
      row.insertBefore(th, row.firstChild);
    });

    Array.prototype.forEach.call(table.tBodies, function (body) {
      Array.prototype.forEach.call(body.rows, function (row, index) {
        if (row.cells.length === 1 && (row.cells[0].colSpan || 1) > 1) {
          row.cells[0].colSpan = (row.cells[0].colSpan || 1) + 1;
          return;
        }
        var td = document.createElement('td');
        td.className = 'drhkat-row-number';
        td.textContent = String(index + 1);
        row.insertBefore(td, row.firstChild);
      });
    });

    table.setAttribute('data-row-numbering-ready', 'true');
    return true;
  };

  window.DRHKATUpdateRowNumbers = function (dt, table) {
    if (!dt || !table) return;
    var info = dt.page && dt.page.info ? dt.page.info() : { start: 0 };
    var start = info && typeof info.start === 'number' ? info.start : 0;
    dt.rows({ page: 'current', search: 'applied', order: 'applied' }).every(function (rowIdx, tableLoop, rowLoop) {
      var node = this.node();
      if (node && node.cells && node.cells.length) {
        node.cells[0].textContent = String(start + rowLoop + 1);
      }
    });
  };

  window.DRHKATBindRowNumbers = function (dt, table) {
    if (!dt || !table || table.getAttribute('data-row-numbering-ready') !== 'true') return;
    var refresh = function () { window.DRHKATUpdateRowNumbers(dt, table); };
    if (dt.on) dt.on('draw order search', refresh);
    refresh();
  };

  var tables = document.querySelectorAll('table.data-table, table.table-list');
  var index;
  for (index = 0; index < tables.length; index++) {
    var table = tables[index];
    window.DRHKATPrepareRowNumbers(table);
    if (table.getAttribute('data-no-datatable') === 'true') continue;
    if (typeof window.DataTable === 'undefined') continue;
    if (!prepareTable(table)) continue;

    if (!table.id) table.id = 'presence-table-' + index;

    try {
      var actionColumn = table.querySelector('thead th.actions, thead th:last-child.actions');
      var columnButtonAvailable = !!(window.DataTable.Buttons);
      var options = {
        pageLength: -1,
        lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, 'Tous']],
        order: [],
        autoWidth: false,
        scrollX: table.scrollWidth > table.clientWidth,
        stateSave: true,
        stateDuration: 0,
        colReorder: { fixedColumnsLeft: 1 },
        columnDefs: actionColumn
          ? [{ targets: 0, orderable: false, searchable: false }, { targets: -1, orderable: false, searchable: false }]
          : [{ targets: 0, orderable: false, searchable: false }],
        language: {
          search: '',
          searchPlaceholder: 'Rechercher dans la liste…',
          lengthMenu: 'Afficher _MENU_',
          info: '_START_–_END_ sur _TOTAL_',
          infoEmpty: 'Aucune donnée',
          zeroRecords: 'Aucun résultat',
          emptyTable: 'Aucune donnée disponible',
          buttons: { colvis: 'Colonnes' },
          paginate: { first: 'Premier', last: 'Dernier', next: '›', previous: '‹' }
        }
      };

      if (columnButtonAvailable) {
        options.layout = {
          topStart: {
            buttons: [
              {
                extend: 'colvis',
                text: '<i class="bi bi-layout-three-columns"></i> Afficher / masquer',
                className: 'btn btn-outline-primary btn-sm',
                columns: actionColumn ? ':not(:first-child):not(:last-child)' : ':not(:first-child)'
              },
              {
                text: '<i class="bi bi-arrow-counterclockwise"></i> Réinitialiser',
                className: 'btn btn-outline-secondary btn-sm',
                action: function (e, dt) {
                  dt.state.clear();
                  window.location.reload();
                }
              }
            ]
          },
          topEnd: 'search',
          bottomStart: ['pageLength', 'info'],
          bottomEnd: 'paging'
        };
      }

      var dtInstance = new window.DataTable(table, options);
      table.classList.add('datatable-enhanced');
      var excludedFilters = [0];
      if (actionColumn) excludedFilters.push(table.tHead.rows[table.tHead.rows.length - 1].cells.length - 1);
      window.DRHKATAddColumnFilters(dtInstance, table, { exclude: excludedFilters });
      window.DRHKATBindRowNumbers(dtInstance, table);
    } catch (error) {
      if (window.console && console.warn) console.warn('Initialisation DataTables ignorée pour #' + table.id, error);
    }
  }

  var alerts = document.querySelectorAll('.alert');
  var alertIndex;
  for (alertIndex = 0; alertIndex < alerts.length; alertIndex++) {
    (function (alertElement) {
      setTimeout(function () {
        if (window.bootstrap && bootstrap.Alert) {
          bootstrap.Alert.getOrCreateInstance(alertElement).close();
        }
      }, 6000);
    }(alerts[alertIndex]));
  }
}());

/* Sélection universelle du signataire pour tous les rapports imprimés. */
(function () {
  'use strict';
  var modalEl = document.getElementById('globalPrintSignerModal');
  if (!modalEl || !window.bootstrap) return;
  var nativePrint = window.print.bind(window);
  var modal = new bootstrap.Modal(modalEl);
  var pending = false;

  function selectRow(row) {
    var radio = row.querySelector('input[type="radio"]');
    if (radio) radio.checked = true;
    modalEl.querySelectorAll('.global-signer-choice').forEach(function (r) { r.classList.toggle('table-active', r === row); });
  }
  modalEl.addEventListener('click', function (e) {
    var row = e.target.closest('.global-signer-choice');
    if (row) selectRow(row);
  });
  modalEl.addEventListener('keydown', function (e) {
    var row = e.target.closest('.global-signer-choice');
    if (row && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); selectRow(row); }
  });

  window.print = function () {
    pending = true;
    modal.show();
  };

  var confirmBtn = document.getElementById('globalConfirmPrint');
  if (confirmBtn) confirmBtn.addEventListener('click', function () {
    var radio = modalEl.querySelector('input[name="global_print_signer"]:checked');
    if (!radio) { alert('Sélectionnez le signataire du rapport.'); return; }
    var row = radio.closest('.global-signer-choice');
    document.getElementById('globalPrintSignatureName').textContent = row.getAttribute('data-nom') || '';
    document.getElementById('globalPrintSignatureTitle').textContent = row.getAttribute('data-qualite') || '';
    modal.hide();
    if (pending) { pending = false; setTimeout(nativePrint, 250); }
  });

  var form = document.getElementById('globalSignerCreateForm');
  if (form) form.addEventListener('submit', function (e) {
    e.preventDefault();
    var msg = document.getElementById('globalSignerFormMessage');
    msg.className = 'small mt-2 text-muted'; msg.textContent = 'Enregistrement…';
    fetch('signataire_impression_api.php', { method:'POST', body:new FormData(form), credentials:'same-origin' })
      .then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j.message || 'Erreur'); return j; }); })
      .then(function (j) {
        var s = j.signataire;
        if (s.actif) {
          var tbody = document.getElementById('globalPrintSignerRows');
          var empty = tbody.querySelector('.global-empty-signers'); if (empty) empty.remove();
          var tr = document.createElement('tr'); tr.className='global-signer-choice table-active'; tr.tabIndex=0; tr.setAttribute('role','button'); tr.setAttribute('data-id',s.id); tr.setAttribute('data-nom',s.nom_complet); tr.setAttribute('data-qualite',s.qualite);
          tr.innerHTML='<td><input class="form-check-input" type="radio" name="global_print_signer" value="'+s.id+'" checked></td><td><strong></strong></td><td></td>';
          tr.cells[1].querySelector('strong').textContent=s.nom_complet; tr.cells[2].textContent=s.qualite; tbody.appendChild(tr);
        }
        form.reset(); document.getElementById('globalSignerActive').checked=true;
        msg.className='small mt-2 text-success'; msg.textContent='Signataire ajouté et sélectionné.';
      })
      .catch(function (err) { msg.className='small mt-2 text-danger'; msg.textContent=err.message; });
  });
})();

/* Assistant conversationnel global DRHKAT. */
(function () {
  'use strict';
  var root=document.getElementById('drhkatChatbot'); if(!root) return;
  var toggle=document.getElementById('drhkatChatbotToggle'), panel=document.getElementById('drhkatChatbotPanel'), close=document.getElementById('drhkatChatbotClose');
  var reset=document.getElementById('drhkatChatbotReset'), form=document.getElementById('drhkatChatbotForm'), input=document.getElementById('drhkatChatbotInput'), messages=document.getElementById('drhkatChatbotMessages'), suggestions=document.getElementById('drhkatChatbotSuggestions');
  var logo=(root.getAttribute('data-logo')||'assets/img/logo-drhkat.png');
  function openChat(){panel.hidden=false;toggle.setAttribute('aria-expanded','true');setTimeout(function(){input.focus();},80)}
  function closeChat(){panel.hidden=true;toggle.setAttribute('aria-expanded','false')}
  toggle.addEventListener('click',function(){panel.hidden?openChat():closeChat()}); close.addEventListener('click',closeChat);
  function addMessage(text,type,links,metrics,table){
    var row=document.createElement('div'); row.className='chat-message '+type;
    if(type.indexOf('bot')!==-1){var img=document.createElement('img');img.className='chatbot-message-logo';img.src=logo;img.alt='';row.appendChild(img)}
    var bubble=document.createElement('div');
    var textBox=document.createElement('div');textBox.className='chat-text';textBox.textContent=text;bubble.appendChild(textBox);
    if(metrics&&metrics.length){var grid=document.createElement('div');grid.className='chat-metrics';metrics.forEach(function(m){var c=document.createElement('div');c.className='chat-metric';var v=document.createElement('strong');v.textContent=m.value;var l=document.createElement('span');l.textContent=m.label;c.appendChild(v);c.appendChild(l);grid.appendChild(c)});bubble.appendChild(grid)}
    if(table&&table.columns&&table.rows){var wrap=document.createElement('div');wrap.className='chat-table-wrap';var t=document.createElement('table');t.className='chat-table';var thead=document.createElement('thead'),trh=document.createElement('tr');table.columns.forEach(function(c){var th=document.createElement('th');th.textContent=c;trh.appendChild(th)});thead.appendChild(trh);t.appendChild(thead);var tb=document.createElement('tbody');table.rows.forEach(function(r){var tr=document.createElement('tr');r.forEach(function(v){var td=document.createElement('td');td.textContent=(v===null||typeof v==='undefined')?'—':v;tr.appendChild(td)});tb.appendChild(tr)});t.appendChild(tb);wrap.appendChild(t);bubble.appendChild(wrap)}
    if(links&&links.length){var box=document.createElement('div');box.className='chat-links';links.forEach(function(l){var a=document.createElement('a');a.href=l.url;a.textContent=l.label;box.appendChild(a)});bubble.appendChild(box)}
    row.appendChild(bubble);messages.appendChild(row);messages.scrollTop=messages.scrollHeight;return row
  }
  function setSuggestions(items){suggestions.innerHTML='';(items||[]).forEach(function(t){var b=document.createElement('button');b.type='button';b.textContent=t;b.addEventListener('click',function(){input.value=t;send()});suggestions.appendChild(b)})}
  function send(custom){var q=(typeof custom==='string'?custom:input.value).trim();if(!q)return;openChat();addMessage(q,'user');input.value='';var loading=addMessage('Analyse de la demande et consultation des données…','bot loading');var fd=new FormData();fd.append('question',q);fd.append('page',location.pathname.split('/').pop()||'index.php');fetch('chatbot_api.php',{method:'POST',body:fd,credentials:'same-origin'}).then(function(r){return r.json().then(function(j){if(!r.ok)throw new Error(j.message||'Erreur');return j})}).then(function(j){loading.remove();addMessage(j.message||'Réponse indisponible.','bot',j.links||[],j.metrics||[],j.table||null);setSuggestions(j.suggestions||[])}).catch(function(e){loading.remove();addMessage('Impossible de traiter la demande : '+e.message,'bot')})}
  form.addEventListener('submit',function(e){e.preventDefault();send()}); input.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}}); suggestions.querySelectorAll('button').forEach(function(b){b.addEventListener('click',function(){input.value=b.textContent;send()})});
  if(reset) reset.addEventListener('click',function(){messages.innerHTML='';addMessage('Nouvelle conversation. Posez votre question sur le personnel, les présences ou les fonctions du site.','bot');setSuggestions(['Résumé RH','Top 10 des sites','Retards ce mois']);send('Réinitialiser conversation')});
}());


/* Recherche instantanée dans les listes déroulantes de fonctions */
(function () {
  'use strict';

  function normalizeText(value) {
    return String(value || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .trim();
  }

  function enhanceFunctionSelect(select) {
    if (!select || select.dataset.searchableReady === '1') return;
    select.dataset.searchableReady = '1';

    var options = Array.prototype.map.call(select.options, function (option) {
      return {
        value: String(option.value),
        text: option.textContent.trim(),
        disabled: option.disabled
      };
    });

    var wrapper = document.createElement('div');
    wrapper.className = 'drhkat-combobox';
    select.parentNode.insertBefore(wrapper, select);
    wrapper.appendChild(select);
    select.classList.add('drhkat-combobox-native');
    select.setAttribute('aria-hidden', 'true');
    select.tabIndex = -1;

    var trigger = document.createElement('button');
    trigger.type = 'button';
    trigger.className = 'drhkat-combobox-trigger';
    trigger.setAttribute('aria-haspopup', 'listbox');
    trigger.setAttribute('aria-expanded', 'false');

    var triggerText = document.createElement('span');
    triggerText.className = 'drhkat-combobox-value';
    var arrow = document.createElement('span');
    arrow.className = 'drhkat-combobox-arrow';
    arrow.setAttribute('aria-hidden', 'true');
    arrow.textContent = '▾';
    trigger.appendChild(triggerText);
    trigger.appendChild(arrow);

    var panel = document.createElement('div');
    panel.className = 'drhkat-combobox-panel';
    panel.hidden = true;

    var searchWrap = document.createElement('div');
    searchWrap.className = 'drhkat-combobox-search-wrap';
    var search = document.createElement('input');
    search.type = 'search';
    search.className = 'drhkat-combobox-search';
    search.placeholder = select.getAttribute('data-search-placeholder') || 'Rechercher dans la liste…';
    search.autocomplete = 'off';
    search.setAttribute('aria-label', search.placeholder);
    searchWrap.appendChild(search);

    var list = document.createElement('div');
    list.className = 'drhkat-combobox-list';
    list.setAttribute('role', 'listbox');
    var empty = document.createElement('div');
    empty.className = 'drhkat-combobox-empty';
    empty.textContent = 'Aucun élément trouvé';
    empty.hidden = true;

    panel.appendChild(searchWrap);
    panel.appendChild(list);
    panel.appendChild(empty);
    wrapper.appendChild(trigger);
    wrapper.appendChild(panel);

    function selectedText() {
      var current = options.find(function (item) { return item.value === String(select.value); });
      return current ? current.text : (options[0] ? options[0].text : '— Sélectionner —');
    }

    function updateTrigger() {
      triggerText.textContent = selectedText();
      trigger.classList.toggle('is-placeholder', !select.value);
    }

    function closePanel(returnFocus) {
      panel.hidden = true;
      trigger.setAttribute('aria-expanded', 'false');
      wrapper.classList.remove('is-open');
      search.value = '';
      render('');
      if (returnFocus) trigger.focus();
    }

    function openPanel() {
      document.querySelectorAll('.drhkat-combobox.is-open').forEach(function (other) {
        if (other !== wrapper) {
          var otherPanel = other.querySelector('.drhkat-combobox-panel');
          var otherTrigger = other.querySelector('.drhkat-combobox-trigger');
          if (otherPanel) otherPanel.hidden = true;
          if (otherTrigger) otherTrigger.setAttribute('aria-expanded', 'false');
          other.classList.remove('is-open');
        }
      });
      panel.hidden = false;
      trigger.setAttribute('aria-expanded', 'true');
      wrapper.classList.add('is-open');
      render('');
      window.setTimeout(function () { search.focus(); }, 0);
    }

    function choose(value) {
      select.value = value;
      select.dispatchEvent(new Event('change', { bubbles: true }));
      updateTrigger();
      closePanel(true);
    }

    function render(query) {
      var q = normalizeText(query);
      list.innerHTML = '';
      var matches = options.filter(function (item) {
        return !q || normalizeText(item.text + ' ' + item.value).indexOf(q) !== -1;
      });
      matches.forEach(function (item) {
        var row = document.createElement('button');
        row.type = 'button';
        row.className = 'drhkat-combobox-option';
        row.setAttribute('role', 'option');
        row.setAttribute('aria-selected', item.value === String(select.value) ? 'true' : 'false');
        row.disabled = item.disabled;
        row.dataset.value = item.value;
        row.textContent = item.text;
        if (item.value === String(select.value)) row.classList.add('is-selected');
        row.addEventListener('click', function () { choose(item.value); });
        list.appendChild(row);
      });
      empty.hidden = matches.length !== 0;
    }

    trigger.addEventListener('click', function () {
      if (panel.hidden) openPanel(); else closePanel(false);
    });
    search.addEventListener('input', function () { render(search.value); });
    search.addEventListener('keydown', function (event) {
      var rows = Array.prototype.slice.call(list.querySelectorAll('.drhkat-combobox-option:not(:disabled)'));
      if (event.key === 'Escape') {
        event.preventDefault(); closePanel(true);
      } else if (event.key === 'ArrowDown' && rows.length) {
        event.preventDefault(); rows[0].focus();
      } else if (event.key === 'Enter' && rows.length === 1) {
        event.preventDefault(); rows[0].click();
      }
    });
    list.addEventListener('keydown', function (event) {
      var rows = Array.prototype.slice.call(list.querySelectorAll('.drhkat-combobox-option:not(:disabled)'));
      var index = rows.indexOf(document.activeElement);
      if (event.key === 'ArrowDown') {
        event.preventDefault(); rows[Math.min(index + 1, rows.length - 1)].focus();
      } else if (event.key === 'ArrowUp') {
        event.preventDefault();
        if (index <= 0) search.focus(); else rows[index - 1].focus();
      } else if (event.key === 'Escape') {
        event.preventDefault(); closePanel(true);
      }
    });
    select.addEventListener('change', updateTrigger);
    document.addEventListener('click', function (event) {
      if (!wrapper.contains(event.target) && !panel.hidden) closePanel(false);
    });

    updateTrigger();
    render('');
  }

  function initFunctionSearch(root) {
    (root || document).querySelectorAll('select.js-searchable-function').forEach(enhanceFunctionSelect);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { initFunctionSearch(document); });
  } else {
    initFunctionSearch(document);
  }

  var observer = new MutationObserver(function (mutations) {
    mutations.forEach(function (mutation) {
      mutation.addedNodes.forEach(function (node) {
        if (node.nodeType !== 1) return;
        if (node.matches && node.matches('select.js-searchable-function')) enhanceFunctionSelect(node);
        else initFunctionSearch(node);
      });
    });
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
}());
