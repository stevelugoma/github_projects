(function () {
  'use strict';

  function parseRecord(button) {
    try { return JSON.parse(button.getAttribute('data-record') || '{}'); }
    catch (e) { return {}; }
  }

  function setValue(id, value) {
    var el = document.getElementById(id);
    if (el) el.value = value == null ? '' : value;
  }

  var personnelCodeSuggestions = {};
  var suggestionsNode = document.getElementById('personnelCodeSuggestions');
  if (suggestionsNode) {
    try { personnelCodeSuggestions = JSON.parse(suggestionsNode.textContent || '{}'); } catch (e) { personnelCodeSuggestions = {}; }
  }

  function refreshAgentCodeSuggestion() {
    var gradeSelect = document.getElementById('ID_GRADE');
    var box = document.getElementById('gradeCodeSuggestion');
    if (!gradeSelect || !box) return;
    var info = personnelCodeSuggestions[String(gradeSelect.value || '')];
    if (!info) { box.hidden = true; return; }
    var last = document.getElementById('lastGradeAgentCode');
    var next = document.getElementById('nextGradeAgentCode');
    var name = document.getElementById('gradeCodeName');
    if (last) last.textContent = info.dernier == null ? 'Aucun' : info.dernier;
    if (next) next.textContent = info.suivant;
    if (name) name.textContent = info.grade || 'ce grade';
    box.hidden = false;
  }

  var gradeForSuggestion = document.getElementById('ID_GRADE');
  if (gradeForSuggestion) gradeForSuggestion.addEventListener('change', refreshAgentCodeSuggestion);
  var applyNextAgentCode = document.getElementById('applyNextAgentCode');
  if (applyNextAgentCode) applyNextAgentCode.addEventListener('click', function () {
    var gradeSelect = document.getElementById('ID_GRADE');
    var codeInput = document.getElementById('CODE_AGENT');
    var info = gradeSelect ? personnelCodeSuggestions[String(gradeSelect.value || '')] : null;
    if (codeInput && info) {
      codeInput.value = info.suivant;
      codeInput.focus();
      codeInput.classList.add('code-suggestion-applied');
      window.setTimeout(function () { codeInput.classList.remove('code-suggestion-applied'); }, 1200);
    }
  });



  // Clic sur une ligne Site / Appartenance / Division : afficher l'effectif détaillé.
  var effectifModalEl = document.getElementById('effectifDetailModal');
  var effectifModal = effectifModalEl && window.bootstrap ? new bootstrap.Modal(effectifModalEl) : null;
  var effectifRows = document.querySelectorAll('.effectif-row');
  var effectifCurrentLabel = '';
  var effectifDetailDataTable = null;
  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>'"]/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]; });
  }
  function openEffectifBy(type, id, label) {
    if (!effectifModal) return;
    type = type || '';
    id = id == null || id === '' ? '__NULL__' : String(id);
    label = label || 'Détail de l’effectif';
    effectifCurrentLabel = label;
    var subtitle = document.getElementById('effectifDetailSubtitle');
    var count = document.getElementById('effectifDetailCount');
    var tbody = document.querySelector('#effectifDetailTable tbody');
    if (subtitle) subtitle.textContent = label;
    if (count) count.textContent = '…';
    if (effectifDetailDataTable) {
      effectifDetailDataTable.clear().draw();
    } else if (tbody) {
      tbody.innerHTML = '';
    }
    effectifModal.show();
    fetch('personnels.php?ajax_effectif=1&type=' + encodeURIComponent(type) + '&id=' + encodeURIComponent(id) + '&label=' + encodeURIComponent(label), { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (!data.ok) throw new Error(data.message || 'Chargement impossible');
        if (count) count.textContent = String(data.effectif || 0);
        if (!tbody) return;
        var rows = (data.rows || []).map(function (r) {
          return ['', r.CODE_AGENT || '', r.NOMS || '', r.SITE || '', r.ENTITE || '', r.DIVISION || '', r.GRADES || '', r.CODE_FONCTION || '', r.FONCTION_AGENT || '', r.MATRICULE || ''];
        });
        var tableNode = document.getElementById('effectifDetailTable');
        if (tableNode && window.DRHKATPrepareRowNumbers) window.DRHKATPrepareRowNumbers(tableNode);
        if (!effectifDetailDataTable && tableNode && window.DataTable) {
          effectifDetailDataTable = new DataTable(tableNode, {
            data: rows,
            pageLength: 25,
            lengthMenu: [[10,25,50,100,-1],[10,25,50,100,'Tous']],
            order: [[2,'asc']],
            autoWidth: false,
            scrollX: true,
            stateSave: true,
            colReorder: { fixedColumnsLeft: 1 },
            columnDefs: [{ targets: 0, orderable: false, searchable: false }],
            layout: {
              topStart: { buttons: [
                { extend: 'colvis', text: '<i class="bi bi-layout-three-columns"></i> Afficher / masquer', className: 'btn btn-outline-primary btn-sm', columns: ':not(:first-child)' },
                { text: '<i class="bi bi-arrow-counterclockwise"></i> Réinitialiser', className: 'btn btn-outline-secondary btn-sm', action: function(e,dt){ dt.state.clear(); dt.columns().visible(true); dt.colReorder.reset(); } }
              ] },
              topEnd: 'search', bottomStart: ['pageLength','info'], bottomEnd: 'paging'
            },
            language: { search:'', searchPlaceholder:'Rechercher dans cet effectif…', lengthMenu:'Afficher _MENU_', info:'_START_–_END_ sur _TOTAL_', infoEmpty:'Aucune donnée', zeroRecords:'Aucun personnel trouvé', emptyTable:'Aucun personnel rattaché', buttons:{colvis:'Colonnes'}, paginate:{first:'Premier',last:'Dernier',next:'›',previous:'‹'} }
          });
          if (window.DRHKATAddColumnFilters) window.DRHKATAddColumnFilters(effectifDetailDataTable, tableNode, { exclude: [0] });
          if (window.DRHKATBindRowNumbers) window.DRHKATBindRowNumbers(effectifDetailDataTable, tableNode);
        } else if (effectifDetailDataTable) {
          effectifDetailDataTable.clear();
          effectifDetailDataTable.rows.add(rows).draw();
        }
      })
      .catch(function (err) {
        if (count) count.textContent = '0';
        if (effectifDetailDataTable) effectifDetailDataTable.clear().draw(); else if (tbody) tbody.innerHTML = '';
        if (window.console && console.error) console.error(err);
      });
  }
  function openEffectifDetail(row) {
    if (!row) return;
    openEffectifBy(
      row.getAttribute('data-effectif-type') || '',
      row.getAttribute('data-effectif-id') || '',
      row.getAttribute('data-effectif-label') || ''
    );
  }
  Array.prototype.forEach.call(effectifRows, function (row) {
    row.addEventListener('click', function (event) {
      if (event.target.closest('button,a,form,input,select,textarea')) return;
      openEffectifDetail(row);
    });
    row.addEventListener('keydown', function (event) {
      if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); openEffectifDetail(row); }
    });
  });
  var pendingPrintAction = null;
  var printSignataireModalEl = document.getElementById('printSignataireModal');
  var printSignataireModal = printSignataireModalEl && window.bootstrap ? new bootstrap.Modal(printSignataireModalEl) : null;
  function askSignerThenPrint(action) {
    pendingPrintAction = action;
    if (!printSignataireModal) { action({nom:'',qualite:''}); return; }
    var checked = printSignataireModalEl.querySelector('input[name="print_signataire"]:checked');
    if (checked) checked.checked = false;
    printSignataireModal.show();
  }
  Array.prototype.forEach.call(document.querySelectorAll('.signataire-choice'), function (row) {
    row.addEventListener('click', function () { var r=row.querySelector('input[type=radio]'); if(r) r.checked=true; });
    row.addEventListener('keydown', function (e) { if(e.key==='Enter'||e.key===' '){e.preventDefault();var r=row.querySelector('input[type=radio]');if(r)r.checked=true;} });
  });
  if (printSignataireModal && new URLSearchParams(window.location.search).get('ouvrir_signataires_impression') === '1') {
    printSignataireModal.show();
    if (window.history && window.history.replaceState) {
      var cleanUrl = window.location.pathname + window.location.hash;
      window.history.replaceState({}, document.title, cleanUrl);
    }
  }
  var confirmPrintWithSigner = document.getElementById('confirmPrintWithSigner');
  if (confirmPrintWithSigner) confirmPrintWithSigner.addEventListener('click', function () {
    var radio = printSignataireModalEl.querySelector('input[name="print_signataire"]:checked');
    if (!radio) { alert('Sélectionnez le signataire.'); return; }
    var row = radio.closest('.signataire-choice');
    var signer = { nom: row.getAttribute('data-nom') || '', qualite: row.getAttribute('data-qualite') || '' };
    printSignataireModal.hide();
    if (pendingPrintAction) { var fn=pendingPrintAction; pendingPrintAction=null; window.setTimeout(function(){ fn(signer); },250); }
  });
  function signatureHtml(signer) {
    return '<div class="signature-block"><div class="signature-label">Pour signature</div><div class="signature-space"></div><div class="signature-name">' + escapeHtml(signer.nom) + '</div><div class="signature-title">' + escapeHtml(signer.qualite) + '</div></div>';
  }
  var effectifPrintBtn = document.getElementById('effectifPrintBtn');
  if (effectifPrintBtn) effectifPrintBtn.addEventListener('click', function () {
    askSignerThenPrint(function (signer) {
      var table = document.getElementById('effectifDetailTable');
      if (!table) return;
      var w = window.open('', '_blank');
      if (!w) return;
      w.document.write('<!doctype html><html><head><meta charset="utf-8"><title>Effectif - ' + escapeHtml(effectifCurrentLabel) + '</title><style>body{font-family:Arial,sans-serif;color:#111;margin:28px}.head{display:flex;align-items:center;gap:18px;border-bottom:3px solid #1e3a8a;padding-bottom:14px;margin-bottom:20px}.head img{width:95px;height:75px;object-fit:contain}.head strong,.head span,.head small{display:block}.head strong{font-size:18px;color:#16366b}.head span{font-size:13px;margin-top:4px}.head small{font-size:11px;color:#555;margin-top:5px}h2{font-size:17px;margin:0 0 5px}.meta{margin-bottom:16px;color:#444}table{width:100%;border-collapse:collapse;font-size:11px}th,td{border:1px solid #999;padding:6px;text-align:left}th{background:#eef3fb}.signature-block{width:320px;margin:55px 0 0 auto;text-align:center;page-break-inside:avoid}.signature-label{font-size:12px;color:#555}.signature-space{height:70px}.signature-name{font-size:18px;font-weight:700}.signature-title{font-size:15px;font-weight:700;margin-top:18px}@media print{body{margin:12mm}}</style></head><body><div class="head"><img src="assets/img/logo-drhkat.png"><div><strong>Direction des Recettes du Haut-Katanga — DRHKAT</strong><span>Division des Ressources Humaines et de l’Administration</span><small>www.edrhkat.com · drhkat.d@edrhkat.com</small></div></div><h2>' + escapeHtml(effectifCurrentLabel) + '</h2><div class="meta">Effectif : ' + escapeHtml(document.getElementById('effectifDetailCount').textContent) + '</div>' + table.outerHTML + signatureHtml(signer) + '<script>window.onload=function(){window.print();}<\/script></body></html>');
      w.document.close();
    });
  });

  var personnelModal = document.getElementById('personnelModal');
  if (personnelModal) {
    personnelModal.addEventListener('show.bs.modal', function (event) {
      var button = event.relatedTarget;
      var record = button && button.classList.contains('edit-personnel') ? parseRecord(button) : {};
      var isEdit = !!record.CODE_AGENT;
      personnelModal.querySelector('.modal-title').textContent = isEdit ? 'Modifier la fiche du personnel' : 'Nouveau membre du personnel';
      ['CODE_AGENT','NOMS','CODE_SITE','CODE_ENTITE','CODE_FONCTION','MATRICULE'].forEach(function (key) {
        setValue(key, record[key]);
      });
      setValue('OLD_CODE_AGENT', record.CODE_AGENT || '');
      setValue('ID_DIV', record.ID_DIV_REF || '');
      var gradeSelect = document.getElementById('ID_GRADE');
      if (gradeSelect) {
        var selectedGrade = '';
        Array.prototype.forEach.call(gradeSelect.options, function (opt) {
          if (!selectedGrade && ((opt.getAttribute('data-code') || '') == (record.CODE_GRADE || '') || (opt.getAttribute('data-sigle') || '') == (record.GRADES || ''))) selectedGrade = opt.value;
        });
        gradeSelect.value = selectedGrade;
      }
      filterMemberships(record.CODE_ENTITE || '');
      refreshAgentCodeSuggestion();
    });
  }

  var signataireModal = document.getElementById('signataireModal');
  if (signataireModal) {
    signataireModal.addEventListener('show.bs.modal', function (event) {
      var button = event.relatedTarget;
      var record = button && button.classList.contains('edit-signataire') ? parseRecord(button) : {};
      signataireModal.querySelector('.modal-title').textContent = record.id ? 'Modifier le signataire' : 'Nouveau signataire';
      setValue('signataire_id', record.id || '');
      setValue('signataire_nom', record.nom_complet || '');
      setValue('signataire_qualite', record.qualite || '');
      setValue('signataire_ordre', record.ordre_affichage || 0);
      var actif = document.getElementById('signataire_actif');
      if (actif) actif.checked = !record.id || String(record.actif) === '1';
    });
  }

  var siteModal = document.getElementById('siteModal');
  if (siteModal) {
    siteModal.addEventListener('show.bs.modal', function (event) {
      var button = event.relatedTarget;
      var record = button && button.classList.contains('edit-site') ? parseRecord(button) : {};
      siteModal.querySelector('.modal-title').textContent = record.IdEntite ? 'Modifier le site' : 'Nouveau site';
      setValue('IdEntite', record.IdEntite);
      setValue('Site', record.Site);
      setValue('CommentaireEnt', record.CommentaireEnt);
    });
  }

  var appModal = document.getElementById('appartenanceModal');
  if (appModal) {
    appModal.addEventListener('show.bs.modal', function (event) {
      var button = event.relatedTarget;
      var record = button && button.classList.contains('edit-appartenance') ? parseRecord(button) : {};
      appModal.querySelector('.modal-title').textContent = record.IdAppartenance ? 'Modifier l’appartenance' : 'Nouvelle appartenance';
      setValue('IdAppartenance', record.IdAppartenance);
      setValue('DesignationAppart', record.DesignationAppart);
      setValue('AppEntite', record.Entite);
      setValue('CommentaireAppart', record.CommentaireAppart);
    });
  }


  var divisionModal = document.getElementById('divisionModal');
  if (divisionModal) {
    divisionModal.addEventListener('show.bs.modal', function (event) {
      var button = event.relatedTarget;
      var record = button && button.classList.contains('edit-division') ? parseRecord(button) : {};
      divisionModal.querySelector('.modal-title').textContent = record.ID_DIV ? 'Modifier la division' : 'Nouvelle division';
      setValue('OLD_ID_DIV', record.ID_DIV || '');
      setValue('DIV_ID_DIV', record.ID_DIV || '');
      setValue('DIV_CODE_DIV', record.CODE_DIV || '');
      setValue('DIV_DIVISION', record.DIVISION || '');
    });
  }

  var fonctionModal = document.getElementById('fonctionModal');
  if (fonctionModal) {
    fonctionModal.addEventListener('show.bs.modal', function (event) {
      var button = event.relatedTarget;
      var record = button && button.classList.contains('edit-fonction') ? parseRecord(button) : {};
      fonctionModal.querySelector('.modal-title').textContent = record.id_fonction ? 'Modifier la fonction' : 'Nouvelle fonction';
      ['id_fonction','Libelle_Fonction','Sigle_Fonction','Commentaires_Fonction','Obs_Fonction','Etat_Fonction'].forEach(function (key) {
        setValue(key, record[key]);
      });
      if (!record.id_fonction) setValue('Etat_Fonction', '1');
    });
  }

  var siteSelect = document.getElementById('CODE_SITE');
  var membershipSelect = document.getElementById('CODE_ENTITE');

  function filterMemberships(preferredValue) {
    if (!siteSelect || !membershipSelect) return;
    var site = String(siteSelect.value || '');
    var options = membershipSelect.options;
    var i;
    for (i = 0; i < options.length; i++) {
      var opt = options[i];
      if (!opt.value) { opt.hidden = false; opt.disabled = false; continue; }
      var visible = !site || String(opt.getAttribute('data-site') || '') === site;
      opt.hidden = !visible;
      opt.disabled = !visible;
    }
    if (preferredValue) membershipSelect.value = String(preferredValue);
    if (membershipSelect.selectedOptions.length && membershipSelect.selectedOptions[0].disabled) membershipSelect.value = '';
  }

  if (siteSelect) siteSelect.addEventListener('change', function () { filterMemberships(''); });

  var tableElement = document.getElementById('personnelDynamicTable');
  if (tableElement && window.DRHKATPrepareRowNumbers) window.DRHKATPrepareRowNumbers(tableElement);
  if (tableElement && window.DataTable) {
    try {
      if (localStorage.getItem('drhkat-personnel-columns-v4') !== 'ready') {
        Object.keys(localStorage).forEach(function (key) { if (key.indexOf('DataTables_personnelDynamicTable_') === 0) localStorage.removeItem(key); });
        localStorage.setItem('drhkat-personnel-columns-v4', 'ready');
      }
    } catch (e) {}
    var columnNames = [];
    var headers = tableElement.querySelectorAll('thead th');
    Array.prototype.forEach.call(headers, function (th) { columnNames.push(th.textContent.trim()); });

    var groupSelect = document.createElement('select');
    groupSelect.className = 'form-select form-select-sm personnel-group-select';
    groupSelect.setAttribute('aria-label', 'Regrouper les données');
    groupSelect.innerHTML = '<option value="">Sans regroupement</option>';
    columnNames.slice(1, -1).forEach(function (name, idx) {
      var option = document.createElement('option');
      option.value = String(idx + 1);
      option.textContent = 'Regrouper par ' + name;
      groupSelect.appendChild(option);
    });

    var savedGroup = '';
    try { savedGroup = localStorage.getItem('drhkat-personnel-group') || ''; } catch (e) {}
    groupSelect.value = savedGroup;

    var table = new DataTable(tableElement, {
      pageLength: 25,
      lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, 'Tous']],
      order: [[2, 'asc']],
      autoWidth: false,
      scrollX: true,
      stateSave: true,
      colReorder: { fixedColumnsLeft: 1 },
      rowGroup: savedGroup !== '' ? { dataSrc: Number(savedGroup), startRender: function (rows, group) { return group + ' (' + rows.count() + ')'; } } : false,
      layout: {
        topStart: {
          buttons: [
            { extend: 'colvis', text: '<i class="bi bi-layout-three-columns"></i> Colonnes', className: 'btn btn-outline-primary btn-sm', columns: ':not(:first-child):not(:last-child)' },
            { extend: 'csvHtml5', text: '<i class="bi bi-filetype-csv"></i> CSV', className: 'btn btn-outline-primary btn-sm', title: 'Personnel_DRHKAT', exportOptions: { columns: ':visible:not(:first-child):not(:last-child)' } },
            { text: '<i class="bi bi-printer"></i> Imprimer', className: 'btn btn-outline-primary btn-sm', action: function (e, dt) { askSignerThenPrint(function (signer) { var w=window.open('', '_blank'); if(!w)return; var visible=[]; dt.columns(':visible:not(:last-child)').every(function(){visible.push(this.index());}); var head='<tr>'+visible.map(function(i){return '<th>'+escapeHtml(dt.column(i).header().textContent.trim())+'</th>';}).join('')+'</tr>'; var body=''; dt.rows({search:'applied'}).every(function(){var d=this.data(); body+='<tr>'+visible.map(function(i){var v=typeof d[i]==='string'?d[i].replace(/<[^>]*>/g,''):d[i];return '<td>'+escapeHtml(v)+'</td>';}).join('')+'</tr>';}); w.document.write('<!doctype html><html><head><meta charset="utf-8"><title>Registre du personnel</title><style>body{font-family:Arial,sans-serif;color:#111;margin:28px}.head{display:flex;align-items:center;gap:18px;border-bottom:3px solid #1e3a8a;padding-bottom:14px;margin-bottom:20px}.head img{width:95px;height:75px;object-fit:contain}.head strong,.head span,.head small{display:block}.head strong{font-size:18px;color:#16366b}.head span{font-size:13px;margin-top:4px}.head small{font-size:11px;color:#555;margin-top:5px}table{width:100%;border-collapse:collapse;font-size:9px}th,td{border:1px solid #999;padding:5px;text-align:left}th{background:#eef3fb}.signature-block{width:320px;margin:55px 0 0 auto;text-align:center;page-break-inside:avoid}.signature-label{font-size:12px;color:#555}.signature-space{height:70px}.signature-name{font-size:18px;font-weight:700}.signature-title{font-size:15px;font-weight:700;margin-top:18px}@media print{body{margin:10mm}}</style></head><body><div class="head"><img src="assets/img/logo-drhkat.png"><div><strong>Direction des Recettes du Haut-Katanga — DRHKAT</strong><span>Division des Ressources Humaines et de l’Administration</span><small>www.edrhkat.com · drhkat.d@edrhkat.com</small></div></div><h2>Registre du personnel</h2><table><thead>'+head+'</thead><tbody>'+body+'</tbody></table>'+signatureHtml(signer)+'<script>window.onload=function(){window.print();}<\/script></body></html>');w.document.close();}); } }
          ]
        },
        topEnd: 'search',
        bottomStart: 'info',
        bottomEnd: 'paging'
      },
      columnDefs: [
        { targets: 0, orderable: false, searchable: false },
        { targets: [3, 5, 7], visible: false },
        { targets: -1, orderable: false, searchable: false }
      ],
      language: {
        search: '', searchPlaceholder: 'Rechercher dans le personnel…',
        lengthMenu: 'Afficher _MENU_', info: '_START_–_END_ sur _TOTAL_', infoEmpty: 'Aucune donnée',
        zeroRecords: 'Aucun personnel ne correspond aux critères', emptyTable: 'Aucune fiche disponible',
        paginate: { first: 'Premier', last: 'Dernier', next: '›', previous: '‹' },
        buttons: { colvis: 'Colonnes', collection: 'Sélection' }
      }
    });
    if (window.DRHKATAddColumnFilters) window.DRHKATAddColumnFilters(table, tableElement, { exclude: [0, columnNames.length - 1] });
    if (window.DRHKATBindRowNumbers) window.DRHKATBindRowNumbers(table, tableElement);

    var wrapper = tableElement.closest('.dt-container');
    if (wrapper) {
      var topStart = wrapper.querySelector('.dt-layout-start');
      var groupBox = document.createElement('div');
      groupBox.className = 'personnel-group-box';
      groupBox.innerHTML = '<i class="bi bi-collection"></i>';
      groupBox.appendChild(groupSelect);
      if (topStart) topStart.appendChild(groupBox);
    }

    groupSelect.addEventListener('change', function () {
      var value = groupSelect.value;
      try { localStorage.setItem('drhkat-personnel-group', value); } catch (e) {}
      if (value === '') {
        table.rowGroup().disable();
      } else {
        table.rowGroup().dataSrc(Number(value)).enable();
      }
      table.draw(false);
    });
  }

  function getChartData() {
    var node = document.getElementById('personnelChartData');
    if (!node) return null;
    try { return JSON.parse(node.textContent); } catch (e) { return null; }
  }

  function labels(rows) { return rows.map(function (r) { return r.label; }); }
  function values(rows) { return rows.map(function (r) { return Number(r.total || 0); }); }
  function chartColors(count, alpha) {
    var base = ['54, 112, 255','25, 195, 125','129, 92, 246','245, 158, 11','239, 68, 68','14, 165, 233','236, 72, 153','132, 204, 22','249, 115, 22','99, 102, 241','20, 184, 166','168, 85, 247'];
    var out = [];
    for (var i = 0; i < count; i++) out.push('rgba(' + base[i % base.length] + ',' + alpha + ')');
    return out;
  }

  var personnelValueLabels = {
    id: 'personnelValueLabels',
    afterDatasetsDraw: function (chart) {
      var ctx = chart.ctx;
      ctx.save();
      ctx.font = '700 12px Inter, Segoe UI, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'bottom';
      ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue('--bs-body-color').trim() || '#dce6f5';
      chart.data.datasets.forEach(function (dataset, datasetIndex) {
        var meta = chart.getDatasetMeta(datasetIndex);
        if (meta.hidden) return;
        meta.data.forEach(function (element, index) {
          var value = Number(dataset.data[index] || 0);
          if (!value) return;
          var pos = element.tooltipPosition();
          ctx.fillText(String(value), pos.x, pos.y - 6);
        });
      });
      ctx.restore();
    }
  };

  var data = getChartData();
  if (data && window.Chart) {
    var siteCanvas = document.getElementById('personnelSiteChart');
    if (siteCanvas) new Chart(siteCanvas, {
      type: 'bar', data: { labels: labels(data.sites), datasets: [{ label: 'Personnel', data: values(data.sites), backgroundColor: chartColors(data.sites.length, .78), borderRadius: 7 }] },
      plugins: [personnelValueLabels],
      options: { responsive: true, maintainAspectRatio: false, indexAxis: 'y', cursor: 'pointer', layout: { padding: { right: 28 } }, plugins: { legend: { display: false }, tooltip: { callbacks: { label: function (context) { return ' Effectif : ' + context.parsed.x; } } } }, scales: { x: { beginAtZero: true, ticks: { precision: 0 } }, y: { grid: { display: false } } }, onHover: function(event, active){ event.native.target.style.cursor = active.length ? 'pointer' : 'default'; }, onClick: function(event, active){ if(!active.length)return; var i=active[0].index; openEffectifBy('site', data.sites[i].id, data.sites[i].label); } }
    });
    var entityCanvas = document.getElementById('personnelEntityChart');
    if (entityCanvas) new Chart(entityCanvas, {
      type: 'bar',
      data: { labels: labels(data.entities), datasets: [{ label: 'Effectif', data: values(data.entities), backgroundColor: chartColors(data.entities.length, .75), borderRadius: 7, maxBarThickness: 74 }] },
      plugins: [personnelValueLabels],
      options: {
        responsive: true,
        maintainAspectRatio: false,
        layout: { padding: { top: 24 } },
        plugins: {
          legend: { display: false },
          tooltip: { callbacks: { label: function (context) { return ' Effectif : ' + context.parsed.y; } } }
        },
        scales: {
          y: { beginAtZero: true, suggestedMax: Math.max.apply(null, values(data.entities)) * 1.12, ticks: { precision: 0 } },
          x: { grid: { display: false }, ticks: { maxRotation: 28, minRotation: 0, autoSkip: false } }
        },
        onHover: function(event, active){ event.native.target.style.cursor = active.length ? 'pointer' : 'default'; },
        onClick: function(event, active){ if(!active.length)return; var i=active[0].index; openEffectifBy('appartenance', data.entities[i].id, data.entities[i].label); }
      }
    });
    var gradeCanvas = document.getElementById('personnelGradeChart');
    if (gradeCanvas) new Chart(gradeCanvas, {
      type: 'doughnut', data: { labels: labels(data.grades), datasets: [{ data: values(data.grades), backgroundColor: chartColors(data.grades.length, .85), borderWidth: 0, hoverOffset: 7 }] },
      options: { responsive: true, maintainAspectRatio: false, cutout: '66%', plugins: { legend: { position: 'bottom', labels: { usePointStyle: true, boxWidth: 8 } } }, onHover: function(event, active){ event.native.target.style.cursor = active.length ? 'pointer' : 'default'; }, onClick: function(event, active){ if(!active.length)return; var i=active[0].index; openEffectifBy('grade', data.grades[i].id, data.grades[i].label); } }
    });
  }
}());


document.addEventListener('DOMContentLoaded', function(){
  document.querySelectorAll('.edit-grade').forEach(function(btn){
    btn.addEventListener('click', function(){
      var r = JSON.parse(btn.getAttribute('data-record') || '{}');
      [['id_gr','id_gr'],['sigle_grade','sigle_grade'],['Libelle_complete','Libelle_complete'],['GradeCode','Code'],['GradeCommentaire','Commentaire'],['ordre_gr','ordre_gr'],['Categorie','Categorie']].forEach(function(m){ var e=document.getElementById(m[0]); if(e)e.value=r[m[1]]==null?'':r[m[1]]; });
    });
  });
  var gm=document.getElementById('gradeModal'); if(gm) gm.addEventListener('hidden.bs.modal', function(){ gm.querySelector('form').reset(); var id=document.getElementById('id_gr'); if(id)id.value=''; });
});
