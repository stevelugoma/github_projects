<?php
require_once __DIR__ . '/helpers.php';
header('Content-Type: application/json; charset=UTF-8');
if (!isset($_SESSION['user'])) { http_response_code(401); echo json_encode(array('ok'=>false,'message'=>'Session expirée.')); exit; }
if (!aPermission('signataires.manage')) { http_response_code(403); echo json_encode(array('ok'=>false,'message'=>'Action non autorisée.')); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(array('ok'=>false,'message'=>'Méthode non autorisée.')); exit; }
$nom = trim(isset($_POST['nom_complet']) ? $_POST['nom_complet'] : '');
$qualite = trim(isset($_POST['qualite']) ? $_POST['qualite'] : '');
$ordre = isset($_POST['ordre_affichage']) ? (int)$_POST['ordre_affichage'] : 0;
$actif = isset($_POST['actif']) ? 1 : 0;
if ($nom === '' || $qualite === '') { http_response_code(422); echo json_encode(array('ok'=>false,'message'=>'Le nom et la qualité sont obligatoires.')); exit; }
try {
  $stmt=db()->prepare('INSERT INTO signataire_impression(nom_complet,qualite,actif,ordre_affichage) VALUES(?,?,?,?)');
  $stmt->execute(array($nom,$qualite,$actif,$ordre));
  $id=(int)db()->lastInsertId();
  logAudit('create','signataire_impression',(string)$id,null,array('nom_complet'=>$nom,'qualite'=>$qualite,'actif'=>$actif,'ordre_affichage'=>$ordre));
  echo json_encode(array('ok'=>true,'signataire'=>array('id'=>$id,'nom_complet'=>$nom,'qualite'=>$qualite,'actif'=>$actif)), JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  http_response_code(500); echo json_encode(array('ok'=>false,'message'=>'Enregistrement impossible : '.$e->getMessage()), JSON_UNESCAPED_UNICODE);
}
