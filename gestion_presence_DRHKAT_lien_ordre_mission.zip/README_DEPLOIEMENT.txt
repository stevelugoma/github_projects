DÉPLOIEMENT — presence.edrhkat.com

1. Dans le panneau d'hébergement, vérifiez que le sous-domaine presence.edrhkat.com pointe vers le dossier choisi (par exemple public_html/presence).
2. Envoyez tout le contenu de ce dossier dans la racine du sous-domaine.
3. Vérifiez que PHP dispose des extensions PDO MySQL, mbstring, zip et XML.
4. Ouvrez https://presence.edrhkat.com/install.php
5. Cliquez sur « Installer les tables ».
6. Connectez-vous avec admin / admin123, puis changez immédiatement ce mot de passe.
7. Supprimez ou renommez install.php après l'installation.
8. Activez un certificat SSL dans le panneau d'hébergement.

La base est déjà configurée dans config.php. Le programme d'installation utilise la base existante et ne tente pas de la créer.

IDENTITE INSTITUTIONNELLE INTEGREE
- Logo officiel DRHKAT : assets/img/logo-drhkat.png
- Site officiel : https://www.edrhkat.com
- Messagerie interne : https://mail.edrhkat.com
- Contact : drhkat.d@edrhkat.com
Ces liens apparaissent sur la connexion, la navigation, le pied de page et les impressions.

NOUVEAU MODULE PERSONNELS
-------------------------
Après connexion, utilisez le menu « Personnels ». La base de production fournie
contient déjà les tables personnel, entite et appartenance : aucune réimportation
du dump complet n'est nécessaire. Les créations/modifications/suppressions sont
réservées aux rôles Administrateur et Gestionnaire RH.
