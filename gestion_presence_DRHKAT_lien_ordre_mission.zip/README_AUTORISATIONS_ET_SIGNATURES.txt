MISE A JOUR — AUTORISATIONS PERSONNALISEES ET SIGNATAIRES

1. Exécuter migration_autorisations_personnalisees.sql sur une base existante (la table est aussi créée automatiquement).
2. Ouvrir Administration > Autorisations.
3. Sélectionner un utilisateur et cocher ses droits précis.
4. Toutes les impressions utilisant window.print ouvrent maintenant la fenêtre universelle de choix du signataire.
5. Les utilisateurs disposant du droit signataires.manage peuvent ajouter un signataire directement dans cette fenêtre.
