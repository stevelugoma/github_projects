MISE À JOUR — AJOUT, MODIFICATION ET SUPPRESSION DES PRÉSENCES

1. Nouvelle autorisation personnalisée : presences.manage
2. Formulaire d'ajout et de modification dans presences.php
3. Calcul automatique de la durée, du retard, de la tranche et des anomalies
4. Synchronisation du premier pointage IN/OUT avec passage_brut
5. Suppression sécurisée de la présence et de ses pointages associés
6. Traçabilité complète dans audit_log

Aucune migration SQL n'est requise. L'autorisation apparaît automatiquement dans
Administration > Autorisations grâce au catalogue centralisé des permissions.
