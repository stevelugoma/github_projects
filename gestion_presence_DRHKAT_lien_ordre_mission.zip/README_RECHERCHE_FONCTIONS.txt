MISE À JOUR — RECHERCHE DANS LES LISTES DE FONCTIONS

Les listes déroulantes alimentées par la table fonction disposent maintenant d’un champ de recherche instantanée.

Emplacements couverts :
- ajout et modification d’un agent ;
- ajout et modification d’un personnel ;
- gestion des signataires ;
- ajout rapide d’un signataire avant impression.

La recherche ignore la casse et les accents. Elle filtre le sigle, le libellé et la valeur de la fonction.
Aucune modification de la base de données n’est nécessaire.
