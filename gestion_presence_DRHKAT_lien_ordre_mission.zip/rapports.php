<?php
$pageTitle = 'Rapports & statistiques';
$activePage = 'rapports.php';
require_once __DIR__ . '/helpers.php';

$pdo = db();
$type = $_GET['type'] ?? 'synthese';

include __DIR__ . '/partials/layout.php';

// Récupération des paramètres de période communs
$dateD = $_GET['date_debut'] ?? '';
$dateF = $_GET['date_fin'] ?? '';
if (!$dateD || !$dateF) {
    $p = $pdo->query("SELECT MIN(date_presence) d1, MAX(date_presence) d2 FROM presence_journaliere")->fetch();
    if ($p['d1']) { $dateD = $p['d1']; $dateF = $p['d2']; }
}

// Onglets
$types = [
    'synthese'   => 'Synthèse générale',
    'presences'  => 'Présences',
    'retards'    => 'Retards',
    'absences'   => 'Absences',
    'agent'      => 'Fiche individuelle',
];
?>
<div class="card">
    <div class="card-header"><h2>📈 Rapports</h2></div>
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px">
        <?php foreach ($types as $k => $v): ?>
            <a href="rapports.php?type=<?php echo $k; ?>" class="btn btn-sm <?php echo $type===$k?'':'btn-outline'; ?>"><?php echo $v; ?></a>
        <?php endforeach; ?>
    </div>
    <form method="get" class="filters" style="padding:0;margin:0">
        <input type="hidden" name="type" value="<?php echo h($type); ?>">
        <div class="form-group"><label>Du</label><input type="date" name="date_debut" value="<?php echo h($dateD); ?>"></div>
        <div class="form-group"><label>Au</label><input type="date" name="date_fin" value="<?php echo h($dateF); ?>"></div>
        <?php if ($type === 'agent'): ?>
            <div class="form-group">
                <label>Agent</label>
                <select name="numero">
                    <option value="">— Sélectionner —</option>
                    <?php foreach ($pdo->query("SELECT numero_identification, nom_complet FROM agents ORDER BY nom_complet")->fetchAll() as $a): ?>
                        <option value="<?php echo h($a['numero_identification']); ?>" <?php echo ($_GET['numero']??'')===$a['numero_identification']?'selected':''; ?>><?php echo h($a['numero_identification'].' — '.($a['nom_complet']?:'sans nom')); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        <?php endif; ?>
        <div class="form-group" style="flex:0"><button type="submit" class="btn">🔎 Générer</button></div>
    </form>
    <div class="mt-2">
        <a href="export.php?type=<?php echo h($type); ?>&<?php echo http_build_query($_GET); ?>" class="btn btn-sm btn-success">📥 Exporter en CSV (Excel)</a>
        <button onclick="window.print()" class="btn btn-sm btn-outline">🖨️ Imprimer</button>
    </div>
</div>

<?php
$whereDate = '';
$params = [];
if ($dateD) { $whereDate .= " AND date_presence>=?"; $params[] = $dateD; }
if ($dateF) { $whereDate .= " AND date_presence<=?"; $params[] = $dateF; }

// ============ SYNTHESE GENERALE ============
if ($type === 'synthese'):
    $sql = "SELECT
        COUNT(DISTINCT numero_identification) AS agents_ayant_pointe,
        COUNT(*) AS total_jours,
        SUM(statut='present') AS jours_presents,
        SUM(statut='absent') AS jours_absents,
        SUM(statut='conge') AS jours_conges,
        SUM(statut='mission') AS jours_mission,
        SUM(statut='ferie') AS jours_feries,
        SUM(retard_minutes>0) AS retards,
        SUM(retard_minutes) AS total_min_retard,
        ROUND(AVG(retard_minutes),1) AS moy_retard
        FROM presence_journaliere WHERE 1=1 $whereDate";
    $stmt = $pdo->prepare($sql); $stmt->execute($params);
    $s = $stmt->fetch();

    // taux
    $tauxPresence = $s['total_jours'] > 0 ? round(($s['jours_presents'] / $s['total_jours']) * 100, 1) : 0;
    $tauxAbsenteisme = $s['total_jours'] > 0 ? round(($s['jours_absents'] / $s['total_jours']) * 100, 1) : 0;
?>
    <div class="stat-grid">
        <div class="stat-card blue"><div class="stat-icon">👥</div><div><div class="stat-value"><?php echo (int)$s['agents_ayant_pointe']; ?></div><div class="stat-label">Agents ayant pointé</div></div></div>
        <div class="stat-card green"><div class="stat-icon">📅</div><div><div class="stat-value"><?php echo (int)$s['total_jours']; ?></div><div class="stat-label">Jours-présences</div></div></div>
        <div class="stat-card green"><div class="stat-icon">✅</div><div><div class="stat-value"><?php echo $tauxPresence; ?>%</div><div class="stat-label">Taux de présence</div></div></div>
        <div class="stat-card red"><div class="stat-icon">❌</div><div><div class="stat-value"><?php echo $tauxAbsenteisme; ?>%</div><div class="stat-label">Taux d'absentéisme</div></div></div>
        <div class="stat-card yellow"><div class="stat-icon">⏰</div><div><div class="stat-value"><?php echo (int)$s['retards']; ?></div><div class="stat-label">Retards</div></div></div>
        <div class="stat-card orange"><div class="stat-icon">⏱️</div><div><div class="stat-value"><?php echo (int)$s['total_min_retard']; ?></div><div class="stat-label">Minutes de retard</div></div></div>
        <div class="stat-card purple"><div class="stat-icon">🏖️</div><div><div class="stat-value"><?php echo (int)$s['jours_conges']; ?></div><div class="stat-label">Jours en congé</div></div></div>
        <div class="stat-card purple"><div class="stat-icon">✈️</div><div><div class="stat-value"><?php echo (int)$s['jours_mission']; ?></div><div class="stat-label">Jours en mission</div></div></div>
    </div>

    <?php
    // répartition par service
    $stmt = $pdo->prepare("SELECT a.service,
        COUNT(*) AS jours,
        SUM(p.retard_minutes>0) AS retards,
        SUM(p.retard_minutes) AS min_retard
        FROM presence_journaliere p JOIN agents a ON a.numero_identification=p.numero_identification
        WHERE 1=1 $whereDate
        GROUP BY a.service ORDER BY retards DESC");
    $stmt->execute($params);
    $parService = $stmt->fetchAll();
    ?>
    <div class="card">
        <div class="card-header"><h2>Statistiques par service</h2></div>
        <div class="table-wrap">
            <table class="data-table">
                <thead><tr><th>Service</th><th>Jours-présences</th><th>Retards</th><th>Minutes cumulées</th></tr></thead>
                <tbody>
                <?php foreach ($parService as $r): ?>
                    <tr><td><?php echo h($r['service'] ?: '—'); ?></td><td><?php echo (int)$r['jours']; ?></td><td><?php echo (int)$r['retards']; ?></td><td class="text-danger"><?php echo (int)$r['min_retard']; ?> min</td></tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php
// ============ PRESENCES ============
elseif ($type === 'presences'):
    $stmt = $pdo->prepare("SELECT p.*, a.nom_complet, a.service
        FROM presence_journaliere p JOIN agents a ON a.numero_identification=p.numero_identification
        WHERE 1=1 $whereDate ORDER BY p.date_presence DESC, a.nom_complet LIMIT 200");
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
?>
    <div class="card">
        <div class="card-header"><h2>Présences du <?php echo formatDateFr($dateD); ?> au <?php echo formatDateFr($dateF); ?></h2></div>
        <div class="table-wrap">
            <table class="data-table">
                <thead><tr><th>Date</th><th>N°</th><th>Agent</th><th>Entrée</th><th>Sortie</th><th>Durée</th><th>Retard</th><th>Statut</th></tr></thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr><td><?php echo formatDateFr($r['date_presence']); ?></td><td class="num"><?php echo h($r['numero_identification']); ?></td><td><?php echo h($r['nom_complet']); ?></td><td><?php echo formatHeure($r['premiere_entree']); ?></td><td><?php echo formatHeure($r['derniere_sortie']); ?></td><td><?php echo $r['duree_minutes']?gmdate('H:i',$r['duree_minutes']*60):'—'; ?></td><td><?php echo $r['retard_minutes']>0?'<span class="text-danger">'.$r['retard_minutes'].' min</span>':'—'; ?></td><td><?php echo badgeStatut($r['statut']); ?></td></tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php
// ============ RETARDS ============
elseif ($type === 'retards'):
    $stmt = $pdo->prepare("SELECT p.*, a.nom_complet, a.service
        FROM presence_journaliere p JOIN agents a ON a.numero_identification=p.numero_identification
        WHERE p.retard_minutes>0 $whereDate ORDER BY p.retard_minutes DESC LIMIT 200");
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
?>
    <div class="card">
        <div class="card-header"><h2>Retards du <?php echo formatDateFr($dateD); ?> au <?php echo formatDateFr($dateF); ?></h2></div>
        <div class="table-wrap">
            <table class="data-table">
                <thead><tr><th>Date</th><th>N°</th><th>Agent</th><th>Service</th><th>Arrivée</th><th>Retard</th><th>Tranche</th><th>Justifié</th></tr></thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr><td><?php echo formatDateFr($r['date_presence']); ?></td><td class="num"><?php echo h($r['numero_identification']); ?></td><td><?php echo h($r['nom_complet']); ?></td><td><?php echo h($r['service']); ?></td><td><?php echo formatHeure($r['premiere_entree']); ?></td><td class="text-danger"><b><?php echo (int)$r['retard_minutes']; ?> min</b></td><td><?php echo badgeTranche($r['tranche_retard']); ?></td><td><?php echo !empty($r['motif_correction'])?'<span class="badge badge-blue">Oui</span>':'<span class="badge badge-gray">Non</span>'; ?></td></tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php
// ============ ABSENCES ============
elseif ($type === 'absences'):
    $stmt = $pdo->prepare("SELECT ab.*, a.nom_complet, a.service
        FROM absence ab JOIN agents a ON a.numero_identification=ab.numero_identification
        WHERE ab.date_fin>=? AND ab.date_debut<=? ORDER BY ab.date_debut DESC");
    $stmt->execute([$dateD ?: '1900-01-01', $dateF ?: '2999-12-31']);
    $rows = $stmt->fetchAll();
?>
    <div class="card">
        <div class="card-header"><h2>Absences du <?php echo formatDateFr($dateD); ?> au <?php echo formatDateFr($dateF); ?></h2></div>
        <div class="table-wrap">
            <table class="data-table">
                <thead><tr><th>N°</th><th>Agent</th><th>Service</th><th>Du</th><th>Au</th><th>Type</th><th>Statut</th></tr></thead>
                <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr><td class="num"><?php echo h($r['numero_identification']); ?></td><td><?php echo h($r['nom_complet']); ?></td><td><?php echo h($r['service']); ?></td><td><?php echo formatDateFr($r['date_debut']); ?></td><td><?php echo formatDateFr($r['date_fin']); ?></td><td><span class="badge badge-orange"><?php echo h($r['type']); ?></span></td><td><span class="badge badge-<?php echo $r['statut']==='validee'?'green':($r['statut']==='rejetee'?'red':'yellow'); ?>"><?php echo h($r['statut']); ?></span></td></tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php
// ============ FICHE INDIVIDUELLE ============
elseif ($type === 'agent' && !empty($_GET['numero'])):
    $numId = $_GET['numero'];
    $a = $pdo->prepare("SELECT * FROM agents WHERE numero_identification=?"); $a->execute([$numId]);
    $agent = $a->fetch();
    if ($agent):
        $stmt = $pdo->prepare("SELECT * FROM presence_journaliere WHERE numero_identification=? $whereDate ORDER BY date_presence");
        $stmt->execute(array_merge([$numId], $params));
        $jours = $stmt->fetchAll();
        $nbRetards = 0; $totalMin = 0;
        foreach ($jours as $j) { if ($j['retard_minutes']>0) { $nbRetards++; $totalMin += $j['retard_minutes']; } }
?>
    <div class="card">
        <div class="card-header"><h2>Fiche individuelle — <?php echo h($agent['nom_complet']); ?></h2></div>
        <div class="detail-grid">
            <dt>N° identification</dt><dd class="num"><?php echo h($agent['numero_identification']); ?></dd>
            <dt>Service</dt><dd><?php echo h($agent['service']); ?></dd>
            <dt>Fonction</dt><dd><?php echo h($agent['fonction']); ?></dd>
            <dt>Période</dt><dd><?php echo formatDateFr($dateD); ?> → <?php echo formatDateFr($dateF); ?></dd>
            <dt>Jours pointés</dt><dd><?php echo count($jours); ?></dd>
            <dt>Retards</dt><dd><b><?php echo $nbRetards; ?></b> — <?php echo $totalMin; ?> min cumulées</dd>
        </div>
    </div>
    <div class="card">
        <div class="table-wrap">
            <table class="data-table">
                <thead><tr><th>Date</th><th>Entrée</th><th>Sortie</th><th>Durée</th><th>Retard</th><th>Statut</th><th>Horaire appliqué</th></tr></thead>
                <tbody>
                <?php foreach ($jours as $j): ?>
                    <tr><td><?php echo formatDateFr($j['date_presence']); ?></td><td><?php echo formatHeure($j['premiere_entree']); ?></td><td><?php echo formatHeure($j['derniere_sortie']); ?></td><td><?php echo $j['duree_minutes']?gmdate('H:i',$j['duree_minutes']*60):'—'; ?></td><td><?php echo $j['retard_minutes']>0?'<span class="text-danger">'.$j['retard_minutes'].' min</span>':'—'; ?></td><td><?php echo badgeStatut($j['statut']); ?></td><td><small><?php echo h($j['horaire_applique']); ?></small></td></tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php else: ?>
    <div class="alert alert-warning">Agent introuvable.</div>
<?php endif; endif; ?>

<?php include __DIR__ . '/partials/footer.php'; ?>
